﻿using System;
using System.IO;

namespace nyp.Commands
{
    public class Logger
    {
        private static Logger Instance;
        private string LogPath;

        private Logger() {
            LogPath = Path.Combine(Directory.GetCurrentDirectory(), "log");
        }

        public static Logger getInstance()
        {
            if (Instance == null) Instance = new Logger();

            return Instance;
        }

        public void Log(string log)
        {
            if (!Directory.Exists(LogPath)) Directory.CreateDirectory(LogPath);

            var logFileName = $"log-{DateTime.Now.Year}{DateTime.Now.Month}.log";
            var logFullFileName = Path.Combine(LogPath, logFileName);
            string logContent = $"\n[{DateTime.Now.ToString("yyyy-MM-dd H:mm:ss")}] {log}";
            Console.WriteLine(logContent);
            File.AppendAllText(logFullFileName, logContent);
        }
    }
}
