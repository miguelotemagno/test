﻿using Microsoft.Data.Entity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.PlatformAbstractions;
using nyp.DataModels;
using nyp.Organica;
using System;
using System.Collections.Generic;
using System.Linq;

namespace nyp.Commands
{
    public class Program
    {
        private readonly IConfiguration Configuration;
        private readonly IServiceProvider ServiceProvider;
        private readonly NYPContext NYPContext;
        private readonly OrganicaDbContext OrganicaContext;

        public Program(IApplicationEnvironment appEnv, IServiceProvider serviceProvider)
        {
            ServiceProvider = serviceProvider;
            Configuration = new ConfigurationBuilder()
               .SetBasePath(appEnv.ApplicationBasePath)
               .AddJsonFile("../nyp/config.json")
               .Build();
            var optionsNYP = new DbContextOptionsBuilder();
            optionsNYP.UseSqlServer(Configuration["Data:NYP:ConnectionString"]);
            NYPContext = new NYPContext(optionsNYP.Options);
            var optionsOrg = new DbContextOptionsBuilder();
            optionsOrg.UseSqlServer(Configuration["Data:Organica:ConnectionString"]);
            OrganicaContext = new OrganicaDbContext(optionsOrg.Options);
        }

        private bool CargarJerarquia(out Jerarquia jerarquiaResultado)
        {
            var jerarquia = new Jerarquia();

            var qry = OrganicaContext.GetOrganica();
            foreach (var q in qry)
            {
                if (q.CodGerencia.HasValue && q.CodArea.HasValue && q.CodUnidadRelacional.HasValue) //&& !string.IsNullOrWhiteSpace(q.Correo))
                {
                    CollGerencia gerencia;
                    if (!jerarquia.Gerencias.TryGetValue(q.CodGerencia.Value, out gerencia))
                    {
                        gerencia = new CollGerencia
                        {
                            Nombre = q.GlsGerencia
                        };
                        jerarquia.Gerencias.Add(q.CodGerencia.Value, gerencia);
                    }
                    CollArea area;
                    if (!gerencia.Areas.TryGetValue(q.CodArea.Value, out area))
                    {
                        area = new CollArea
                        {
                            Nombre = q.GlsArea
                        };
                        gerencia.Areas.Add(q.CodArea.Value, area);
                    }
                    CollUnidad unidad;
                    if (!area.Unidades.TryGetValue(q.CodUnidadRelacional.Value, out unidad))
                    {
                        unidad = new CollUnidad
                        {
                            Nombre = q.UnidadRelacional
                        };
                        area.Unidades.Add(q.CodUnidadRelacional.Value, unidad);
                    }
                }
            }
            jerarquiaResultado = jerarquia;
            return true;
        }

        public void Listado()
        {
            Jerarquia j;
            if (CargarJerarquia(out j))
            {
                foreach (var g in j.Gerencias)
                {
                    Logger.getInstance().Log($"{g.Key} - {g.Value.Nombre}");
                    foreach (var a in g.Value.Areas)
                    {
                        Logger.getInstance().Log($"\t{a.Key} - {a.Value.Nombre}");
                        foreach (var u in a.Value.Unidades)
                        {
                            Logger.getInstance().Log($"\t\t{u.Key} - {u.Value}");
                        }
                    }
                }
            }
        }

        private void ActualizarOrganica()
        {
            Jerarquia j;
            if (CargarJerarquia(out j))
            {
                if (RegistrarJerarquia(j))
                {
                    DesmarcarOrganica();
                    SincronizarGerencias();
                    SincronizarAreas();
                    SincronizarUnidades(); 
                }
            }
        }

        private void ActualizarUsuarios()
        {
            Logger.getInstance().Log("Actualizando usuarios");
            var qry = from u in OrganicaContext.GetOrganica()
                      select u;

            var usuariosOrganica = new Dictionary<int, UsuarioIntranet>();
            foreach (var u in qry)
            {
                var rut = Rut.RutAsInt(u.Rut);
               // if (u.CodArea > 0 && u.CodGerencia > 0 && u.CodUnidadRelacional > 0 && !string.IsNullOrWhiteSpace(u.Correo))
                {
                    usuariosOrganica.Add(rut, new UsuarioIntranet()
                    {
                        Id = Rut.RutAsInt(u.Rut),
                        UnidadId = (int)(u.CodUnidadRelacional ?? 0L),
                        Activo = true,
                        ApellidoMaterno = u.ApeMaterno,
                        ApellidoPaterno = u.ApePaterno,
                        Nombres = u.Nombres,
                        Cargo = u.Cargo,
                        Email = u.Correo
                    });
                }
            }

            var usuariosIntranet = (from u in NYPContext.UsuariosIntranet
                                    select u).ToDictionary(k => k.Id, v => v);

            var existentes = usuariosOrganica.Keys.Intersect(usuariosIntranet.Keys);
            var nuevos = usuariosOrganica.Keys.Except(usuariosIntranet.Keys);
            var eliminados = usuariosIntranet.Keys.Except(usuariosOrganica.Keys);

            Logger.getInstance().Log($"\tActualizando usuarios existentes ({existentes.Count()} registros)...");
            foreach (var rut in existentes)
            {
                ActualizarUsuario(usuariosIntranet[rut], usuariosOrganica[rut]);
            }

            Logger.getInstance().Log($"\tAgregando usuarios nuevos ({nuevos.Count()} registros)...");
            foreach (var rut in nuevos)
            {
                var usuarioNuevo = usuariosOrganica[rut];
                if (usuarioNuevo.UnidadId != 0)
                {
                    NYPContext.UsuariosIntranet.Add(usuarioNuevo);
                }
                else
                {
                    Logger.getInstance().Log($"\tUsuario no agregado (unidad inválida): {usuarioNuevo.Id} - {usuarioNuevo.UnidadId}");
                }
            }

            Logger.getInstance().Log($"\tDesactivando usuarios eliminados ({eliminados.Count()} registros)...");
            foreach (var rut in eliminados)
            {
                if (usuariosIntranet[rut].Activo)
                {
                    usuariosIntranet[rut].Activo = false;
                }
            }
            NYPContext.SaveChanges();
            Logger.getInstance().Log("Actualización completada.");
        }

        private static void ActualizarUsuario(UsuarioIntranet usuario, UsuarioIntranet nuevo)
        {
            if (usuario.Cargo != nuevo.Cargo ||
                usuario.Email != nuevo.Email ||
                usuario.Nombres != nuevo.Nombres ||
                usuario.ApellidoPaterno != nuevo.ApellidoPaterno ||
                usuario.ApellidoMaterno != nuevo.ApellidoMaterno ||
                usuario.UnidadId != nuevo.UnidadId
            )
            {
                usuario.Cargo = nuevo.Cargo;
                usuario.Email = nuevo.Email;
                usuario.Nombres = nuevo.Nombres;
                usuario.ApellidoPaterno = nuevo.ApellidoPaterno;
                usuario.ApellidoMaterno = nuevo.ApellidoMaterno;
                usuario.UnidadId = nuevo.UnidadId;
            }
        }

        private bool RegistrarJerarquia(Jerarquia j)
        {
            Dictionary<long, OrganicaArea> DicAreas = new Dictionary<long, OrganicaArea>();
            Dictionary<int, OrganicaUnidad> DicUnidad = new Dictionary<int, OrganicaUnidad>();

            Logger.getInstance().Log("Registrando y Evaluando las Jerarquias en tablas auxiliares.");
            Logger.getInstance().Log("1. Limpiar las tablas aux...");
            //vaciar organica. 

            Logger.getInstance().Log("unidades..");
            var delUnid = from o in OrganicaContext.OrganicaUnidad select o;
            foreach (var row in delUnid)
            {
                OrganicaContext.OrganicaUnidad.Remove(row);
            }
            OrganicaContext.SaveChanges();
 
            Logger.getInstance().Log("areas..");
            var delAre = from o in OrganicaContext.OrganicaAreas select o;
            foreach (var are in delAre)
            {
                OrganicaContext.OrganicaAreas.Remove(are);                
            }
            OrganicaContext.SaveChanges();


            Logger.getInstance().Log("gerencias..");
            var delGer = from o in OrganicaContext.OrganicaGerencias select o;

            foreach (var ger in delGer)
            {
                OrganicaContext.OrganicaGerencias.Remove(ger);
            }
            OrganicaContext.SaveChanges();
           Logger.getInstance().Log("Listo.");



            Logger.getInstance().Log("2. Calculando Gerencias aux....");
            foreach (var gerencia in j.Gerencias)
            {

                if (gerencia.Key == 0)
                {
                    continue;
                }

                OrganicaGerencia og = new OrganicaGerencia();
                og.Id = gerencia.Key;
                og.Nombre = gerencia.Value.Nombre;
                OrganicaContext.OrganicaGerencias.Add(og);
            }
            OrganicaContext.SaveChanges();
            Logger.getInstance().Log("Listo.");
            Logger.getInstance().Log("3. Calculando Areas aux....");


            foreach (var gerencia in j.Gerencias)
            {
                if (gerencia.Key == 0)
                {
                    continue;
                }
                foreach (var area in gerencia.Value.Areas)
                {
                    if (area.Key == 0)
                    {
                        continue;
                    }
                    OrganicaArea oa;
                    if (!DicAreas.TryGetValue(area.Key, out oa))
                    {
                        oa = new OrganicaArea(); 
                        oa.Id = area.Key;
                        oa.Nombre = area.Value.Nombre;
                        oa.OrganicaGerenciaId = gerencia.Key;
                        DicAreas.Add(area.Key, oa);
                    }
                    else
                    {
                        Logger.getInstance().Log($"ERROR: El código de area'{area.Key} - {area.Value.Nombre}' esta repetido. No se registró");
                        continue; 
                    }
                }
                
            }
            Logger.getInstance().Log("guardando...");

            foreach(var combinado in DicAreas)
            {
                OrganicaContext.OrganicaAreas.Add(combinado.Value);
            }
            OrganicaContext.SaveChanges();
            Logger.getInstance().Log("Listo.");
            Logger.getInstance().Log("4. Calculando Unidades...");
            foreach (var gerencia in j.Gerencias)
            {
                /*
                if (gerencia.Key == 0)
                {
                    continue;
                }
                */
                foreach (var area in gerencia.Value.Areas)
                {
                    foreach(var unidad in area.Value.Unidades)
                    {
                        OrganicaUnidad oun;
                        if (!DicUnidad.TryGetValue((int)unidad.Key, out oun))
                        {
                            oun = new OrganicaUnidad();
                            oun.Id = (int)unidad.Key;
                            oun.Nombre = unidad.Value.Nombre;
                            oun.OrganicaAreaId = (int)area.Key;
                            DicUnidad.Add((int)unidad.Key, oun);
                        }
                        else
                        {
                            Logger.getInstance().Log($"ERROR: El código de Unidad '{unidad.Key} - {unidad.Value.Nombre}' esta repetido. No se registró");
                            continue;
                        }                        
                    }
                }
            }
            Logger.getInstance().Log("guardando...");
            foreach (var combinado in DicUnidad)
            {
                OrganicaContext.OrganicaUnidad.Add(combinado.Value);
            }
            OrganicaContext.SaveChanges();
            Logger.getInstance().Log("Listo.");
            return true;
        }

        private void DesmarcarOrganica()
        {
            Logger.getInstance().Log("-- Desamarcar la Organica...");

            Logger.getInstance().Log("gerencia...");
            var gerencias = from g in NYPContext.Gerencias select g;
            foreach (var gerencia in gerencias)
            {
                gerencia.Revision = false;
            }
            NYPContext.SaveChanges();

            Logger.getInstance().Log("areas...");
            var areas = from g in NYPContext.Areas select g;
            foreach (var area in areas)
            {
                area.Revision = false;
            }
            NYPContext.SaveChanges();

            Logger.getInstance().Log("unidades...");
            var unidades = from g in NYPContext.Unidades select g;
            foreach (var unidad in unidades)
            {
                unidad.Revision = false;
            }
            NYPContext.SaveChanges();
            Logger.getInstance().Log("Listo.");
        }

        private void SincronizarGerencias()
        {
            Logger.getInstance().Log("--Certificando gerencias .. parte 1...");
            var gerenciasOrg = from g in OrganicaContext.OrganicaGerencias select g;
            foreach (var gerenciaO in gerenciasOrg)
            {
                var gerenciaNP = (from g in NYPContext.Gerencias where g.Id == gerenciaO.Id select g).FirstOrDefault(); 
                if (gerenciaNP != null)
                {
                    if (gerenciaNP.Nombre.Trim() != gerenciaO.Nombre.Trim())
                    {
                        Logger.getInstance().Log($"Cambio en orgánica: {gerenciaNP.Nombre} -> {gerenciaO.Nombre}");
                        gerenciaNP.FechaCreacion = DateTime.Now;
                        gerenciaNP.Nombre = gerenciaO.Nombre;
                    }
                    gerenciaNP.Revision = true;
                } else
                {
                    gerenciaNP = new Gerencia();
                    gerenciaNP.Id = (int) gerenciaO.Id;
                    gerenciaNP.FechaCreacion = DateTime.Now;
                    gerenciaNP.Nombre = gerenciaO.Nombre;
                    gerenciaNP.Revision = true;
                    NYPContext.Gerencias.Add(gerenciaNP);
                }
            }
            NYPContext.SaveChanges();
            Logger.getInstance().Log(".. parte 2...");
            var gerenciasDel = from g in NYPContext.Gerencias where !g.Revision select g;
            foreach (var geren in gerenciasDel)
            {
                geren.FechaEliminacion = DateTime.Now;
                geren.Revision = true; 
            }
            NYPContext.SaveChanges();
            Logger.getInstance().Log("Listo.");

        }

        private void SincronizarAreas()
        {
            Logger.getInstance().Log("--Certificando areas .. parte 1...");
            var areasOrg = from a in OrganicaContext.OrganicaAreas select a;
            foreach (var areaO in areasOrg)
            {
                var areaNP = (from a in NYPContext.Areas where a.Id == areaO.Id select a).FirstOrDefault();
                if (areaNP != null)
                {
                    if (areaNP.Nombre.Trim() != areaO.Nombre.Trim())
                    {
                        Logger.getInstance().Log($"Cambio en orgánica: {areaNP.Nombre} -> {areaO.Nombre}");
                        areaNP.FechaCreacion = DateTime.Now;
                        areaNP.Nombre = areaO.Nombre;
                    }
                    if (areaNP.GerenciaId != (int)areaO.OrganicaGerenciaId)
                    {
                        Logger.getInstance().Log(string.Format("Cambio de ubicación ({2} - {3}): Gerencia {0} -> Gerencia {1}.", areaNP.GerenciaId, areaO.OrganicaGerenciaId, areaNP.Id, areaNP.Nombre));
                        areaNP.FechaCreacion = DateTime.Now;
                        areaNP.GerenciaId = (int)areaO.OrganicaGerenciaId;
                    }
                    areaNP.Revision = true;
                }
                else
                {
                    areaNP = new Area();
                    areaNP.Id = (int)areaO.Id;
                    areaNP.FechaCreacion = DateTime.Now;
                    areaNP.Nombre = areaO.Nombre;
                    areaNP.Revision = true;
                    areaNP.GerenciaId = (int)areaO.OrganicaGerenciaId;
                    NYPContext.Areas.Add(areaNP);
                }
            }
            NYPContext.SaveChanges();
            Logger.getInstance().Log(" .. parte 2...");
            var areasDel = from a in NYPContext.Areas where !a.Revision select a;
            foreach (var area in areasDel)
            {
                area.FechaEliminacion = DateTime.Now;
                area.Revision = true;
            }
            NYPContext.SaveChanges();
            Logger.getInstance().Log("Listo.");

        }

        private void SincronizarUnidades()
        {
            Logger.getInstance().Log("--Certificando unidades .. parte 1...");
            var unidadesOrg = from u in OrganicaContext.OrganicaUnidad select u;
            foreach (var unidadO in unidadesOrg)
            {
                var unidadNP = (from u in NYPContext.Unidades where u.Id == unidadO.Id select u).FirstOrDefault();
                if (unidadNP != null)
                {
                    if (unidadNP.Nombre.Trim() != unidadO.Nombre.Trim())
                    {
                        Logger.getInstance().Log($"Cambio en orgánica: {unidadNP.Nombre} -> {unidadO.Nombre}");
                        unidadNP.FechaCreacion = DateTime.Now;
                        unidadNP.Nombre = unidadO.Nombre;
                    }
                    if (unidadNP.AreaId != (int)unidadO.OrganicaAreaId)
                    {
                        Logger.getInstance().Log(string.Format("Cambio de ubicación ({2} - {3}): Area {0} -> Area {1}.", unidadNP.AreaId, unidadO.OrganicaAreaId, unidadNP.Id, unidadNP.Nombre));
                        unidadNP.FechaCreacion = DateTime.Now;
                        unidadNP.AreaId = (int)unidadO.OrganicaAreaId;
                    }
                    unidadNP.Revision = true;
                }
                else
                {
                    unidadNP = new Unidad();
                    unidadNP.Id = (int)unidadO.Id;
                    unidadNP.FechaCreacion = DateTime.Now;
                    unidadNP.Nombre = unidadO.Nombre;
                    unidadNP.Revision = true;
                    unidadNP.AreaId = (int)unidadO.OrganicaAreaId;
                    NYPContext.Unidades.Add(unidadNP);
                }
            }
            NYPContext.SaveChanges();
            Logger.getInstance().Log(".. parte 2...");
            var unidadesDel = from u in NYPContext.Unidades where !u.Revision select u;
            foreach (var unidad in unidadesDel)
            {
                unidad.FechaEliminacion = DateTime.Now;
                unidad.Revision = true;
            }
            NYPContext.SaveChanges();
            Logger.getInstance().Log("Listo.");

        }


        public int Main(string[] args)
        {
            ActualizarOrganica();
            ActualizarUsuarios();
            Logger.getInstance().Log("Procedimiento Completado!");
            return 0;

            
        }
    }

    internal class CollGerencia
    {
        public bool Visited { get; set; }
        public string Nombre { get; set; }
        public Dictionary<long, CollArea> Areas { get; set; } = new Dictionary<long, CollArea>();
    }

    internal class CollArea
    {
        public bool Visited { get; set; }
        public string Nombre { get; set; }
        public Dictionary<long, CollUnidad> Unidades { get; set; } = new Dictionary<long, CollUnidad>();
    }

    internal class CollUnidad
    {
        public bool Visited { get; set; }
        public string Nombre { get; set; }
    }

    internal class Jerarquia
    {
        public bool Visited { get; set; }
        public Dictionary<long, CollGerencia> Gerencias { get; set; } = new Dictionary<long, CollGerencia>();
    }
}
