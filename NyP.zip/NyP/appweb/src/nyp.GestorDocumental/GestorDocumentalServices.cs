﻿using System;
using System.Collections.Generic;
using System.IO;

namespace nyp.GestorDocumental.Service
{
    public class DatosPublicacion
    {
        // Identificador del documento - equivalente a DocumentoID en base de datos
        public long Id { get; set; }

        // Descripción del Documento
        public string Descripcion { get; set; }

        // Código del Documento
        public string CodigoDocumento { get; set; }

        // Tipo de Documento
        public string Tipo { get; set; }

        // Nombre físico del archivo
        public string NombreFisico { get; set; }

        // Fecha de Publicación
        public DateTime Fecha { get; set; }
    }

    public interface IPublicacionUri
    {
       DatosPublicacion DatosPublicacion { get; set; }
        Uri Uri { get; set; }
    }

    public interface IResultadoAlmacenar
    {
        string Id { get; set; }
        bool Ok { get; set; }
        string Mensaje { get; set; }
        Uri Uri { get; set; }
    }

    public class DocumentoEnGestor
    {
        public string Id { get; set; }
        public string Nombre { get; set; }
        public string MimeType { get; set; }
        public byte[] Contenidos { get; set; }
    }

    public interface IGestorDocumental
    {
        DocumentoEnGestor GetDocumento(string idDocumento);
        IList<IPublicacionUri> Search(int? CategoriaId, string searchText);
        IResultadoAlmacenar Almacenar(DatosPublicacion datosPublicacion, string nombreArchivo, string stream);
        DocumentoEnGestor GetDocumentoPorNombre(string nombreArchivo);
    }
}
