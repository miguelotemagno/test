﻿using System;
using System.Collections.Generic;
using Microsoft.Data.Entity;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.Data.Entity.Infrastructure;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.RegularExpressions;
using Microsoft.Data.Entity.ChangeTracking;
using System.Threading.Tasks;
using System.Threading;
using Microsoft.Data.Entity.Metadata.Internal;

namespace nyp.DataModels
{
    public class ComboTreeViewModel
    {
        public IList<ComboTreeViewModel> children { get; set; }
        public string id { get; set; }
        public string text { get; set; }
        public string state { get; set; }
    }


    public interface INYPContext
    {
        DbSet<Categoria> Categorias { get; set; }
        // Homepage
        DbSet<Noticia> Noticias { get; set; }
        DbSet<Seccion> Secciones { get; set; }

        DbSet<UsuarioIntranet> UsuariosIntranet { get; set; }
        DbSet<Solicitud> Solicitudes { get; set; }
        DbSet<UsuarioNotificado> UsuariosNotificados { get; set; }
        DbSet<AutorizacionSolicitud> Autorizadores { get; set; }
        DbSet<Evento> Evento { get; set; }
        DbSet<Publicacion> Publicaciones { get; set; }
        DbSet<Archivo> Archivos { get; set; }
        DbSet<Documento> Documentos { get; set; }
        DbSet<DocumentosEnPublicacion> DocumentosEnPublicaciones { get; set; }
        DbSet<DocumentosExistentesEnSolicitud> DocumentosExistentesEnSolicitud { get; set; }
        DbSet<ArchivosEnSolicitud> ArchivosEnSolicitud { get; set; }
        DbSet<CategoriasEnPublicacion> CategoriasEnPublicacion { get; set; }
        DbSet<PaginaContenidos> PaginasContenidos { get; set; }
        DbSet<Circular> Circulares { get; set; }
        DbSet<Nota> Notas { get; set; }

        DbSet<ProcesoCertificacion> Certificaciones { get; set; }
        DbSet<EnlacesCategoria> EnlacesCategorias { get; set; }

        DbSet<UsuarioConsulta> ConsultasEnCircular { get; set; }
        DbSet<PropiedadConfiguracion> Propiedades { get; set; }
        DbSet<Gerencia> Gerencias { get; set; }
        DbSet<Area> Areas { get; set; }
        DbSet<Unidad> Unidades { get; set; }

        DbSet<ListaDistribucion> ListasDistribucion { get; set; }
        // Igual necesito esta tabla..
        DbSet<UsuariosEnListaDistribucion> UsuariosEnListaDistribucion { get; set; }

        DbSet<EstadisticaPublicacion> EstadisticasPublicaciones { get; set; }
        DbSet<EstadisticaDocumento> EstadisticasDocumentos { get; set; }

        DbSet<ExclusionUsuario> ExclusionesUsuario { get; set; }
        DbSet<Restriccion> Restricciones { get; set; }
        DbSet<CodigoGlosa> CodigosGlosa { get; set; }

        EntityEntry Entry(object entity);
        int SaveChanges();
        Task<int> SaveChangesAsync(CancellationToken cancellationToken = default(CancellationToken));
        DbSet<TEntity> Set<TEntity>() where TEntity : class;

        DatabaseFacade Database { get; }
        IList<Categoria> ListaCategorias(long? id);
        IList<Categoria> ObtenerPathCategoria(long id);
        IList<ComboTreeViewModel> OrganicaInicial(string id);
        IList<ComboTreeViewModel> ComboCategorias();
        int GetUnidadId(string unidadId);
    }

    public class EnlacesCategoria
    {
        public int Id { get; set; }
        public long CategoriaId { get; set; }
        public Categoria Categoria { get; set; }
        public string Titulo { get; set; }
        public string Hipervinculo { get; set; }
    }

    public class ListaDistribucion
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Notas { get; set; }
        public ICollection<EventoConfiguracion> Historial { get; set; }
        public ICollection<UsuariosEnListaDistribucion> UsuariosEnListaDistribucion { get; set; }
    }

    public class UsuariosEnListaDistribucion
    {
        public int UsuarioIntranetId { get; set; }
        public UsuarioIntranet UsuarioIntranet { get; set; }

        public int ListaDistribucionId { get; set; }
        public ListaDistribucion ListaDistribucion { get; set; }
    }

    public class EventoConfiguracion
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public UsuarioIntranet Autor { get; set; }
        public string Descripcion { get; set; }
    }

    public class Nota
    {
        public int Id { get; set; }
        public long SolicitudId { get; set; }
        public Solicitud Solicitud { get; set; }

        public int AutorId { get; set; }
        public UsuarioIntranet Autor { get; set; }

        public DateTime Fecha { get; set; }
        public string Texto { get; set; }
        // Sólo para analistas
        public bool Privada { get; set; }
    }

    public class PropiedadConfiguracion
    {
        public string Id { get; set; }
        public string Valor { get; set; }
    }

    public class NYPContext : DbContext, INYPContext
    {
        public NYPContext(DbContextOptions options)
        : base(options)
        { }
        public DbSet<Categoria> Categorias { get; set; }
        public DbSet<Noticia> Noticias { get; set; }
        public DbSet<Seccion> Secciones { get; set; }
        public DbSet<UsuarioIntranet> UsuariosIntranet { get; set; }
        public DbSet<Solicitud> Solicitudes { get; set; }
        public DbSet<UsuarioNotificado> UsuariosNotificados { get; set; }
        public DbSet<AutorizacionSolicitud> Autorizadores { get; set; }
        public DbSet<Evento> Evento { get; set; }
        public DbSet<Publicacion> Publicaciones { get; set; }
        public DbSet<Archivo> Archivos { get; set; }
        public DbSet<Documento> Documentos { get; set; }
        public DbSet<DocumentosEnPublicacion> DocumentosEnPublicaciones { get; set; }
        public DbSet<DocumentosExistentesEnSolicitud> DocumentosExistentesEnSolicitud { get; set; }
        public DbSet<ArchivosEnSolicitud> ArchivosEnSolicitud { get; set; }
        public DbSet<CategoriasEnPublicacion> CategoriasEnPublicacion { get; set; }
        public DbSet<PaginaContenidos> PaginasContenidos { get; set; }
        public DbSet<Circular> Circulares { get; set; }
        public DbSet<UsuarioConsulta> ConsultasEnCircular { get; set; }
        public DbSet<PropiedadConfiguracion> Propiedades { get; set; }
        public DbSet<Gerencia> Gerencias { get; set; }
        public DbSet<Area> Areas { get; set; }
        public DbSet<Unidad> Unidades { get; set; }
        public DbSet<Nota> Notas { get; set; }

        public DbSet<ProcesoCertificacion> Certificaciones { get; set; }
        public DbSet<EnlacesCategoria> EnlacesCategorias { get; set; }

        public DbSet<ListaDistribucion> ListasDistribucion { get; set; }
        public DbSet<UsuariosEnListaDistribucion> UsuariosEnListaDistribucion { get; set; }
        public DbSet<EstadisticaPublicacion> EstadisticasPublicaciones { get; set; }
        public DbSet<EstadisticaDocumento> EstadisticasDocumentos { get; set; }

        public DbSet<ExclusionUsuario> ExclusionesUsuario { get; set; }
        public DbSet<Restriccion> Restricciones { get; set; }
        public DbSet<CodigoGlosa> CodigosGlosa { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AutorizacionSolicitud>().HasKey(x => new { x.UsuarioIntranetId, x.SolicitudId });
            modelBuilder.Entity<DocumentosEnPublicacion>().HasKey(x => new { x.DocumentoId, x.PublicacionId });
            modelBuilder.Entity<ArchivosEnSolicitud>().HasKey(x => new { x.ArchivoId, x.SolicitudId });
            modelBuilder.Entity<DocumentosExistentesEnSolicitud>().HasKey(x => new { x.DocumentoId, x.SolicitudId });
            modelBuilder.Entity<Categoria>().HasOne<Categoria>().WithMany("Children");
            modelBuilder.Entity<CategoriasEnPublicacion>().HasKey(x => new { x.CategoriaId, x.PublicacionId });
            modelBuilder.Entity<UsuarioConsulta>().HasKey(x => new { x.UsuarioIntranetId, x.CircularId });
            modelBuilder.Entity<UsuariosEnListaDistribucion>().HasKey(x => new { x.ListaDistribucionId, x.UsuarioIntranetId });

            modelBuilder.Entity<Gerencia>().Property(b => b.FechaCreacion).HasDefaultValueSql("getdate()");
            modelBuilder.Entity<Area>().Property(b => b.FechaCreacion).HasDefaultValueSql("getdate()");
            modelBuilder.Entity<Unidad>().Property(b => b.FechaCreacion).HasDefaultValueSql("getdate()");

            modelBuilder.Entity<DocumentosMasVisitados>().HasKey(mep => mep.Id);
            modelBuilder.Entity<PublicacionesMasVisitadas>().HasKey(mep => mep.Id);
            modelBuilder.Entity<ReporteSolicitudItem>().HasKey(mep => mep.Solicitud);
            modelBuilder.Entity<ReportePublicacionItem>().HasKey(mep => mep.Id);
            modelBuilder.Entity<ReporteCertificacionItem>().HasKey(mep => mep.Id);
            modelBuilder.Entity<Documento>().Property(e => e.Version).HasDefaultValue(0);


            modelBuilder.Entity<Publicacion>()
                .HasMany(c => c.DocumentosEnPublicacion)
                .WithOne(c => c.Publicacion)
                .OnDelete(Microsoft.Data.Entity.Metadata.DeleteBehavior.Cascade);

            modelBuilder.Entity<DocumentosEnPublicacion>()
                .HasOne(c => c.Publicacion)
                .WithMany(c => c.DocumentosEnPublicacion)
                .OnDelete(Microsoft.Data.Entity.Metadata.DeleteBehavior.Restrict);
        }

        public IList<Categoria> ListaCategorias(long? id)
        {
            var root = (from c in Categorias.Include(t => t.Children)
                        where c.CategoriaId == id
                        select c).ToList();
            return root;
        }

        public IList<Categoria> ObtenerPathCategoria(long id)
        {
            var tmpColl = new List<Categoria>();
            var leaf = (from c in Categorias
                        where c.Id == id
                        select c).FirstOrDefault();
            int preventLoop = 0;
            while (leaf != null)
            {
                tmpColl.Add(leaf);
                leaf = (from c in Categorias
                        where c.Id == leaf.CategoriaId
                        select c).FirstOrDefault();
                if (preventLoop++ > 10)
                {
                    break;
                }
            }
            return tmpColl;
        }

        public IList<ComboTreeViewModel> OrganicaInicial(string id)
        {
            string tipo = "";
            int valor = 0;
            if (!string.IsNullOrWhiteSpace(id))
            {
                var match = Regex.Match(id, @"^([gua])(\d+)$");
                if (match.Success)
                {
                    tipo = match.Groups[1].Value;
                    valor = int.Parse(match.Groups[2].Value);
                }
            }

            Unidad unidad = null;
            Area area = null;
            Gerencia gerencia = null;
            if (tipo == "u")
            {
                unidad = (from u in Unidades where u.Id == valor select u).SingleOrDefault();
                area = (from a in Areas.Include(a => a.Unidades) where a.Id == unidad.AreaId select a).SingleOrDefault();
                gerencia = (from g in Gerencias.Include(a => a.Areas) where g.Id == area.GerenciaId select g).SingleOrDefault();
            }
            else if (tipo == "a")
            {
                area = (from a in Areas.Include(a => a.Unidades) where a.Id == valor select a).SingleOrDefault();
                gerencia = (from g in Gerencias.Include(a => a.Areas) where g.Id == area.GerenciaId select g).SingleOrDefault();
            }
            else if (tipo == "g")
            {
                gerencia = (from g in Gerencias.Include(a => a.Areas) where g.Id == valor select g).SingleOrDefault();
            }

            var gerencias = from g in Gerencias.Include(g => g.Areas).ThenInclude(a => a.Unidades) select g;
            // Todos los datos
            var result = new List<ComboTreeViewModel>();
            foreach (var g in gerencias)
            {
                var item = new ComboTreeViewModel()
                {
                    id = "g" + g.Id,
                    text = g.Nombre,
                    state = (gerencia != null && g.Id == gerencia.Id) ? "open" : "closed",
                    children = new List<ComboTreeViewModel>()
                };
                foreach (var a in g.Areas)
                {
                    var aItem = new ComboTreeViewModel()
                    {
                        id = "a" + a.Id,
                        text = a.Nombre,
                        state = (area != null && area.Id == a.Id) ? "open" : "closed",
                        children = new List<ComboTreeViewModel>()
                    };

                    foreach (var u in a.Unidades)
                    {
                        aItem.children.Add(new ComboTreeViewModel()
                        {
                            id = "u" + u.Id,
                            text = u.Nombre
                        });
                    }

                    item.children.Add(aItem);
                }

                result.Add(item);
            }
            return result;
        }


        public IList<ComboTreeViewModel> ComboCategorias()
        {
            var q = (from c in Categorias
                     orderby c.Orden
                     select c).ToList();
            q.RemoveAll(t => t.CategoriaId != null);

            return ComboCategorias(q);
        }

        private IList<ComboTreeViewModel> ComboCategorias(IList<Categoria> categorias)
        {
            var result = new List<ComboTreeViewModel>();
            foreach (var categoria in categorias)
            {
                var item = new ComboTreeViewModel
                {
                    id = categoria.Id.ToString(),
                    text = categoria.Nombre
                };

                
                if (categoria.Children != null && categoria.Children.Any())
                {
                    item.children = ComboCategorias(categoria.Children.ToList());
                }
                result.Add(item);
            }
            return result;
        }



        public int GetUnidadId(string unidadId)
        {
            if (!string.IsNullOrEmpty(unidadId))
            {
                var match = Regex.Match(unidadId, @"^u(\d+)$");
                if (match.Success)
                {
                    return int.Parse(match.Groups[1].Value);
                }
            }
            return 0;
        }
    }

    public class Noticia
    {
        public int Id { get; set; }
        public string Titulo { get; set; }
        public string Cuerpo { get; set; }
        public DateTime Fecha { get; set; }
        public string Autor { get; set; }
    }

    public class Seccion
    {
        public int Id { get; set; }
        public string Titulo { get; set; }
        public string Cuerpo { get; set; }
    }

    [Serializable]
    public class UsuarioIntranet
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        public int UnidadId { get; set; }
        public bool Activo { get; set; }

        public string Nombres { get; set; }
        public string ApellidoPaterno { get; set; }
        public string ApellidoMaterno { get; set; }
        public string Cargo { get; set; }

        [EmailAddress]
        public string Email { get; set; }

        public bool AnalistaNYP { get; set; }

        public Unidad Unidad { get; set; }
        public ICollection<AutorizacionSolicitud> Autorizador { get; set; }
        public ICollection<UsuarioConsulta> Consultas { get; set; }
        // Notas creadas por el usuario
        public ICollection<Nota> Notas { get; set; }
        // Listas de distribución en las cuales el usuario recibe notificaciones
        public ICollection<UsuariosEnListaDistribucion> UsuariosEnListaDistribucion { get; set; }

        public string NombreCompleto()
        {
            return string.Format("{0} {1} {2}", Nombres, ApellidoPaterno, ApellidoMaterno);
        }
        public bool Revision { get; set; }

        public ICollection<UsuarioNotificado> UsuariosNotificados { get; set; }
    }

    public class Evento
    {
        public int Id { get; set; }
        public UsuarioIntranet Autor { get; set; }
        public DateTime Fecha { get; set; }
        public string Titulo { get; set; }
        public string Campo { get; set; }
        public string ValorAnterior { get; set; }
        public string ValorNuevo { get; set; }
    }


    // Solicitud de Publicación: cuando un usuario solicita que se publique cierta
    // normativa o manual y sea visible en la organización.

    // Certificación: Proceso de validar que una publicación cuenta con toda la información
    // correcta antes de ser validada.

    // Publicación: Los archivos con los manuales / instrucciones / procedimiento / normativa son
    // puestos a disposición de los usuarios del banco.

    // Circular: Documento que informa sobre una nueva publicación.
    [Serializable]
    public class Solicitud
    {
        public long Id { get; set; }
        public string Estado { get; set; }
        //public int AnalistaId { get; set; }
        public UsuarioIntranet Analista { get; set; }

        public UsuarioIntranet Solicitante { get; set; }
        public Unidad Unidad { get; set; }

        public string Tipo { get; set; }
        public string CodigoDocumento { get; set; }
        public string Titulo { get; set; }

        public DateTime? FechaSolicitud { get; set; }
        public DateTime? FechaIngreso { get; set; }
        public DateTime? FechaSolicitudVB { get; set; }

        // Para registrar reenvíos
        public DateTime? FechaSolicitudVB2 { get; set; }
        public DateTime? FechaSolicitudVB3 { get; set; }

        public DateTime? FechaInicioVigencia { get; set; }

        // Datos de la Circular
        [MaxLength(300)]
        public string Impacto { get; set; }
        public string Destino { get; set; }
        public string Materia { get; set; }
        public string Consultas { get; set; }
        public string Objetivo { get; set; }
        [MaxLength(1024)]
        public string FuncionamientoActual { get; set; }
        [MaxLength(1024)]
        public string FuncionamientoNuevo { get; set; }


        public ICollection<CambioEnPublicacion> CambiosEnPublicacion { get; set; }
        public DateTime FechaOK { get; set; }
        public DateTime FechaBorrador { get; set; }
        public ICollection<Evento> Historial { get; set; }
        public ICollection<Nota> Notas { get; set; }
        public ICollection<AutorizacionSolicitud> Autorizadores { get; set; }
        public string Motivo { get; set; }

        public ICollection<UsuarioNotificado> UsuariosNotificados { get; set; }
    }

    public class UsuarioNotificado
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public Solicitud Solicitud { get; set; }
        public UsuarioIntranet Usuario { get; set; }
        [EmailAddress]
        public string Email { get; set; }
    }

    public class ArchivosEnSolicitud
    {
        public long SolicitudId { get; set; }
        public long ArchivoId { get; set; }
    }

    public class DocumentosExistentesEnSolicitud
    {
        public long SolicitudId { get; set; }
        public long DocumentoId { get; set; }
        public Documento Documento { get; set; }
    }

    public class AutorizacionSolicitud
    {
        public int UsuarioIntranetId { get; set; }
        public UsuarioIntranet UsuarioIntranet { get; set; }

        public long SolicitudId { get; set; }
        public Solicitud Solicitud { get; set; }

        public DateTime FechaModificacion { get; set; }
        public string Estado { get; set; }
        public string Observaciones { get; set; }

        public override string ToString()
        {
            return UsuarioIntranetId.ToString();
        }
    }

    [Serializable]
    public class Publicacion
    {
        public long Id { get; set; }
        public string Estado { get; set; }
        // Gerencia
        public string Division { get; set; }
        public string Area { get; set; }
        public string Unidad { get; set; }

        public DateTime FechaPublicacion { get; set; }
        public DateTime InicioVigencia { get; set; }
        public DateTime FinVigencia { get; set; }
        public DateTime FechaCertificacion { get; set; }
        public string Codigo { get; set; }
        public int? ResponsableId { get; set; }
        public UsuarioIntranet Responsable { get; set; }
        public string Intervinientes { get; set; }
        public string Impacto { get; set; }
        public string AreasImpactadas { get; set; }
        public string NombreDocumento { get; set; }
        public string FuncionamientoAnterior { get; set; }
        public string FuncionamientoNuevo { get; set; }
        public string Consultas { get; set; }
        public string Tipo { get; set; }
        public long SolicitudId { get; set; }
        public Solicitud Solicitud { get; set; }
        public Circular Circular { get; set; }
        public ICollection<CategoriasEnPublicacion> CategoriasEnPublicacion { get; set; }
        public ICollection<DocumentosEnPublicacion> DocumentosEnPublicacion { get; set; }
        public ICollection<CambioEnPublicacion> CambiosEnPublicacion { get; set; }
        public string Motivo { get; set; }
        public string NivelAcceso { get; set; }
    }

    public class ProcesoCertificacion
    {
        public int Id { get; set; }
        public long PublicacionId { get; set; }
        public Publicacion Publicacion { get; set; }

        public int ResponsableAnteriorId { get; set; }
        public int ResponsableNuevoId { get; set; }

        public string GerenciaAnterior { get; set; }
        public string AreaAnterior { get; set; }
        public string UnidadAnterior { get; set; }

        public ICollection<Documento> Documentos { get; set; }

        public int AnalistaEjecutorId { get; set; }
        public UsuarioIntranet AnalistaEjecutor { get; set; }
        public DateTime FechaProceso { get; set; }
        public string Comentarios { get; set; }

    }

    /// <summary>
    /// Archivo en sistema local - usado durante la validación de una solicitud.
    /// TODO: cleanup policy
    /// </summary>
    public class Archivo
    {
        public long Id { get; set; }

        [Required]
        public string Tipo { get; set; }

        // Por cada documento individual se debe tener una descripción
        // de sus contenidos.
        [Required]
        public string TituloDocumento { get; set; }

        // Código de Documento - asignado por NYP
        [Required]
        public string CodigoDocumento { get; set; }

        // Nombre físico - nombre en disco
        [Required]
        public string NombreFisico { get; set; }

        // Nombre original del archivo (usado para descargarlo con el mismo nombre)
        [Required]
        public string NombreArchivoOriginal { get; set; }

        public override string ToString()
        {
            return NombreArchivoOriginal;
        }
    }

    public class EventoDocumento
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public string Descripcion { get; set; }
        public UsuarioIntranet Autor { get; set; }
    }

    /// <summary>
    /// Documento en gestor documental.
    /// </summary>
    /// <remarks>
    /// Una publicación puede contener varios documentos, pero sólo aquellos que 
    /// a su vez referencian de vuelta (en el campo Publicacion) son propios. 
    /// </remarks>
    public class Documento
    {
        public long Id { get; set; }
        [Required]
        public string NombreDocumento { get; set; }
        [Required]
        public string NombreArchivo { get; set; }
        [Required]
        public DateTime FechaPublicacion { get; set; }

        // Este campo representa la publicación donde se creó originalmente el documento.
        // Una publicación certificada creará una nueva versión
        [Required]
        public Publicacion Publicacion { get; set; }
        public string Codigo { get; set; }
        public DateTime FechaCertificacion { get; set; }
        public string GestorDocumentalId { get; set; }
        public bool Vigente { get; set; }
        public int Version { get; set; }
        public ICollection<EventoDocumento> Historial { get; set; }
        public int? ProcesoCertificacionId { get; set; }
    }

    public class DocumentosEnPublicacion
    {
        public long PublicacionId { get; set; }
        public Publicacion Publicacion { get; set; }
        public long DocumentoId { get; set; }
        public Documento Documento { get; set; }
        public bool Referencia { get; set; }
        public int? ReferenciaId { get; set; }
    }

    public class CategoriasEnPublicacion
    {
        public long PublicacionId { get; set; }
        public Publicacion Publicacion { get; set; }

        public long CategoriaId { get; set; }
        public Categoria Categoria { get; set; }
    }

    //Restricciones de una publicacion. 
    [Serializable]
    public class ExclusionUsuario
    {
        public int ID { get; set; }
        public int RestriccionRestriccionId { get; set; }
        public int UsuarioIntranetId { get; set; }
        public UsuarioIntranet UsuarioIntranet { get; set; }
    }

    [Serializable]
    public class Restriccion
    {
        public int RestriccionId { get; set; }
        public string DescRegla { get; set; }
        public int GerenciaId { get; set; }
        public Gerencia Gerencia { get; set; }
        public int? AreaId { get; set; }
        public Area Area { get; set; }
        public int? UnidadId { get; set; }
        public Unidad Unidad { get; set; }
        public long? PublicacionId { get; set; }
        public Publicacion Publicacion { get; set; }
        public long SolicitudId { get; set; }
        public Solicitud Solicitud { get; set; }
        public ICollection<ExclusionUsuario> ExclusionUsuario { get; set; }
    }





    public class Categoria
    {
        public long Id { get; set; }
        public long? CategoriaId { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public int Orden { get; set; }
        public ICollection<Categoria> Children { get; set; }
        public ICollection<CategoriasEnPublicacion> CategoriasEnPublicacion { get; set; }
    }

    public class PaginaContenidos
    {
        public int Id { get; set; }
        public string Titulo { get; set; }
        public DateTime FechaPublicacion { get; set; }
        public UsuarioIntranet Autor { get; set; }
        public string Contenido { get; set; }
    }

    [Serializable]
    public class Gerencia
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        public string Nombre { get; set; }
        public ICollection<Area> Areas { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime? FechaEliminacion { get; set; }
        public bool Revision { get; set; }
    }

    [Serializable]
    public class Area
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        public int? GerenciaId { get; set; }
        public Gerencia Gerencia { get; set; }
        public string Nombre { get; set; }
        public ICollection<Unidad> Unidades { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime? FechaEliminacion { get; set; }
        public bool Revision { get; set; }
    }

    [Serializable]
    public class Unidad
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        public int? AreaId { get; set; }
        public string Nombre { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime? FechaEliminacion { get; set; }
        public ICollection<UsuarioIntranet> Usuarios { get; set; }
        public Area Area { get; set; }
        public bool Revision { get; set; }
    }


    public class CambioEnPublicacion
    {
        public int Id { get; set; }
        public string Titulo { get; set; }
        public string Anterior { get; set; }
        public string Nuevo { get; set; }
    }

    public class UsuarioConsulta
    {
        public int UsuarioIntranetId { get; set; }
        public UsuarioIntranet UsuarioIntranet { get; set; }

        public int CircularId { get; set; }
        public Circular Circular { get; set; }
    }

   [Serializable]
    public class Circular
    {
        public int Id { get; set; }
        public DateTime InicioVigencia { get; set; }
        public DateTime FinVigencia { get; set; }

        public string Destino { get; set; }
        public string Materia { get; set; }
        public string Objetivo { get; set; }
        public string Consultas { get; set; }
        public string Responsable { get; set; }
        public string FuncionamientoActual { get; set; }
        public string FuncionamientoNuevo { get; set; }

        public ICollection<CambioEnPublicacion> CambiosEnPublicacion { get; set; }
    }

    public class EstadisticaPublicacion
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public Publicacion Publicacion { get; set; }
    }

    public class EstadisticaDocumento
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public long DocumentoId { get; set; }
        public Documento Documento { get; set; }
    }

    public static class Valores
    {
        public enum PermisoEnSolicitud
        {
            NoAutorizado,
            Solicitante,
            Autorizador,
            Analista
        };

        public enum EstadoAutorizacion
        {
            Ingresado,
            VBEnviado,
            Autorizado,
            Declinado
        }

        public enum EstadoSolicitud
        {
            Nueva,
            EnProceso,
            EsperaVB,
            VBRechazado,
            OK,
            Borrador,
            Publicado,
            Rechazado
        }

        public enum EstadoPublicacion
        {
            Borrador,
            Activo,
            Inactivo
        }

        public static string EstadoAutorizacionString(EstadoAutorizacion estado)
        {
            return Enum.GetName(typeof(EstadoAutorizacion), estado);
        }

        public static string EstadoSolicitudString(EstadoSolicitud estado)
        {
            return Enum.GetName(typeof(EstadoSolicitud), estado);
        }



        public static string RenderEstadoSolicitud(String estado)
        {
            string respuesta = "ERROR: ESTADO DE SOLICITUD NO ENCONTRADO";
            switch (estado)
            {
                case "Nueva":
                    respuesta = "Nueva Solicitud";
                    break;
                case "EnProceso":
                    respuesta = "En Proceso";
                    break;
                case "EsperaVB":
                    respuesta = "A la espera de V°B°";
                    break;
                case "VBRechazado":
                    respuesta = "V°B° Rechazado";
                    break;
                case "OK":
                    respuesta = "Listo para publicar";
                    break;
                case "Borrador":
                    respuesta = "En Borrador";
                    break;
                case "Publicado":
                    respuesta = "Publicada";
                    break;
                case "Rechazado":
                    respuesta = "Rechazada por Analista";
                    break;
                default:
                    break;
            }
            return respuesta;
        }

        public static string EstadoPublicacionString(EstadoPublicacion estado)
        {
            return Enum.GetName(typeof(EstadoPublicacion), estado);
        }

        public static string RenderEstadoPublicacion(String estado)
        {
            string respuesta = "ERROR: ESTADO DE PUBLICACION NO ENCONTRADO";
            switch (estado)
            {
                case "Borrador":
                    respuesta = "Borrador";
                    break;
                case "Activo":
                    respuesta = "Publicada";
                    break;
                case "Inactivo":
                    respuesta = "Inactiva";
                    break;
                default:
                    break;
            }
            return respuesta;

        }


    }


    public class DocumentosMasVisitados
    {
        public long Id { get; set; }
        public string GestorDocumentalId { get; set; }
        public string NombreDocumento { get; set; }
        public string NombreArchivo { get; set; }
        public int Cantidad { get; set; }
    }

    public class PublicacionesMasVisitadas
    {
        public long Id { get; set; }
        public string NombreDocumento { get; set; }
        public DateTime FechaPublicacion { get; set; }
        public string Codigo { get; set; }
        public int Cantidad { get; set; }
    }

    public class ReporteSolicitudItem
    {
        public long Solicitud { get; set; }
        public string Solicitante { get; set; }
        public string Analista { get; set; }
        public string Estado { get; set; }
        public string Unidad { get; set; }
        //public string Restriccion { get; set; }
        [Display(Name = "Área")]
        public string Area { get; set; }
        public string Gerencia { get; set; }
        public string Tipo { get; set; }
        [Display(Name = "Nombre Documento")]
        public string NombreDocumento { get; set; }
        [Display(Name = "Código Doc.")]
        public string CodigoDocumento { get; set; }
        [Display(Name = "Fecha Ingreso")]
        public DateTime? FechaSolicitud { get; set; }
        [Display(Name = "Solicitud 1er VºBº")]
        public DateTime? FechaSolicitudVB { get; set; }
        [Display(Name = "Solicitud 2do VºBº")]
        public DateTime? FechaSolicitudVB2 { get; set; }
        [Display(Name = "Solicitud 3er VºBº")]
        public DateTime? FechaSolicitudVB3 { get; set; }
        [Display(Name = "Fecha OK V°B°")]
        public DateTime? FechaAceptacionVB { get; set; }
        [Display(Name = "Fecha Borrador")]
        public DateTime? FechaBorrador { get; set; }
        public string Destino { get; set; }
        public string Materia { get; set; }
    }

    public class ReportePublicacionItem
    {
        public long Id { get; set; }
        public int? Circular { get; set; }
        public string Estado { get; set; }
        [Display(Name = "Analista Encargado")]
        public string Analista { get; set; }
        public string Gerencia { get; set; }
        public string Area { get; set; }
        public string Unidad { get; set; }
        [Display(Name = "Fecha Inicio Vigencia")]
        public string FechaInicioVigencia { get; set; }
        [Display(Name = "FechaPublicación")]
        public string FechaPublicacion { get; set; }
        [Display(Name = "Fecha Fin Vigencia")]
        public string FinVigencia { get; set; }
        [Display(Name = "Nombre Documento")]
        public string NombreDocumento { get; set; }
        [Display(Name = "Código")]
        public string Codigo { get; set; }
        [Display(Name = "Versión Documento")]
        public int VersionDocumento { get; set; }
        public string Responsable { get; set; }
        public string Intervinientes { get; set; }
        public string Impacto { get; set; }
        public string AreasImpactadas { get; set; }
        public string Materia { get; set; }
        [Display(Name = "Funcionamiento Anterior")]
        public string FuncionamientoAnterior { get; set; }
        [Display(Name = "Funcionamiento Nuevo")]
        public string FuncionamientoNuevo { get; set; }
        public string Consultas { get; set; }
        public string Tipo { get; set; }
        public long Solicitud { get; set; }
        public string CategoriasEnPublicacion { get; set; }
        public string DocumentosEnPublicacion { get; set; }
       // public string CambiosEnPublicacion { get; set; }
        public string Restricciones { get; set; }
    }

    public class ReporteCertificacionItem
    {
        public long Id { get; set; }
        public string AnalistaEjecutor { get; set; }
        public string FechaProceso { get; set; }
        public string FechaCertificacion { get; set; }
        public string Codigo { get; set; }
        public string Tipo { get; set; }
        public string NombreDocumento { get; set; }
        public int Version { get; set; }
        public string FechaCreacion { get; set; }
        public string FechaPublicacion { get; set; }
        public string GerenciaAnterior { get; set; }
        public string AreaAnterior { get; set; }
        public string UnidadAnterior { get; set; }
        public string Gerencia{ get; set; }
        public string Area{ get; set; }
        public string Unidad { get; set; }
        public string ResponsableAnterior { get; set; }
        public string ResponsableActual { get; set; }
        public string Comentarios { get; set; }
    }

    public class CodigoGlosa
    {
        public int Id { get; set; }
        public string CodigoDocumento { get; set; }
        public string NombreDocumento { get; set; }
        public bool Vigente { get; set; }
    }
}
