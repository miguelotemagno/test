﻿using Microsoft.Data.Entity;
using Microsoft.Data.Entity.Infrastructure;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;

namespace nyp.Organica
{
    public static class DataReaderExtensions
    {
        public static List<T> MapToList<T>(this System.Data.Common.DbDataReader dr) where T : new()
        {
            if (dr != null && dr.HasRows)
            {
                var entity = typeof(T);
                var entities = new List<T>();
                var propDict = new Dictionary<string, PropertyInfo>();
                var props = entity.GetProperties(BindingFlags.Instance | BindingFlags.Public);
                propDict = props.ToDictionary(p => p.Name.ToUpper(), p => p);

                while (dr.Read())
                {
                    T newObject = new T();
                    for (int index = 0; index < dr.FieldCount; index++)
                    {
                        if (propDict.ContainsKey(dr.GetName(index).ToUpper()))
                        {
                            var info = propDict[dr.GetName(index).ToUpper()];
                            if ((info != null) && info.CanWrite)
                            {
                                var val = dr.GetValue(index);
                                info.SetValue(newObject, (val == System.DBNull.Value) ? null : val, null);
                            }
                        }
                    }
                    entities.Add(newObject);
                }
                return entities;
            }
            return null;
        }
    }

    public class RegistroOrganica
    {

        [Column("CodGerencia")]
        public long? CodGerencia { get; set; }
        [Column("GlsGerencia")]
        public string GlsGerencia { get; set; }
        [Column("CodArea")]
        public long? CodArea { get; set; }
        [Column("GlsArea")]
        public string GlsArea { get; set; }

        [Key]
        [Column("Rut")]
        public string Rut { get; set; }

        [Column("Nombres")]
        public string Nombres { get; set; }
        [Column("ApePaterno")]
        public string ApePaterno { get; set; }
        [Column("ApeMaterno")]
        public string ApeMaterno { get; set; }
        [Column("Correo")]
        public string Correo { get; set; }
        [Column("Cargo")]
        public string Cargo { get; set; }


        [Column("CodUnidadRelacional")]
        public long? CodUnidadRelacional { get; set; }
        [Column("UnidadRelacional")]
        public string UnidadRelacional { get; set; }
        [Column("unidad")]
        public string unidad { get; set; }
    }

    public class OrganicaGerencia
    {
        public long Id { get; set; }
        public string Nombre { get; set; }
    }

    public class OrganicaArea
    {
        public long Id { get; set; }
        public string Nombre { get; set; }
        public long OrganicaGerenciaId { get; set; }
    }

    public class OrganicaUnidad {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public int OrganicaAreaId { get; set; }
    }

    public class OrganicaUsuarioIntranet
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        public int OrganicaUnidadId { get; set; }
        public bool Activo { get; set; }
        public string Nombres { get; set; }
        public string ApellidoPaterno { get; set; }
        public string ApellidoMaterno { get; set; }
        public string Cargo { get; set; }
        public string Email { get; set; }
        public bool AnalistaNYP { get; set; }
        public OrganicaUnidad OrganicaUnidad { get; set; }
    }

    public class OrganicaDbContext : DbContext
    {

        public OrganicaDbContext(DbContextOptions options)
        : base(options)
        { }
        public DbSet<RegistroOrganica> Organica { get; set; }
        public DbSet<OrganicaGerencia> OrganicaGerencias { get; set; }
        public DbSet<OrganicaArea> OrganicaAreas { get; set; }
        public DbSet<OrganicaUnidad> OrganicaUnidad { get; set; }
        public DbSet<OrganicaUsuarioIntranet> OrganicaUsuarioIntranet { get; set; }
        public List<RegistroOrganica> GetOrganica()
        {
            string errorResult = "";

            Database.OpenConnection();
            var dbConn = Database.GetDbConnection();
            DbCommand cmd = dbConn.CreateCommand();
            cmd.CommandText = "BD_RRHH_NYP.dbo.sp_prc_ApliNormaProcedimiento";
            cmd.CommandType = CommandType.StoredProcedure;
            var error = new SqlParameter("p_error", 0) { Direction = ParameterDirection.Output };
            cmd.Parameters.Add(error);

            List<RegistroOrganica> results;
            using (var reader = cmd.ExecuteReader())
            {
                results = reader.MapToList<RegistroOrganica>();
            }
            errorResult = (error.Value == null) ? "" : Convert.ToString(error.Value);

            return results;
        }
    }
}
