﻿using Microsoft.Framework.OptionsModel;
using nyp.GestorDocumental.Client;
using nyp.GestorDocumental.Service;
using System;
using System.Collections.Generic;
using System.IO;
using System.ServiceModel;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.XPath;

namespace nyp.GestorDocumental.IBMContentManager
{
    public class IBMContentManagerWebServiceOptions
    {
        public string Hostname { get; set; }
        public int Port { get; set; }
        public string ICMServerName { get; set; }
        public string ICMUsername { get; set; }
        public string ICMPassword { get; set; }
    }

    public class PublicacionUri : IPublicacionUri
    {
        public DatosPublicacion DatosPublicacion { get; set; }
        public Uri Uri { get; set; }
    }

    public class ResultadoAlmacenar : IResultadoAlmacenar
    {
        public string Id { get; set; }
        public bool Ok { get; set; }
        public string Mensaje { get; set; }
        public Uri Uri { get; set; }
    }

    public class IBMContentManagerWebService : IGestorDocumental
    {
        CMWebServicePortTypeClient Client = null;
        AuthenticationData AuthenticationData = null;
        Uri Host = null;

        public IBMContentManagerWebService(IOptions<IBMContentManagerWebServiceOptions> options)
        {
            // config.json
            var url = new UriBuilder("http://localhost/CMBSpecificWebService/services/CMWebService");
            if (!string.IsNullOrEmpty(options.Value.Hostname))
                url.Host = options.Value.Hostname;

            if (options.Value.Port > 0)
                url.Port = options.Value.Port;

            Host = new Uri(url.ToString());
            BasicHttpBinding basicbinding = new BasicHttpBinding();
            basicbinding.SendTimeout = TimeSpan.FromSeconds(30);
            basicbinding.OpenTimeout = TimeSpan.FromSeconds(10);
            // basicbinding.MessageEncoding = WSMessageEncoding.Mtom;
            Client = new CMWebServicePortTypeClient(basicbinding,
                new EndpointAddress(Host));

            AuthenticationData = new AuthenticationData()
            {
                ServerDef = new ServerDef()
                {
                    ServerName = options.Value.ICMServerName,
                    ServerType = ServerType.ICM
                },
                LoginData = new AuthenticationDataLoginData()
                {
                    UserID = options.Value.ICMUsername,
                    Password = options.Value.ICMPassword
                }
            };
        }

        public IList<IPublicacionUri> Search(int? CategoriaId, string searchText)
        {
            var ret = new List<IPublicacionUri>();
            var results = getSearchResults(searchText);
            for (int i = 0; i < results.count; i++)
            {
                Item item = results.Item[i];
                XmlDocument doc = new XmlDocument();
                var n = doc.ImportNode(item.ItemXML, true);
                doc.AppendChild(n);
                var retrieved = new NYPPublicacion();
                var xS = CreateXmlSerializer();
                Stream s = GenerateStreamFromString(doc.OuterXml);
                var pub = (NYPPublicacion)xS.Deserialize(s);
                ret.Add(CrearDesdeCMItemType(pub));
            }
            return ret;
        }

        public IResultadoAlmacenar Almacenar(DatosPublicacion datosPublicacion, string nombreArchivo, string stream)
        {
            var xS = CreateXmlSerializer();
            var publicacion = new NYPPublicacion()
            {
                NYParchivo = datosPublicacion.NombreFisico,
                NYPid = datosPublicacion.Id.ToString(),
                NYPfechacm = datosPublicacion.Fecha.ToString(),
                NYPcodigo = datosPublicacion.CodigoDocumento,
                NYPtitulo = datosPublicacion.Descripcion,
                ICMBASE = new ICMBASE[]
                {
                    new ICMBASE
                    {
                        resourceObject = new LobObjectType()
                        {
                            label = new LobObjectTypeLabel()
                            {
                                name = "adjunto",
                            },
                            MIMEType = GetMimeMapping(datosPublicacion.NombreFisico),
                            originalFileName = datosPublicacion.NombreFisico
                        }
                    }
                }
            };

            XmlDocument payload = new XmlDocument();
            XPathNavigator nav = payload.CreateNavigator();
            using (XmlWriter w = nav.AppendChild())
            {
                xS.Serialize(w, publicacion);
            }

            var request = new CreateItemRequest()
            {
                AuthenticationData = AuthenticationData,
                Item = new CreateItemRequestItem()
                {
                    ItemXML = payload.DocumentElement
                }
            };

            var attachment = new MTOMAttachment()
            {
                MimeType = GetMimeMapping(datosPublicacion.NombreFisico),
                ID = "adjunto"
            };
            using (var ms = new MemoryStream())
            {
                //stream.CopyTo(ms);
                ms.Position = 0;
                attachment.Value = ms.ToArray();
            }

            request.mtomRef = new MTOMAttachment[] {
                attachment
            };

            var reply = Client.CreateItem(request);

            var result = new ResultadoAlmacenar();

            if (reply.RequestStatus.success == true)
            {
                result.Ok = true;
                result.Uri = new Uri(reply.Item.URI);
            }
            else
            {
                result.Ok = false;
                result.Mensaje = reply.RequestStatus.ErrorData[0].errorMessage;
            }
            return result;
        }


        public DocumentoEnGestor GetDocumento(string idDocumento)
        {
            // create a search request
            RunQueryRequest request = new RunQueryRequest();
            // set the request's authentication data
            request.AuthenticationData = AuthenticationData;
            // set the search query for the request
            request.QueryCriteria = new QueryCriteria();
            // set the query string to search for all policies
            request.QueryCriteria.QueryString = "/NYPid[ . LIKE \"%\"]";
            request.maxResults = "0";
            request.version = "latest-version(.)";

            // set the retrieve option to be content which specifies
            // that information regarding the parts will be returned
            // as well as meta-data
            request.retrieveOption = RunQueryRequestRetrieveOption.IDONLY;

            // set the content option to return parts
            // as resource manager urls
            request.contentOption = RunQueryRequestContentOption.URL;

            // now call the request
            RunQueryReply reply = Client.RunQuery(request);
            // check to see if operation was successful
            if (reply.RequestStatus.success == true)
            {
                if (reply.ResultSet.count > 0)
                {
                    var result = new DocumentoEnGestor
                    {
                        Id = reply.ResultSet.Item[0].URI,
                    };
                    return result;
                }
            }
            return null;
        }


        #region Private
        private IPublicacionUri CrearDesdeCMItemType(NYPPublicacion src)
        {
            Uri URL = null;
            string nombreFisico = "";
            if (src.ICMBASE != null && src.ICMBASE[0].resourceObject != null)
            {
                var Uri = new UriBuilder(src.ICMBASE[0].resourceObject.URL.value);
                Uri.Host = Host.Host;
                URL = new Uri(Uri.ToString());
                nombreFisico = src.ICMBASE[0].resourceObject.originalFileName;
            }
            else
            {
                nombreFisico = src.NYParchivo;
            }

            return new PublicacionUri()
            {
                DatosPublicacion = new DatosPublicacion()
                {
                    Id = Convert.ToInt32(src.NYPid),
                    Tipo = "", // TODO
                    CodigoDocumento = src.NYPcodigo,
                    NombreFisico = nombreFisico,
                    Fecha = src.properties.lastChangeTime.value,
                    Descripcion = src.NYPtitulo // src.nyp
                },
                Uri = URL
            };
        }

        private static Stream GenerateStreamFromString(string s)
        {
            MemoryStream stream = new MemoryStream();
            StreamWriter writer = new StreamWriter(stream);
            writer.Write(s);
            writer.Flush();
            stream.Position = 0;
            return stream;
        }

        private RunQueryReplyResultSet getSearchResults(string searchTerm)
        {
            var query = new RunQueryRequest()
            {
                AuthenticationData = AuthenticationData,
                QueryCriteria = new QueryCriteria()
                {
                    QueryString = string.Format("/NYPPublicacion[@NYPcodigo LIKE \"{0}\"]", searchTerm),
                    queryType = "XPATH"
                },
                version = "LATEST_VERSION",
                retrieveOption = RunQueryRequestRetrieveOption.CONTENT,
                contentOption = RunQueryRequestContentOption.URL,
                maxResults = "10"
            };
            var queryReply = Client.RunQuery(query);

            return queryReply.ResultSet;
        }

        private string GetMimeMapping(string fileName)
        {
            var mimeMappings = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { ".doc", "application/msword" },
                { ".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document" },
                { ".pdf", "application/pdf" },
                { ".pps", "application/vnd.ms-powerpoint" },
                { ".ppsx", "application/vnd.openxmlformats-officedocument.presentationml.slideshow" },
                { ".ppt", "application/vnd.ms-powerpoint" },
                { ".pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation" },
                { ".rtf", "application/rtf" },
                { ".txt", "text/plain" },
                { ".vsd", "application/vnd.visio" },
                { ".vss", "application/vnd.visio" },
                { ".vst", "application/vnd.visio" },
                { ".vsto", "application/x-ms-vsto" },
                { ".vsw", "application/vnd.visio" },
                { ".vsx", "application/vnd.visio" },
                { ".vtx", "application/vnd.visio" },
                { ".xls", "application/vnd.ms-excel" },
                { ".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"  }
            };
            string result;
            string extension = Path.GetExtension(fileName);
            if (extension == null)
            {
                return null;
            }
            if (mimeMappings.TryGetValue(extension, out result))
            {
                return result;
            }
            return null;
        }

        private XmlSerializer CreateXmlSerializer()
        {
            return new XmlSerializer(typeof(NYPPublicacion),
                                new XmlRootAttribute("NYPPublicacion") { Namespace = "http://www.ibm.com/xmlns/db2/cm/beans/1.0/schema" });
        }

        public DocumentoEnGestor GetDocumentoPorNombre(string nombreArchivo)
        {
            throw new NotImplementedException();
        }


        #endregion
    }
}
