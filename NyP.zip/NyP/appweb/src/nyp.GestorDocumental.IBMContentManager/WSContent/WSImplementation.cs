﻿using Microsoft.Framework.OptionsModel;
using Microsoft.AspNet.Hosting;
using nyp.GestorDocumental.Service;
using nyp.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.ServiceModel;
using nyp.GestorDocumental.Client;
using Newtonsoft.Json.Linq;

namespace nyp.GestorDocumental.WSContent
{ 


    public class WSBancoOptions
    {
        public string url { get; set; }
    }

    public class WSBancoRespuestaAlmacenar : IResultadoAlmacenar
    {
        public string Id { get; set; }
        public string Mensaje { get; set; }
        public bool Ok { get; set; }
        public Uri Uri { get; set; }
    }

    public class WSRespuestaBusqueda : IPublicacionUri
    {
        public DatosPublicacion DatosPublicacion { get; set; }
        public Uri Uri { get; set; }
    }

    public class WSImplementation : IGestorDocumental
    {
        private INYPContext dbContext;
        private IHostingEnvironment HostingEnvironment;
        private WSBancoOptions opciones; 

        public WSImplementation(INYPContext context, IHostingEnvironment hostingEnvironment)
        {
            dbContext = context;
            HostingEnvironment = hostingEnvironment;
            JObject o1 = JObject.Parse(File.ReadAllText(@"../../nyp/config.json"));
            opciones = new WSBancoOptions();
            opciones.url = (string)(o1["GestorDocumental"]["WSContent"]["url"]);
        }




        public IResultadoAlmacenar Almacenar(DatosPublicacion datosPublicacion, string nombreArchivo, string contenidoBase64)
        {
            WSBancoRespuestaAlmacenar answ = new WSBancoRespuestaAlmacenar();
            
            

            RespuestaDTO respuesta; 
            try {
                ArchivoServiceService wsbanco = new ArchivoServiceService(opciones.url);
                respuesta = wsbanco.guardarArchivo(new ArchivoCMDTO() {
                    guid = nombreArchivo,
                    name = datosPublicacion.NombreFisico
                }, contenidoBase64);
                answ.Mensaje = respuesta.mensaje_error;
                answ.Id = nombreArchivo;

                if (respuesta.codigo_error == "000")
                {
                    answ.Id = nombreArchivo;
                    answ.Ok = true;
                } else
                {
                    answ.Id = respuesta.codigo_error;
                    answ.Mensaje = respuesta.mensaje_error;
                    answ.Ok = false; 

                }

                return answ;
            }
            catch (Exception e)
            {
                answ.Mensaje = e.Message;
                answ.Id = "ERROR";
                answ.Ok = false; 
            }
            
            
            return answ;
        }

        private string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        private byte[] Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            //return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
            return base64EncodedBytes;
        }

        public DocumentoEnGestor GetDocumento(string idDocumento)
        {
            try
            {
                byte[] contenidoArchivo;
                ArchivoServiceService wsbanco = new ArchivoServiceService(opciones.url);
                RespBusqueda respuestaBusqueda = wsbanco.buscarArchivo(idDocumento);
                contenidoArchivo = Base64Decode(respuestaBusqueda.base64);
                if (respuestaBusqueda.error.codigo_error != "000")
                {
                    Console.Write(respuestaBusqueda.error.codigo_error + " - " + respuestaBusqueda.error.mensaje_error);
                    return null; 
                }
                return GetDocumento(contenidoArchivo, idDocumento);
            }catch (Exception ex)
            {
                return null; 
            }

        }

        public DocumentoEnGestor GetDocumentoPorNombre(string nombreArchivo)
        {
            throw new NotImplementedException();
        }

        public IList<IPublicacionUri> Search(int? CategoriaId, string searchText)
        {
            IList<IPublicacionUri> listaResultado = new List<IPublicacionUri>();

            try
            {
                
                ArchivoServiceService wsbanco = new ArchivoServiceService(opciones.url);
                String respuestaBusqueda = wsbanco.buscarTextoContenido(searchText);
                /*
                if (respuestaBusqueda.error.codigo_error != "000" && respuestaBusqueda.error.codigo_error != "001")
                {
                    Console.Write(respuestaBusqueda.error.codigo_error + " - " + respuestaBusqueda.error.mensaje_error);
                    return null;
                }
                foreach(ArchivoCMDTO arch in  respuestaBusqueda.listFiles)
                {
                    DatosPublicacion aux = new DatosPublicacion();
                    aux.Descripcion = arch.name;
                    aux.CodigoDocumento = arch.guid;
                    
                    WSRespuestaBusqueda documento = new WSRespuestaBusqueda();
                    documento.DatosPublicacion = aux;
                    listaResultado.Add(documento);
                }*/

                return listaResultado; 
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        private DocumentoEnGestor GetDocumento(byte[] streamFile, string id)
        {

            var doc = (from d in dbContext.Documentos
                       where d.GestorDocumentalId == id
                       select d).FirstOrDefault();

            if (doc != null)
            {
                try
                {
                    byte[] fileBytes = streamFile;//System.Text.Encoding.UTF8.GetBytes(streamFile);
                    if (fileBytes != null)
                    {
                        return new DocumentoEnGestor()
                        {
                            Id = doc.GestorDocumentalId,
                            MimeType = "application/octet-stream",
                            Nombre = doc.NombreArchivo,
                            Contenidos = fileBytes
                        };
                    }
                }
                catch
                {

                }
            }
            return null;
        }
        private string GetPhysicalFilename(string fileName)
        {
            return Path.Combine(HostingEnvironment.WebRootPath, "tmp-upload-zone", fileName);
        }

    }

}
