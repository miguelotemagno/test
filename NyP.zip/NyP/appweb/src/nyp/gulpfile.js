﻿/// <binding BeforeBuild='min' Clean='clean' />

var gulp = require("gulp"),
    gulputil = require('gulp-util'),
    rimraf = require("rimraf"),
    concat = require("gulp-concat"),
    cssmin = require("gulp-cssmin"),
    uglify = require("gulp-uglify"),
    project = require("./project.json"),
    less = require("gulp-less")
    ;

var paths = {
    webroot: "./" + project.webroot + "/"
};

paths.js = paths.webroot + "js/**/*.js";
paths.minJs = paths.webroot + "js/**/*.min.js";
paths.css = paths.webroot + "css/**/*.css";
paths.minCss = paths.webroot + "css/**/*.min.css";
paths.concatJsDest = paths.webroot + "js/site.min.js";
paths.concatCssDest = paths.webroot + "css/site.min.css";

paths.editorSkin = paths.webroot + "editorskin";

gulp.task("clean:js", function (cb) {
    rimraf(paths.concatJsDest, cb);
});

gulp.task("clean:css", function (cb) {
    rimraf(paths.concatCssDest, cb);
});

gulp.task("clean:editorskin", function (cb) {
    rimraf(paths.editorSkin, cb);
});

gulp.task("clean", ["clean:js", "clean:css", "clean:editorskin"]);

gulp.task("ckeditor", function () {
    // Skin customizado para ckeditor
    gulp.src("Styles/ckeditor/*.less")
        .pipe(less({
            paths: [
                '.'
            ]
        }))
        .pipe(gulp.dest(paths.editorSkin))

    gulp.src("Styles/ckeditor/**/*.{png,js}")
          .pipe(gulp.dest(paths.editorSkin));
});

gulp.task("less", function () {
    gulp.src("Styles/*.less")
        .pipe(less({
            paths: [
                '.',
                 paths.webroot + 'lib/metro/less'
            ]
        }))
        .pipe(gulp.dest(paths.webroot + 'css/styles'));
})

gulp.task("min:js", function () {
    gulp.src([paths.js, "!" + paths.minJs], { base: "." })
        .pipe(concat(paths.concatJsDest))
        .pipe(uglify().on('error', gulputil.log))
        .pipe(gulp.dest("."));
    gulp.src("Scripts/*.js")
        .pipe(gulp.dest(paths.webroot + 'js'))
});

gulp.task("min:css", function () {
    gulp.src([paths.css, "!" + paths.minCss])
        .pipe(concat(paths.concatCssDest))
        .pipe(cssmin())
        .pipe(gulp.dest("."));
});

gulp.task("min", ["less", "ckeditor", "min:js", "min:css"]);

