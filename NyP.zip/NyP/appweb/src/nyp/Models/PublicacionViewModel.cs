﻿using nyp.DataModels;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace nyp.Models
{
    // Categorias y sus hijos
    public class CategoriasViewModel
    {
        public long id { get; set; }
        public string Name { get; set; }
        public IList<CategoriasViewModel> Children { get; set; }
    }

    // Categoría sola
    public class CategoriaViewModel
    {
        public long id { get; set; }
        public string Name { get; set; }
    }


    public class NuevaPublicacionViewModel
    {
        [Required]
        public long SolicitudId { get; set; }
        [Required]
        public DateTime FechaPublicacion { get; set; }
        [Required]
        public DateTime FechaInicioVigencia { get; set; }
        [Required]
        public DateTime FechaCertificacion { get; set; }

        public List<long> Categorias { get; set; }
        public SolicitudViewModel Solicitud { get; set; }

        public String MyProperty { get; set; }
        public String NivelAcceso { get; set; }
    }

    public class EditarPublicacionViewModel
    {
        [Required]
        public long Id { get; set; }
        // [Required]
        public string Estado { get; set; }

        public List<long> Categorias { get; set; }

        public List<List<CategoriasViewModel>> CategoriasExistentes { get; set; }
    }


    public class PublicacionViewModel
    {
        public long Id { get; set; }
        [Required]
        public string Nombre { get; set; }
        [Required]
        public string Tipo { get; set; }
        [Required]
        public string Destino { get; set; }
        public string Estado { get; set; }
        public DateTime Fecha { get; set; }
        public DateTime FechaCertiicacion { get; set; }
        public SolicitudViewModel Solicitud { get; set; }
        public IQueryable<DocumentoViewModel> Documentos { get; set; }
        public List<ArchivoViewModel> Archivos { get; set; }
        public List<List<CategoriasViewModel>> Categorias { get; internal set; }
        public int NumeroCircular { get; internal set; }
        public string Objetivo { get; set; }
        public string Codigo { get; set; }
        public string Motivo { get; set; }
        public string NivelAcceso { get; set; }
        public long SolicitudId { get; set; }
    }

    public class PublicarBorradorViewModel
    {
        [Required]
        public long Id { get; set; }
        [Required]
        public int ListaDistribucionId { get; set; }
        public ICollection<string> UsuariosNotificadosEmails { get; set; } = new List<string>();
    }

    public class DocumentoViewModel
    {
        public long Id { get; set; }
        public string GestorDocumentalId { get; set; }
        public string Filename { get; set; }
        public string Titulo { get; set; }
        public bool Visible { get; set; }
        public int Version { get; set; }
        public bool Certificado { get; set; }
        public bool Referencia { get; set; }
    }

    public class BusquedaViewModel
    {
        public BusquedaViewModel()
        {
            Listado = new ListaPublicacionesViewModel();
        }
        public string Terminos { get; set; }
        public string Area { get; set; }
        public string Tipo { get; set; }
        public string TargetTipo { get; set; }
        public string TargetTerminos { get; set; }
        public bool buscarContenido { get; set; }

        public ListaPublicacionesViewModel Listado { get; set; }
    }

    public class BandejaPublicaciones
    {
        public string Action { get; set; }
        public int Page { get; set; }
        public string Controller { get; set; }
        public string Titulo { get; set; }
        public IEnumerable<Publicacion> Publicaciones { get; set; }
        public IEnumerable<PublicacionesCertificacion> PublicacionesCertificacion { get; set; }
    }


    public class PublicacionesCertificacion
    {
        public long PublicacionId { get; set; }
        public string TituloDocumento { get; set; }
        public DateTime FechaPublicacion { get; set; }
        public DateTime FechaCertificacion { get; set; }
        public Circular Circular { get; set; }


    }

    public class SuspenderPublicacionViewModel
    {
        public long PublicacionId { get; set; }
        public string Motivo { get; set; }
    }

    public class SuspenderDocumentoViewModel
    {
        public long DocumentoId { get; set; }
        public long PublicacionId { get; set; }
        public string Motivo { get; set; }
    }


}
