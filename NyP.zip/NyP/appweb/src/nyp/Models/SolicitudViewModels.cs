﻿using Microsoft.AspNet.Http;
using nyp.DataModels;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace nyp.Models
{
    public class MensajeErrorViewModel
    {
        public MensajeErrorViewModel()
        {
            Errores = new List<string>();
        }
        public string Mensaje { get; set; }
        public string Titulo { get; set; }
        public IList<string> Errores { get; set; }
    }

    public class ArchivoViewModel
    {
        public long Id { get; set; }
        public string Descripcion { get; set; }
        public string NombreFisico { get; set; }
        public string NombreOriginal { get; set; }
        public bool Reemplazo { get; set; }
        public string NombreDocumento { get; set; }
        public int Version { get; set; }
    }

    public class AutorizacionSolicitudViewModel
    {
        [Required]
        public long SolicitudId { get; set; }

        [Required]
        public string Estado { get; set; }

        public string Observaciones { get; set; }

        public string TipoEvento { get; set; }
    }

    public class AdjuntarArchivoViewModel
    {
        [Required]
        public long SolicitudId { get; set; }
        [Required]
        [Display(Description = "Nombre del documento")]
        public string NombreDocumento { get; set; }
        [Required]
        [Display(Description = "Descripción")]
        public string Descripcion { get; set; }
        [Required]
        [Display(Description = "Código")]
        public string Codigo { get; set; }
        [Required]
        [Display(Description = "Documento a adjuntar")]
        public IFormFile ArchivoAdjunto { get; set; }


        public SolicitudViewModel Solicitud { get; set; }
    }

    public class AdjuntarArchivoExistenteViewModel
    {
        [Required]
        public long SolicitudId { get; set; }
        [Required]
        public long DocumentoId { get; set; }
    }

    public class ApplicationUserJSONViewModel
    {
        public int id { get; set; }
        public string nombre { get; set; }
        public string cargo { get; set; }
    }

    public class ApplicationOpenUserJSONViewModel
    {
        public string id { get; set; }
        public string nombre { get; set; }
        public string cargo { get; set; }
        public string email { get; set; }
    }

    public class ApplicationUserViewModel
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Cargo { get; set; }
        public string Email { get; set; }

        public override string ToString()
        {
            return Nombre;
        }
    }

    public class ApplicationOpenUserViewModel
    {
        public string Id { get; set; }
        public string Nombre { get; set; }
        public string Cargo { get; set; }
        public string Email { get; set; }

        public override string ToString()
        {
            return Nombre;
        }
    }

    public class EstadoAutorizacionViewModel
    {
        public ApplicationUserViewModel Interviniente { get; set; }
        public AutorizacionSolicitudViewModel Autorizacion { get; set; }
    }

    public class SolicitudViewModel
    {
        [Display(Name = "Número de Solicitud")]
        public long Id { get; set; }

        public ApplicationUserViewModel Solicitante { get; set; }
        public ApplicationUserViewModel Analista { get; set; }
        public Unidad Unidad { get; set; }

        public IList<EstadoAutorizacionViewModel> Autorizadores { get; set; } = new List<EstadoAutorizacionViewModel>();
        //public IList<EstadoAutorizacionViewModel> UsuariosNotificados { get; set; } = new List<EstadoAutorizacionViewModel>();

        public int? SolicitanteId { get; set; }
        public int? AnalistaId { get; set; }
        public ICollection<int> AutorizadoresId { get; set; } = new List<int>();
        public ICollection<string> UsuariosNotificadosEmails { get; set; } = new List<string>();

        [Display(Name = "Fecha de Envío de Solicitud")]
        public DateTime? FechaSolicitud { get; set; }

        [Display(Name = "Fecha de Ingreso al sistema")]
        public DateTime? FechaIngreso { get; set; }

        [Display(Name = "Fecha de Solicitud Vº Bº")]
        public DateTime? FechaSolicitudVB { get; set; }
        public DateTime? FechaSolicitudVB2 { get; set; }
        public DateTime? FechaSolicitudVB3 { get; set; }

        [Display(Name = "Fecha de Publicación")]
        public DateTime? FechaPublicacion { get; set; }

        [Display(Name = "Fecha de Inicio de Vigencia")]
        public DateTime? FechaInicioVigencia { get; set; }

        [Required]
        [Display(Name = "Departamento o Unidad")]
        public string UnidadId { get; set; }

        [Required(ErrorMessage = "Especifique tipo de documento")]
        [Display(Name = "Tipo de Documento")]
        public string TipoDocumento { get; set; }

        [Display(Name = "Código de Documento")]
        public string CodigoDocumento { get; set; }

        [Required(ErrorMessage = "Especifique título del documento")]
        [Display(Name = "Título")]
        public string Titulo { get; set; }

        [StringLength(300, ErrorMessage = "Impacto no puede tener más de 300 caracteres")]
        [Display(Description = "Impacto / Implicancia")]
        public string Impacto { get; set; }

        [Display(Description = "Documento a adjuntar")]
        public IFormFile ArchivoAdjunto { get; set; }

        [Required(ErrorMessage = "Especifique Funcionamiento Actual")]
        [MaxLength(2024, ErrorMessage = "Funcionamiento Actual debe tener menos de 2000 caracteres")]
        public string FuncionamientoActual { get; set; }

        [Required(ErrorMessage = "Especifique Funcionamiento Nuevo")]
        [MaxLength(2024, ErrorMessage = "Funcionamiento Nuevo debe tener menos de 2000 caracteres")]
        public string FuncionamientoNuevo { get; set; }

        public string Motivo { get; set; }


        public ICollection<ArchivoViewModel> ArchivosAdjuntos { get; set; }
        public ICollection<ApplicationUserViewModel> Analistas { get; set; }
        public ICollection<ApplicationOpenUserViewModel> UsuariosNotificados { get; set; }

        public Valores.PermisoEnSolicitud PermisosParaUsuario(int RUT)
        {
            Valores.PermisoEnSolicitud permisoUsuario = Valores.PermisoEnSolicitud.NoAutorizado;
            if (RUT > 0)
            {
                if (Solicitante != null && Solicitante.Id == RUT)
                {
                    permisoUsuario = Valores.PermisoEnSolicitud.Solicitante;
                }
                else if (Autorizadores != null)
                {
                    var ids = (from a in Autorizadores
                               select a.Interviniente.Id).ToArray();
                    if (ids.Contains(RUT))
                    {
                        permisoUsuario = Valores.PermisoEnSolicitud.Autorizador;
                    }
                }
            }
            return permisoUsuario;
        }

        public string Estado { get; set; }

        // Datos Circular
        [Display(Name = "Destino / Áreas impactadas")]
        public string Destino { get; set; }
        public string Materia { get; set; }
        [Display(Name = "La presente tiene por objeto informar...")]
        public string Objetivo { get; set; }
        public string Consultas { get; set; }
        public string Intervinientes { get; set; }

        public Area Area { get; set; }
        public Gerencia Gerencia { get; set; }

    }





    public class ListadoSolicitudesViewModel
    {
        public string ActionName { get; set; }
        public int Page { get; set; }
        public IEnumerable<Solicitud> Solicitudes { get; set; }
    }

    public class AnularSolicitudViewModel
    {
        [Required]
        public string Motivo { get; set; }
        [Required]
        public long SolicitudId { get; set; }
    }

    public class AgregarNotaViewModel
    {
        [Required]
        public long? SolicitudId { get; set; }
        [Required]
        public string Texto { get; set; }
        public bool Privado { get; set; }
    }

    public class EliminarDocumentoViewModel
    {
        [Required(ErrorMessage = "Documento no especificado")]
        public long DocumentoId { get; set; }
        [Required(ErrorMessage = "Solicitud no especificada")]
        public long SolicitudId { get; set; }
        public string CallbackController { get; set; }
        public string CallbackAction { get; set; }
        public long CallbackId { get; set; }
    }

    public class SolicitudYDocumentoViewModel
    {
        public long DocumentoId { get; set; }
        public string NombreArchivo { get; set; }
        public string NombreDocumento { get; set; }
        public string NombreSolicitud { get; set; }
        public long SolicitudId { get; set; }
    }

    public class ReporteViewModel
    {
        [Required]
        public DateTime Desde { get; set; } = DateTime.Today;
        [Required]
        public DateTime Hasta { get; set; } = DateTime.Today;
    }
}
