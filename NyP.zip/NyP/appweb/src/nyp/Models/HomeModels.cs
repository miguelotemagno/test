﻿using nyp.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;

namespace nyp.Models
{
    public class SearchModel
    {
        public long? CategoriaId { get; set; }
        public string SearchText { get; set; }
    }

    public class ListaPublicacionesViewModel
    {
        public ListaPublicacionesViewModel()
        {
            Documentos = new List<Publicacion>();
            Glosa = new List<Tuple<string, string>>();
        }
        public string Titulo { get; set; }
        public ICollection<Publicacion> Documentos { get; set; }
        public ICollection<Tuple<string, string>> Glosa { get; set; }
    }



    public static class FnvHash
    {
        public static readonly uint FnvPrime32 = 16777619;
        public static readonly ulong FnvPrime64 = 1099511628211;
        public static readonly uint FnvOffset32 = 2166136261;
        public static readonly ulong FnvOffset64 = 14695981039346656037;

        public static uint To32BitFnv1aHash(this string toHash,
              bool separateUpperByte = false)
        {
            IEnumerable<byte> bytesToHash;

            if (separateUpperByte)
                bytesToHash = toHash.ToCharArray()
                    .Select(c => new[] { (byte)((c - c) >> 8), (byte)c })
                    .SelectMany(c => c);
            else
                bytesToHash = toHash.ToCharArray()
                    .Select(Convert.ToByte);

            //this is the actual hash function; very simple
            uint hash = FnvOffset32;

            foreach (var chunk in bytesToHash)
            {
                hash ^= chunk;
                hash *= FnvPrime32;
            }
            return hash;
        }
    }

    public class HomeModel
    {
        public HomeModel()
        {
            Path = new List<CategoriasViewModel>();
            Categorias = new List<CategoriasViewModel>();
            Hoy = new ListaPublicacionesViewModel();
            UltimaSemana = new ListaPublicacionesViewModel();
            Ultimos30Dias = new ListaPublicacionesViewModel();
            Documentos = new ListaPublicacionesViewModel();
            Search = new SearchModel();
        }
        public SearchModel Search { get; set; }
        public IList<CategoriasViewModel> Path { get; set; }
        public ICollection<CategoriasViewModel> Categorias { get; set; }
        public ListaPublicacionesViewModel Hoy { get; set; }
        public ListaPublicacionesViewModel UltimaSemana { get; set; }
        public ListaPublicacionesViewModel Ultimos30Dias { get; set; }
        public ListaPublicacionesViewModel Documentos { get; set; }
        public string Terminos { get; set; }
        public string Area { get; set; }
        public string Tipo { get; set; }
        public string TargetTipo { get; set; }
        public string TargetTerminos { get; set; }
    }

    public class HomeTasasComisionesViewModel
    {
        public long CategoriaId { get; set; }
        public GrupoTasasCategorias padre { get; set; }
    }

    public class GrupoTasasCategorias
    {
        public long CategoriaId { get; set; }
        public Categoria raiz { get; set; }
        public List<GrupoTasasCategorias> Categorias { get; set; }
        public List<EnlacesCategoria> Enlaces { get; set; }
        public List<EnlacePublicacion> Publicaciones { get; set; }

    }

    public class EnlacePublicacion
    {
        public long PublicacionID { get; set; }
        public string Titulo { get; set; }
        public long CodDocumento { get; set; }
    }
}
