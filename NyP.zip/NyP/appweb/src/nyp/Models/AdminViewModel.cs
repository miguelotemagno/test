﻿using nyp.DataModels;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace nyp.Models
{
    public class PaginaViewModel
    {
        public int? Id { get; set; }
        [Required(ErrorMessage = "Debe especificar el título de la página")]
        public string Titulo { get; set; }
        [Required(ErrorMessage = "Por favor agregue contenidos a la página")]
        public string Contenido { get; set; }
    }

    public class NoticiaViewModel
    {
        public int Id { get; set; }
        [Required]
        public string Titulo { get; set; }
        [Required]
        public string Contenido { get; set; }
    }

    public class ConfigurarPaginaViewModel
    {
        public ICollection<PaginaContenidos> Paginas { get; set; }
        public ICollection<PropiedadConfiguracion> PaginasPredeterminadas { get; set; }
    }

    public class ResultadoValidacionCorreos
    {
        public string Email { get; set; }
        public UsuarioIntranet Usuario { get; set; }
        public bool Valido { get; set; }
        public string MensajeValidacion { get; set; }
    }

    public class NuevaListaDistribucioViewModel
    {
        [Required]
        public string Nombre { get; set; }
        public string Notas { get; set; }
    }

    public class EditarListaDistribucionViewModel
    {
        [Required]
        public int Id { get; set; }
        [Required]
        public string Nombre { get; set; }
        public string Notas { get; set; }
        public int[] Usuarios { get; set; }
        public string Action { get; set; } = "EditarListaDistribucion";
    }

    public class EliminarListaDistribucionViewModel
    {
        [Required]
        public int ListaId { get; set; }
        // sólo para agregar un campo
        [Required]
        public int Autor { get; set; }
    }

    public class EditarListaDistribucionDesdeOrganicaViewModel : EditarListaDistribucionViewModel
    {
        [Required(ErrorMessage = "Debe seleccionar un elemento de la orgánica")]
        public string OrganicaId { get; set; }
    }

    public class EditarListaDistribucionDesdeListadoViewModel : EditarListaDistribucionViewModel
    {
        [Required(ErrorMessage = "Ingrese texto a procesar")]
        public string Texto { get; set; }
        public IEnumerable<ResultadoValidacionCorreos> ResultadoValidacion { get; set; }
    }

    public class AgregarUsuariosListaDistribucionViewModel
    {
        [Required]
        public int Id { get; set; }
        [Required]
        public int[] Usuarios { get; set; }
    }


    public class RenameCategory
    {
        public long Id { get; set; }
        public string Text { get; set; }
    }

    public class MoveCategory
    {
        public long Id { get; set; }
        public long OldParent { get; set; }
        public string NewParent { get; set; }
    }

    public class AddCategory
    {
        public string ParentId { get; set; }
        public string Id { get; set; }
        public string Text { get; set; }
    }

    public class DeleteCategory
    {
        public long Id { get; set; }
    }

    public class OrderCategory
    {
        public string Id { get; set; }
        public int Order { get; set; }
    }

    public class Changes
    {
        public AddCategory[] Adds { get; set; }
        public RenameCategory[] Renames { get; set; }
        public MoveCategory[] Moves { get; set; }
        public DeleteCategory[] Deletes { get; set; }
        public OrderCategory[] Reorder { get; set; }
    }

    public class ConfigurarCategoriaBusquedaViewModel
    {
        [Required]
        public long CategoriaBusqueda { get; set; }
        [Required]
        public long CategoriaMenuLateral { get; set; }
    }

    public class MantenedorCodigosViewModel
    {
        public string CodigoDocumento { get; set; }
        public string Documento { get; set; }
        public bool Vigente { get; set; }
        public string Action { get; set; } = "MantenedorCodigos";
    }

    public class ConfiguracionViewModel
    {
        public int SLA1 { get; set; }
        public int SLA2 { get; set; }
        public int SLA3 { get; set; }
        public int AlertaVerde { get; set; }
        public int AlertaNaranja { get; set; }
        public int AlertaRoja { get; set; }

        public int CheckSum()
        {
            return SLA1 + SLA2 + SLA3 + AlertaRoja + AlertaNaranja + AlertaVerde;
        }
    }

    public class TasasComisionesViewModel
    {
        public long CategoriaRaizId { get; set; }
        public Categoria TasaCategoriaRaiz { get; set; }
        public List<Categoria> categorias { get; set; }
        public List<EnlacesCategoria> Enlaces { get; set; }
        
    }



    public class EnlaceViewModel
    {
        public int EnlaceId { get; set; }
        public long CategoriaId { get; set; }
        public Categoria Categoria { get; set; }
        public string Titulo { get; set; }
        public string Hipervinculo { get; set; }
    }

}