﻿using nyp.DataModels;
using nyp.Services;

namespace nyp.Models
{
    public class Destinatario : IDestinatario
    {
        public string Email { get; set; }
        public string Nombre { get; set; }
    }

    public class NotificacionSolicitudViewModel
    {
        public Solicitud Solicitud { get; set; }
        public int DiasPrimeraInsistencia { get; set; }
        public int DiasSegundaaInsistencia { get; set; }
        public int DiasTerceraInsistencia { get; set; }
    }

    public class NotificarNuevaPublicacionViewModel
    {
        public int ListaDistribucionId { get; set; }
        public long PublicacionId { get; set; }
    }

    public class NotificacionPublicacionViewModel
    {
        public Publicacion Publicacion { get; set; }
        public ListaDistribucion ListaDistribucion { get; set; }
    }

    public class NotificacionSolicitudModificadaViewModel
    {
        public UsuarioIntranet Autor { get; set; }
        public Solicitud Solicitud { get; set; }
    }

    public class NotificacionSolicitudAnuladaViewModel
    {
        public Solicitud Solicitud { get; set; }
        public string MotivoAnulacion { get; set; }
    }

    public class NotificacionSolicitudAutorizadaViewModel
    {
        public UsuarioIntranet Autor { get; set; }
        public string TipoEvento { get; set; }
        public Solicitud Solicitud { get; set; }
    }

    public class ResultadoEnvioNotificacionViewModel
    {
        public ListaDistribucion ListaDistribucion { get; set; }
        public NotificacionPublicacionViewModel Notificacion { get; set; }
    }



}
