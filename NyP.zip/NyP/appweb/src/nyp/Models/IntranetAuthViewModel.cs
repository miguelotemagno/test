﻿using Microsoft.AspNet.Mvc.Rendering;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace nyp.Models
{
    public class UserSelectionViewModel
    {
        public string Nombre { get; set; }
        public IEnumerable<SelectListItem> UsuariosSeleccionados{ get; set; }
        public bool Multiple { get; set; }
    }

    public class IntranetAuthViewModel
    {
        [Required]
        public int RUT { get; set; }
    }

    public class PruebaEncodeViewModel
    {
        public string TextoOriginal { get; set; }
        public string EncondeText { get; set; }
        public string DecodeText { get; set; }
    }
}