﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace nyp.Models
{
    public class CertificacionViewModel
    {
        public long PublicacionId { get; set; }
        public string NombrePublicacion { get; set; }
        
        //Datos historicos. 
        public int AnalistaEjecutorId { get; set; }
        public string AnalistaEjecutor { get; set; }
        public DateTime FechaProceso { get; set; }
        public string Comentarios { get; set; }

        //Datos Publicacion
        public int AnalistaId { get; set; }
        public string Analista { get; set; }
        public DateTime FechaCertificacion { get; set; }

        public int ResponsableNuevoId { get; set; }
        public string ResponsableNuevo { get; set; }
        public bool CambioResposable { get; set; }

        public string UnidadNuevaId { get; set; }
        public string UnidadNueva { get; set; }
        public string UbicacionNueva { get; set; }
        public bool CambioUnidad { get; set; }

        public IQueryable<DocumentoViewModel> Documentos { get; set; }

        public string Tipo { get; set; }
        public string Codigo { get; set; }
        public string NombreDocumento { get; set; }

    }
}
