﻿namespace nyp.Models
{
    public class Confirmacion
    {
        public string Titulo { get; set; }
        public string Texto { get; set; }
    }
}
