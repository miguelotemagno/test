﻿using Microsoft.AspNet.Http;
using Microsoft.AspNet.Http.Features;
using nyp.DataModels;
using nyp.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Claims;

namespace nyp.Session
{
    public static class NYPSession
    {
        private static IHttpContextAccessor contextAux; 
        public static byte[] ObjectToByteArray(object obj)
        {
            if (obj == null)
                return null;

            BinaryFormatter bf = new BinaryFormatter();
            using (MemoryStream ms = new MemoryStream())
            {
                bf.Serialize(ms, obj);
                return ms.ToArray();
            }
        }

        public static object ByteArrayToObject(byte[] array)
        {
            if (array == null)
                return null;
            BinaryFormatter bf = new BinaryFormatter();
            MemoryStream ms = new MemoryStream(array);
            ms.Position = 0;
            return bf.Deserialize(ms);
        }

        public static NYPSessionData Load(INYPContext dbContext)
        {
            return Load(contextAux, dbContext);
        }

        public static NYPSessionData Load(IHttpContextAccessor HttpContext, INYPContext dbContext)
        {
            if (contextAux == null) contextAux = HttpContext;

            byte[] array = null;
            if (HttpContext.HttpContext.Session.TryGetValue("NYP_SS", out array))
            {
                return (NYPSessionData)ByteArrayToObject(array);
            }
            else
            {
                var claim = HttpContext.HttpContext.User.FindFirst(t => t.Type == ClaimTypes.SerialNumber);
                if (claim != null)
                {
                    int RUT = 0;
                    if (int.TryParse(claim.Value, out RUT))
                    {
                        var user = (from u in dbContext.UsuariosIntranet
                                    where u.Id == RUT
                                    select u).FirstOrDefault();
                        if (user != null)
                        {
                            return new NYPSessionData()
                            {
                                RUT = user.Id,
                                Nombre = user.Nombres + " " + user.ApellidoPaterno,
                                Cargo = user.Cargo,
                                Email = user.Email,
                                AnalistaNYP = user.AnalistaNYP,
                                PublicacionesBloqueadas = calcularBloqueos(user, dbContext)

                            };
                        }
                    }
                }
            }
            return null;
        }

        public static void Save(NYPSessionData SessionData, ISession ContextSession)
        {
            ContextSession.Set("NYP_SS", ObjectToByteArray(SessionData));
        }

        private static List<Restriccion> calcularBloqueos(UsuarioIntranet user, INYPContext dbContext)
        {
            List<Restriccion> listaR = new List<Restriccion>();

            var bloqueoGerencia = (from b in dbContext.Restricciones
                                   join g in dbContext.Gerencias
                                   on b.GerenciaId equals g.Id
                                   join a in dbContext.Areas on g.Id equals a.GerenciaId
                                   join ud in dbContext.Unidades on a.Id equals ud.AreaId
                                   where ud.Id == user.UnidadId
                                   select b);

            if (!bloqueoGerencia.Any()) return listaR;


            int areaUsuario = (from u in dbContext.UsuariosIntranet
                               join uu in dbContext.Unidades on u.UnidadId equals uu.Id
                               join au in dbContext.Areas on uu.AreaId equals au.Id
                               where u.Id == user.Id
                               select au.Id).FirstOrDefault();

            var bloqueoArea = (from b2 in bloqueoGerencia
                               where b2.AreaId == areaUsuario || b2.AreaId == null
                               select b2);

            if (!bloqueoArea.Any()) return listaR;

            var bloqueoUnidad = (from b3 in bloqueoArea
                                 where b3.UnidadId == user.UnidadId || b3.UnidadId == null
                                 select b3);

            if (!bloqueoUnidad.Any()) return listaR;


            foreach (Restriccion rest in bloqueoUnidad)
            {
                var usuario = (from ue in dbContext.ExclusionesUsuario
                               where ue.RestriccionRestriccionId == rest.RestriccionId && ue.UsuarioIntranetId == user.Id
                               select ue).FirstOrDefault();
                if (usuario == null)
                {
                    listaR.Add(rest);
                }
            }



            return listaR;



        }

    }

    public class SessionServiceLocalImplementation : ISessionService
    {
        INYPSessionData SessionData;
        INYPActividades Actividades;

        public SessionServiceLocalImplementation(IHttpContextAccessor httpContextAccessor, INYPContext dbContext)
        {
            SessionData = NYPSession.Load(httpContextAccessor, dbContext);
            // TODO: Inicializar desde db
            Actividades = new NYPActividades();
        }

        public INYPSessionData DatosUsuario
        {
            get
            {
                return SessionData;
            }
        }

        public INYPActividades ActividadesUsuario
        {
            get
            {
                return Actividades;
            }
        }
    }

    [Serializable]
    public class NYPSessionData : INYPSessionData
    {
        public int RUT { get; set; }
        public string Nombre { get; set; }
        public string Cargo { get; set; }
        public bool AnalistaNYP { get; set; }
        public string Email { get; set; }
        public List<Restriccion> PublicacionesBloqueadas { get; set; }
    }

    public class NYPActividades : INYPActividades
    {
        public int Nuevas
        {
            get
            {
                // TODO
                return 0;
            }
        }
    }
}
