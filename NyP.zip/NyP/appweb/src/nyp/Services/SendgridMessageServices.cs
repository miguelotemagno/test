﻿using Microsoft.Extensions.OptionsModel;
using SendGrid;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace nyp.Services
{
    public class SendgridOptions
    {
        public string From { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }

    public class SendgridMessageServices : IEmailSender
    {
        private SendgridOptions SendgridOptions;
        private Web _transportWeb = null;
        public Web TransportWeb
        {
            get
            {
                if (_transportWeb == null)
                {
                    _transportWeb = new Web(new NetworkCredential(SendgridOptions.Username, SendgridOptions.Password));
                }
                return _transportWeb;
            }
        }

        public SendgridMessageServices(IOptions<SendgridOptions> options)
        {
            SendgridOptions = options.Value;
        }

        public async Task SendEmailToList(IEnumerable<IDestinatario> destinatarios, string titulo, string mensaje, ICollection<IAdjunto> adjuntos)
        {
            foreach (var d in destinatarios)
            {
                await SendEmail(d.Email, titulo, mensaje, adjuntos);
            }
        }

        public async Task SendEmail(string email, string subject, string message, ICollection<IAdjunto> adjuntos)
        {
            var mail = new SendGridMessage()
            {
                From = new System.Net.Mail.MailAddress(SendgridOptions.From),
                Subject = subject,
                Html = message
            };
            mail.AddTo(email);

            if (adjuntos != null)
            {
                foreach (var adjunto in adjuntos)
                {
                    mail.AddAttachment(adjunto.Path);
                }
            }
            await TransportWeb.DeliverAsync(mail);
        }
    }
}
