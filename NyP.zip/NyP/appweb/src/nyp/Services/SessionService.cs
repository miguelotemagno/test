﻿using Microsoft.AspNet.Http.Features;

namespace nyp.Services
{
    public interface INYPActividades
    {
        int Nuevas { get; }
    }

    public interface INYPSessionData
    {
        int RUT { get; set; }
        string Nombre { get; set; }
        string Cargo { get; set; }
        bool AnalistaNYP { get; set; }
        string Email { get; set; }
    }

    public interface ISessionService
    {
        INYPSessionData DatosUsuario { get; }
        INYPActividades ActividadesUsuario { get; }
    }
}