﻿using Microsoft.Extensions.OptionsModel;
using System.Collections.Generic;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace nyp.Services
{
    public class SmtpOptions
    {
        public string From { get; set; }
        public string Hostname { get; set; }
        public int Port { get; set; }
        public bool EnableSsl { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }

    public class SmtpMessageServices : BaseMessageServices, IEmailSender
    {
        private SmtpOptions SmtpOptions;
        private SmtpClient _smtp = null;
        public SmtpClient Smtp
        {
            get
            {
                if (_smtp == null)
                {
                    _smtp = new SmtpClient(SmtpOptions.Hostname, SmtpOptions.Port)
                    {
                        Credentials = new NetworkCredential(SmtpOptions.Username, SmtpOptions.Password),
                        EnableSsl = SmtpOptions.EnableSsl
                    };
                }
                return _smtp;
            }
        }


        public SmtpMessageServices(IOptions<SmtpOptions> options)
        {
            SmtpOptions = options.Value;
        }

        public async Task SendEmailToList(IEnumerable<IDestinatario> destinatarios, string titulo, string mensaje, ICollection<IAdjunto> adjuntos)
        {
            foreach (var d in destinatarios)
            {
                await SendEmail(d.Email, titulo, mensaje, adjuntos);
            }
        }

        public async Task SendEmail(string email, string subject, string message, ICollection<IAdjunto> adjuntos)
        {
            using (var msg = new MailMessage()
            {
                From = new MailAddress(SmtpOptions.From),
                Subject = subject,
                Body = message,
                IsBodyHtml = true
            })
            {
                msg.To.Add(email);
                foreach (var adjunto in adjuntos)
                {
                    msg.Attachments.Add(new Attachment(adjunto.Path));
                }
                try { 
                await Smtp.SendMailAsync(msg);
                } catch (SmtpException ex)
                {
                    message = ex.Message;
                }
            }
        }
    }
}
