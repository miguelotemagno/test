﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace nyp.Services
{
    public interface IDestinatario
    {
        string Nombre { get; set; }
        string Email { get; set; }
    }

    public interface IAdjunto
    {
        string Nombre { get; set; }
        string Path { get; set; }
    }

    public interface IEmailSender
    {
        Task SendEmail(string email, string subject, string message, ICollection<IAdjunto> adjuntos);
        Task SendEmailToList(IEnumerable<IDestinatario> destinatarios, string titulo, string mensaje, ICollection<IAdjunto> adjuntos);
    }

    public class BaseMessageServices
    {
    }

    public class Adjunto : IAdjunto
    {
        public string Nombre { get; set; }
        public string Path { get; set; }
    }

}
