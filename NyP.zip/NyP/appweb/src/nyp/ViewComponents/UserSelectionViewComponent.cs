﻿using Microsoft.AspNet.Mvc;
using Microsoft.AspNet.Mvc.Rendering;
using nyp.DataModels;
using nyp.Models;
using System.Linq;

namespace nyp.ViewComponents
{
    public class UserSelectionViewComponent : ViewComponent
    {
        private readonly NYPContext db;

        public UserSelectionViewComponent(NYPContext context)
        {
            db = context;
        }

        public IViewComponentResult Invoke(string name, bool multiple, int[] SelectedIds)
        {
            var usuarios = from u in db.UsuariosIntranet
                           where SelectedIds.Contains(u.Id)
                           select new SelectListItem()
                           {
                               Text = string.Format("{0}, {1}", u.ApellidoPaterno, u.Nombres),
                               Value = u.Id.ToString(),
                           };


            var model = new UserSelectionViewModel()
            {
                Nombre = name,
                UsuariosSeleccionados = usuarios,
                Multiple = multiple
            };

            return View(model);
        }

        public IViewComponentResult Invoke(string name, bool multiple, long solicitudId)
        {
            UserSelectionViewModel model = new UserSelectionViewModel();

            //if (solicitudId > 0)
            {
                var usuarios1 = (from un in db.UsuariosNotificados
                                 join u in db.UsuariosIntranet on un.Usuario.Id equals u.Id
                                 where un.Solicitud.Id == solicitudId && un.Usuario != null
                                 select new SelectListItem
                                 {
                                     Text = string.Format("{0}, {1}", u.ApellidoPaterno, u.Nombres),
                                     Value = un.Email,
                                 })
                                 .ToList();
                var usuarios2 = (from u in db.UsuariosNotificados
                                where u.Solicitud.Id == solicitudId && u.Usuario == null
                                select new SelectListItem
                                {
                                    Text = u.Email,
                                    Value = u.Email,
                                })
                                .ToList();

                var usuarios = usuarios1.Concat(usuarios2);

                model = new UserSelectionViewModel()
                {
                    Nombre = name,
                    UsuariosSeleccionados = usuarios.ToList(),
                    Multiple = multiple
                };
            }

            return View(model);
        }
    }
}
