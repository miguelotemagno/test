﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using ExtremeML.Packaging;
using Microsoft.AspNet.Hosting;
using Microsoft.AspNet.Http;
using Microsoft.AspNet.Mvc;
using Microsoft.Net.Http.Headers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

public class ExcelFileResultBase<T>
{
    protected IEnumerable<T> _model;
    protected string _titulo;

    public ExcelFileResultBase(IEnumerable<T> model, string titulo)
    {
        _titulo = titulo;
        _model = model;
    }

    protected static bool IsNumericType(Type type)
    {
        if (type == null)
        {
            return false;
        }

        switch (Type.GetTypeCode(type))
        {
            case TypeCode.Byte:
            case TypeCode.Decimal:
            case TypeCode.Double:
            case TypeCode.Int16:
            case TypeCode.Int32:
            case TypeCode.Int64:
            case TypeCode.SByte:
            case TypeCode.Single:
            case TypeCode.UInt16:
            case TypeCode.UInt32:
            case TypeCode.UInt64:
                return true;
            case TypeCode.Object:
                if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>))
                {
                    return IsNumericType(Nullable.GetUnderlyingType(type));
                }
                return false;
        }
        return false;
    }

    protected static bool IsDate(Type type)
    {
        if (type == null)
        {
            return false;
        }

        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>))
        {
            type = Nullable.GetUnderlyingType(type);
        }
        return Type.GetTypeCode(type) == TypeCode.DateTime;
    }

    protected static string NombreAtributo(PropertyInfo property)
    {
        var nombre = "";
        var displayAttribute = property.GetCustomAttributes(typeof(DisplayAttribute), false).Cast<DisplayAttribute>().SingleOrDefault();
        if (displayAttribute != null)
        {
            nombre = displayAttribute.Name;
        }
        else
        {
            nombre = property.Name;
        }
        return nombre;
    }

    protected string GetExcelColumnName(int columnNumber)
    {
        int dividend = columnNumber;
        string columnName = string.Empty;
        int modulo;

        while (dividend > 0)
        {
            modulo = (dividend - 1) % 26;
            columnName = Convert.ToChar(65 + modulo).ToString() + columnName;
            dividend = (dividend - modulo) / 26;
        }
        return columnName;
    }

    protected static Sheet GetWorksheetByName(SpreadsheetDocument document, string sheetName)
    {
        return
           document.WorkbookPart.Workbook.GetFirstChild<Sheets>().
           Elements<Sheet>().Where(s => s.Name == sheetName).FirstOrDefault();
    }

    protected static WorksheetPart GetWorksheetPartByName(SpreadsheetDocument document, Sheet sheet, string sheetName)
    {
        if (sheet != null)
        {
            string relationshipId = sheet.Id.Value;
            WorksheetPart worksheetPart = (WorksheetPart)
                 document.WorkbookPart.GetPartById(relationshipId);
            return worksheetPart;
        }
        return null;
    }

    public virtual Task WriteFileAsync(HttpResponse response)
    {
        throw new NotImplementedException();
    }
}

class ExcelFileResultPlantilla<T> : ExcelFileResultBase<T>
{
    private string _plantilla;
    private IHostingEnvironment _hostingEnvironment;

    public ExcelFileResultPlantilla(IEnumerable<T> model, string plantilla, string titulo, IHostingEnvironment hostingEnvironment) :
        base(model, titulo)
    {
        _plantilla = plantilla;
        _hostingEnvironment = hostingEnvironment;
    }

    public object[][] ModelToObjectArray()
    {
        var properties = typeof(T).GetProperties().OrderBy(o => o.MetadataToken);
        var data = new List<object[]>();
        foreach (var obj in _model)
        {
            var tmpObj = new object[properties.Count()];
            int i = 0;
            foreach (var prop in properties)
            {
                if (IsDate(prop.PropertyType))
                {
                    var dt = prop.GetValue(obj) as DateTime?;
                    if (dt != null)
                    {
                        tmpObj[i] = dt.Value;
                    }
                    else
                    {
                        tmpObj[i] = null;
                    }
                }
                else
                {
                    tmpObj[i] = prop.GetValue(obj);
                }
                i++;
            }
            data.Add(tmpObj);
        }
        return data.ToArray();

    }

    public override Task WriteFileAsync(HttpResponse response)
    {
        var templateName = _hostingEnvironment.MapPath(Path.Combine("Templates", _plantilla + ".xlsm"));
        using (var input = new FileStream(templateName, FileMode.Open, FileAccess.Read))
        using (var output = new MemoryStream())
        {
            using (var package = SpreadsheetDocumentWrapper.Open(input, output))
            {
                var obj = ModelToObjectArray();
                var part = package.WorkbookPart.GetTablePart("Datos");
                var table = part.Table;
                table.Fill(obj);
            }
            var byteArray = output.ToArray();
            return response.Body.WriteAsync(byteArray, 0, byteArray.Length);
        }
    }
}

class ExcelFileResultSinPlantilla<T> : ExcelFileResultBase<T>
{
    public ExcelFileResultSinPlantilla(IEnumerable<T> model, string titulo) :
        base(model, titulo)
    { }

    public override Task WriteFileAsync(HttpResponse response)
    {
        byte[] FileContents = null;
        using (MemoryStream mem = new MemoryStream())
        {
            using (var workbook = SpreadsheetDocument.Create(mem, DocumentFormat.OpenXml.SpreadsheetDocumentType.Workbook))
            {
                var workbookPart = workbook.AddWorkbookPart();
                workbook.WorkbookPart.Workbook = new Workbook();
                workbook.WorkbookPart.Workbook.Sheets = new Sheets();
                var sheetPart = workbook.WorkbookPart.AddNewPart<WorksheetPart>();
                var sheetData = new SheetData();
                sheetPart.Worksheet = new Worksheet(sheetData);
                Sheets sheets = workbook.WorkbookPart.Workbook.GetFirstChild<Sheets>();
                string relationshipId = workbook.WorkbookPart.GetIdOfPart(sheetPart);

                uint sheetId = 1;
                if (sheets.Elements<Sheet>().Count() > 0)
                {
                    sheetId = sheets.Elements<Sheet>().Select(s => s.SheetId.Value).Max() + 1;
                }

                Sheet sheet = new Sheet()
                {
                    Id = relationshipId,
                    SheetId = sheetId,
                    Name = _titulo
                };
                sheets.Append(sheet);

                Row headerRow = new Row();

                var properties = typeof(T).GetProperties().OrderBy(o => o.MetadataToken);
                foreach (var property in properties)
                {
                    var columnName = NombreAtributo(property);
                    Cell cell = new Cell();
                    cell.DataType = CellValues.String;
                    cell.CellValue = new CellValue(columnName);
                    headerRow.AppendChild(cell);
                }

                sheetData.AppendChild(headerRow);
                var rowCount = 0;
                foreach (var item in _model)
                {
                    Row newRow = new Row();

                    foreach (var header in properties)
                    {
                        Cell cell = new Cell();
                        cell.DataType = CellValues.String;

                        var value = header.GetValue(item);
                        if (IsNumericType(header.PropertyType))
                        {
                            cell.DataType = CellValues.Number;
                        }
                        else
                        {
                            cell.DataType = CellValues.String;
                        }
                        cell.CellValue = new CellValue(value?.ToString()); //
                        newRow.AppendChild(cell);
                    }
                    sheetData.AppendChild(newRow);
                    rowCount++;
                }

                string rangeRef = string.Format("A1:{0}1", GetExcelColumnName(headerRow.Count()));
                sheetPart.Worksheet.Append(new AutoFilter
                {
                    Reference = rangeRef
                });

                sheetPart.Worksheet.Save();
                workbook.WorkbookPart.Workbook.Save();
                workbook.Close();
                FileContents = mem.ToArray();
                return response.Body.WriteAsync(FileContents, 0, FileContents.Length);
            }
        }
    }
}

public class ExcelFileResult<T> : FileResult
{
    private ExcelFileResultBase<T> obj;
    public ExcelFileResult(IEnumerable<T> model, string plantilla, string titulo, IHostingEnvironment hostingEnvironment)
        : base(new MediaTypeHeaderValue("application/vnd.ms-excel.sheet.macroEnabled.12"))
    {
        obj = new ExcelFileResultPlantilla<T>(model, plantilla, titulo, hostingEnvironment);
    }

    public ExcelFileResult(IEnumerable<T> model, string titulo)
        : base(new MediaTypeHeaderValue("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
    {
        obj = new ExcelFileResultSinPlantilla<T>(model, titulo);
    }

    protected override Task WriteFileAsync(HttpResponse response)
    {
        return obj.WriteFileAsync(response);
    }

}