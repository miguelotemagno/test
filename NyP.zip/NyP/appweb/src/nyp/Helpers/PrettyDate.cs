﻿using System;

namespace nyp.Helpers
{
    public class PrettyDate
    {
        public static string GetPrettyDate(DateTime d)
        {
            // 1.
            // Get time span elapsed since the date.
            TimeSpan s = DateTime.Now.Subtract(d);

            // 2.
            // Get total number of days elapsed.
            int dayDiff = (int)s.TotalDays;

            // 3.
            // Get total number of seconds elapsed.
            int secDiff = (int)s.TotalSeconds;

            // 4.
            // Don't allow out of range values.
            if (dayDiff < 0 || dayDiff >= 31)
            {
                return null;
            }

            // 5.
            // Handle same-day times.
            if (dayDiff == 0)
            {
                // A.
                // Less than one minute ago.
                if (secDiff < 60)
                {
                    return "recién";
                }
                // B.
                // Less than 2 minutes ago.
                if (secDiff < 120)
                {
                    return "hace un minuto";
                }
                // C.
                // Less than one hour ago.
                if (secDiff < 3600)
                {
                    return string.Format("hace {0} minutos",
                        Math.Floor((double)secDiff / 60));
                }
                // D.
                // Less than 2 hours ago.
                if (secDiff < 7200)
                {
                    return "hace una hora";
                }
                // E.
                // Less than one day ago.
                if (secDiff < 86400)
                {
                    return string.Format("hace {0} horas",
                        Math.Floor((double)secDiff / 3600));
                }
            }
            // 6.
            // Handle previous days.
            if (dayDiff == 1)
            {
                return "ayer";
            }
            if (dayDiff < 7)
            {
                return string.Format("hace {0} días",
                dayDiff);
            }
            if (dayDiff < 31)
            {
                var weeks = Math.Ceiling((double)dayDiff / 7);
                if (weeks == 1)
                {
                    return "hace una semana";
                }
                return string.Format("hace {0} semanas", weeks);
            }
            return d.ToShortDateString();
        }
        public static DateTime? SumarDiasHabiles(DateTime? fechaInicial, int cantidad)
        { 
            int contador = 0;
            int numeroDia = 0; 
            if (fechaInicial == null)
            {
                return fechaInicial; 
            }
            DateTime fechaAux = (DateTime)fechaInicial; 
            if (cantidad > 0) { 
                while (cantidad > contador)
                {
                    fechaAux = fechaAux.AddDays(1);
                    numeroDia = Convert.ToInt16(fechaAux.DayOfWeek.ToString("d"));
                    if (numeroDia >= 1 && numeroDia <= 5)
                    {
                        contador++; 
                    }
                }
            }
            return fechaAux;
        }
        public static DateTime? RestarDiasHabiles(DateTime? fechaInicial, int cantidad)
        {
            int contador = 0;
            int numeroDia = 0;
            if (fechaInicial == null)
            {
                return fechaInicial;
            }
            DateTime fechaAux = (DateTime)fechaInicial;
            if (cantidad > 0)
            {
                while (cantidad >= contador)
                {
                    fechaAux.AddDays(1);
                    numeroDia = Convert.ToInt16(fechaAux.DayOfWeek.ToString("d"));
                    if (numeroDia >= 1 && numeroDia <= 5)
                    {
                        contador++;
                    }
                }
            }
            return fechaAux;
        }
    }
}
