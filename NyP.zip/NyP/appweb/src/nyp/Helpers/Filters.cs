﻿using Microsoft.AspNet.Mvc;
using Microsoft.AspNet.Mvc.Filters;

namespace nyp.Filters
{
    public class OcultarMenuLateralFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            ((Controller)context.Controller).ViewBag.MostrarMenuLateral = false;
            base.OnActionExecuting(context);
        }
    }
}
