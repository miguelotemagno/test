﻿using nyp.DataModels;
using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace nyp.Helpers
{
    public class Preferencias
    {
        private static INYPContext dbContext = null;
        public Preferencias(INYPContext context)
        {
            dbContext = context;
            var props = GetType().GetProperties();
            var dict = props.ToDictionary(t => t.Name, t => t);

            var propiedadesBaseDatos = dbContext.Propiedades.ToDictionary(t => t.Id, t => t.Valor);

            foreach (var property in props)
            {
                string value = "";
                if (propiedadesBaseDatos.TryGetValue(property.Name, out value))
                {
                    property.SetValue(this, Convert.ChangeType(value, property.PropertyType), null);
                }
                else
                {
                    // valor por defecto
                    property.SetValue(this, null, null);
                }
            }
        }

        public void Guardar()
        {
            var props = GetType().GetProperties();
            foreach (var prop in props)
            {
                var stored = (from s in dbContext.Propiedades
                              where s.Id == prop.Name
                              select s).FirstOrDefault();

                var valor = (string)Convert.ChangeType(prop.GetValue(this, null), typeof(string));
                if (stored != null)
                {
                    stored.Valor = valor;
                }
                else
                {
                    dbContext.Propiedades.Add(new PropiedadConfiguracion() { Id = prop.Name, Valor = valor });
                }
            }
            dbContext.SaveChanges();
        }

        [Display(Name = "Primer plazo Vº Bº")]
        public int SLA1 { get; set; } = 3;
        [Display(Name = "Segundo plazo Vº Bº")]
        public int SLA2 { get; set; }
        [Display(Name = "Plazo final Vº Bº")]
        public int SLA3 { get; set; }
        [Display(Name = "Página informativa para solicitar publicación")]
        public int PaginaSolicitarPublicacion { get; set; }
        [Display(Name = "Categoría a desplegar en combo de búsqueda")]
        public long CategoriaBusqueda { get; set; }
        [Display(Name = "Categoría a desplegar en menu lateral")]
        public long CategoriaMenuLateral { get; set; }

        public int AlertaRoja { get; set; }
        public int AlertaNaranja { get; set; }
        public int AlertaVerde { get; set; }
        public String RutaServer { get; set; }
        public String DirectorioTemporal { get; set; }
        public long TasasID { get; set; }

    }
}
