﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.CustomProperties;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Validation;
using DocumentFormat.OpenXml.VariantTypes;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.AspNet.Hosting;
using nyp.DataModels;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.AspNet.Mvc;

namespace nyp.Helpers
{
    public class WordUtils
    {
        public WordUtils(IHostingEnvironment hostingEnvironment, IUrlHelper url)
        {
            this.hostingEnvironment = hostingEnvironment;
            this.url = url;
        }

        private int altChunkCounter = 1;
        private IHostingEnvironment hostingEnvironment;
        private IUrlHelper url;

        private bool RefrescarTextos(WordprocessingDocument doc, OpenXmlPartRootElement rootElement, string propertyName, string propertyValue, bool isHtml)
        {
            var fieldCodes = rootElement.Descendants<FieldCode>().ToList();
            var regex = new Regex(string.Format(@"DOCPROPERTY\s+{0}\s+\\\*\sMERGEFORMAT", propertyName));
            var changed = false;
            foreach (FieldCode field in fieldCodes)
            {
                var m = regex.Match(field.Text);
                if (m.Success)
                {
                    Text text = null;
                    var runs = field.Parent.NextSibling<Run>();
                    while (runs != null)
                    {
                        var t = runs.Descendants<Text>().FirstOrDefault();
                        if (t != null)
                        {
                            text = t;
                            break;
                        }
                        runs = runs.NextSibling<Run>();
                    }


                    // Cambiar el texto 
                    if (isHtml)
                    {
                        if (text != null)
                        {
                            text.Text = "";
                        }
                        appendHtml(doc, propertyValue, "altChunk" + altChunkCounter.ToString(), field);
                        altChunkCounter++;
                    }
                    else
                    {
                        if (text != null)
                        {
                            text.Text = propertyValue;
                        }
                    }
                }
            }

            var simpleFields = rootElement.Descendants<SimpleField>().ToList();
            foreach (var field in simpleFields)
            {
                var m = regex.Match(field.Instruction);
                if (m.Success)
                {
                    if (isHtml)
                    {
                        foreach (var t in field.Descendants<Text>())
                        {
                            t.Text = "";
                        }
                        appendHtml(doc, propertyValue, "altChunk" + altChunkCounter.ToString(), field);
                        altChunkCounter++;
                    }
                    else
                    {
                        var t = field.Descendants<Text>().FirstOrDefault();
                        if (t != null)
                        {
                            t.Text = propertyValue;
                        }
                    }
                    changed = true;
                }
            }
            if (changed)
            {
                rootElement.Save();
            }
            return changed;
        }

        private void SetProperty(WordprocessingDocument doc, string propertyName, string propertyValue, bool isHtml)
        {
            /*
            var newProp = new CustomDocumentProperty();
            newProp.FormatId = "{D5CDD505-2E9C-101B-9397-08002B2CF9AE}";
            newProp.VTLPWSTR = new VTLPWSTR(propertyValue);
            newProp.Name = propertyName;
            var props = doc.CustomFilePropertiesPart.Properties;
            var prop = (from p in props
                        where ((CustomDocumentProperty)p).Name.Value == propertyName
                        select p
                        ).FirstOrDefault();
            if (prop != null)
            {
                prop.Remove();
            }
            props.AppendChild(newProp);

            // esto es NECESARIO, ugh
            var pid = 2;
            foreach (var item in props)
            {
                ((CustomDocumentProperty)item).PropertyId = pid++;
            }
            props.Save();*/

            RefrescarTextos(doc, doc.MainDocumentPart.RootElement, propertyName, propertyValue, isHtml);
            var headers = doc.MainDocumentPart.HeaderParts.ToList();
            foreach (var header in headers)
            {
                RefrescarTextos(doc, header.RootElement, propertyName, propertyValue, isHtml);
            }

            var footers = doc.MainDocumentPart.FooterParts.ToList();
            foreach (var footer in footers)
            {
                RefrescarTextos(doc, footer.RootElement, propertyName, propertyValue, isHtml);
            }
        }

        private string GetCircularDocX(Publicacion publicacion, string outputFilename)
        {
            var templateName = hostingEnvironment.MapPath(Path.Combine("Templates", "Circular.docx"));
            var outputFilepath = Path.Combine(Path.GetTempPath(), outputFilename);
            byte[] byteArray = File.ReadAllBytes(templateName);
            using (MemoryStream mem = new MemoryStream())
            {
                mem.Write(byteArray, 0, (int)byteArray.Length);
                using (var d = WordprocessingDocument.Open(mem, true))
                {
                    SetProperty(d, "Gerencia", publicacion.Area, false);
                    SetProperty(d, "Responsable", publicacion.Circular.Responsable, false);
                    SetProperty(d, "Destino", publicacion.Circular.Destino, false);
                    SetProperty(d, "Materia", publicacion.Circular.Materia, false);
                    SetProperty(d, "Consultas", publicacion.Circular.Consultas, false);
                    SetProperty(d, "InicioVigencia", publicacion.Circular.InicioVigencia.ToShortDateString(), false);

                    SetProperty(d, "NumeroCircular", publicacion.Circular.Id.ToString(), false);
                    SetProperty(d, "FechaCircular", publicacion.FechaPublicacion.ToShortDateString(), false);
                    SetProperty(d, "Objetivos", publicacion.Circular.Objetivo, false);
                    SetProperty(d, "Codigo", publicacion.Codigo, false);

                    string funcionamientoActual = Regex.Replace(publicacion.Circular.FuncionamientoActual, "<.*?>", string.Empty);
                    funcionamientoActual = funcionamientoActual.Replace("\r\n", "");

                    string funcionamientoNuevo = Regex.Replace(publicacion.Circular.FuncionamientoNuevo, "<.*?>", string.Empty); 
                    funcionamientoNuevo = funcionamientoNuevo.Replace("\r\n", "");


                    SetProperty(d, "FuncionamientoActual", funcionamientoActual, false);
                    SetProperty(d, "FuncionamientoNuevo", funcionamientoNuevo, false);

                       // Archivos
                    var files = (from archivo in publicacion.DocumentosEnPublicacion
                                 select archivo.Documento.NombreArchivo).ToArray();
                    var str = string.Join(", ", files);
                    SetProperty(d, "ArchivosRelacionados", str, false);

                    var ubicacion = url.Action("Ver", "Publicacion", new { id = publicacion.Id }, "http");
                    SetProperty(d, "RutaDocumento", ubicacion, false);
                   
                }

                File.Delete(outputFilepath);
                using (var fs = new FileStream(outputFilepath, FileMode.CreateNew))
                {
                    mem.WriteTo(fs);
                }
            }
            return outputFilepath;
        }

        private string GetCircularDocX(Publicacion publicacion)
        {
            var outputFilepath = string.Format("Circular-{0}.docx", publicacion.Circular.Id);
            return GetCircularDocX(publicacion, outputFilepath);
        }

        public Stream GetCircularWord(Publicacion publicacion)
        {
            var filename = GetCircularDocX(publicacion);
            var ms = new MemoryStream();
            using (var fs = new FileStream(filename, System.IO.FileMode.Open))
            {
                fs.CopyTo(ms);
            }
            ms.Position = 0;
            return ms;
        }

        public void GetCircularWordAsFile(Publicacion publicacion, string filename)
        {
            GetCircularDocX(publicacion, filename);
        }

        private Stream GenerateStreamFromString(string s)
        {
            MemoryStream stream = new MemoryStream();
            StreamWriter writer = new StreamWriter(stream);
            writer.Write(s);
            writer.Flush();
            stream.Position = 0;
            return stream;
        }

        private void appendHtml(WordprocessingDocument doc, string htmlText, string altChunkId, OpenXmlElement where)
        {
            MainDocumentPart mainPart = doc.MainDocumentPart;
            AlternativeFormatImportPart chunk = mainPart.AddAlternativeFormatImportPart(
                AlternativeFormatImportPartType.Html, altChunkId);

            using (var s = GenerateStreamFromString("<html><body>" + htmlText + "</html></body>"))
            {
                chunk.FeedData(s);
            }

            var altChunk = new AltChunk();
            altChunk.Id = altChunkId;

            var p = where;

            // body (§17.2.2); comment (§17.13.4.2); docPartBody (§17.12.6); endnote (§17.11.2); footnote (§17.11.10); ftr (§17.10.3); hdr (§17.10.4); tc (§17.4.66)
            while (
                p != null &&
                !(p is Body || p is Comment || p is DocPartBody || p is Endnote || p is Footnote || p is Footer || p is Header || p is TableCell))
            {
                p = p.Parent;
            }

            if (p != null)
            {
                p.Append(altChunk);
                mainPart.Document.Save();
            }
            else
            {
                throw new System.Exception("No se encontró un punto de inserción válido para texto HTML");
            }
        }
    }
}
