﻿using Microsoft.AspNet.Http;
using Microsoft.AspNet.Mvc;
using nyp.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace nyp.Extensions
{
    public static class Extensions
    {
        private static IHttpContextAccessor HttpContextAccessor;
        public static void Configure(IHttpContextAccessor httpContextAccessor)
        {
            HttpContextAccessor = httpContextAccessor;
        }

        public static IEnumerable<T> Traverse<T>(this IEnumerable<T> items,
            Func<T, IEnumerable<T>> childSelector)
        {
            var stack = new Stack<T>(items);
            while (stack.Any())
            {
                var next = stack.Pop();
                yield return next;
                if (childSelector(next) != null)
                    foreach (var child in childSelector(next))
                        stack.Push(child);
            }
        }

        public static bool IsValidEmail(this string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        public static void AnadirUsuariosACopiar(this IEnumerable<Services.IDestinatario> destinatarios, Solicitud solicitud)
        {
            if (solicitud.UsuariosNotificados == null) return;
            foreach (var dc in solicitud.UsuariosNotificados)
            {
                if (!destinatarios.Any(x => x.Email == dc.Email)) // Evitar agregar email repetido
                    ((List<Services.IDestinatario>)destinatarios).Add(new Models.Destinatario { Email = dc.Email, Nombre = dc.Usuario != null ? dc.Usuario.Nombres + " " + dc.Usuario.ApellidoPaterno : dc.Email });
            }
        }

        public static IEnumerable<Categoria> Descendants(this Categoria root)
        {
            var nodes = new Stack<Categoria>(new[] { root });
            while (nodes.Any())
            {
                Categoria node = nodes.Pop();
                yield return node;
                if (node.Children != null)
                {
                    foreach (var n in node.Children) nodes.Push(n);
                }
            }
        }

        public static string AbsoluteUri(this IUrlHelper helper,
            string relativeUriString)
        {
            var request = HttpContextAccessor.HttpContext.Request;
            if (!request.Host.HasValue)
            {
                return relativeUriString;
            }
            var requestUri = new Uri(Microsoft.AspNet.Http.Extensions.UriHelper.GetDisplayUrl(request));
            var absoluteUri = new UriBuilder(request.Scheme, requestUri.Host, requestUri.Port, helper.Content(relativeUriString));
            return absoluteUri.Uri.ToString();
        }

        public static string GetPlainTextFromHtml(this string htmlString)
        {
            const string htmlTagPattern = "<.*?>";
            var regexCss = new Regex("(\\<script(.+?)\\</script\\>)|(\\<style(.+?)\\</style\\>)", RegexOptions.Singleline | RegexOptions.IgnoreCase);
            htmlString = regexCss.Replace(htmlString, string.Empty);
            htmlString = Regex.Replace(htmlString, htmlTagPattern, string.Empty);
            htmlString = Regex.Replace(htmlString, @"^\s+$[\r\n]*", "", RegexOptions.Multiline);
            htmlString = htmlString.Replace("&nbsp;", string.Empty);

            return htmlString;
        }
    }
}
