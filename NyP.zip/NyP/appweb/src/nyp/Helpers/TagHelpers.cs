﻿using Microsoft.AspNet.Mvc.Rendering;
using Microsoft.AspNet.Mvc.ViewFeatures;
using Microsoft.AspNet.Razor.TagHelpers;
using Microsoft.Extensions.WebEncoders;
using PagedList;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace nyp.Helpers
{
    public class ArbolNode
    {
        public long Id { get; set; }
        public int Order { get; set; }
        public long? ParentId { get; set; }
        public string Nombre { get; set; }
    }


    [HtmlTargetElement("arbol", Attributes = CategoriasAttributeName)]
    [HtmlTargetElement("arbol", Attributes = ActionAttributeName)]
    [HtmlTargetElement("arbol", Attributes = ControllerAttributeName)]
    [HtmlTargetElement("arbol", Attributes = FragmentAttributeName)]
    [HtmlTargetElement("arbol", Attributes = HostAttributeName)]
    [HtmlTargetElement("arbol", Attributes = ProtocolAttributeName)]

    [HtmlTargetElement("arbol", Attributes = UlClassAttributeName)]
    [HtmlTargetElement("arbol", Attributes = UlDropdownAnchorClassAttributeName)]
    [HtmlTargetElement("arbol", Attributes = UlDropdownListClassAttributeName)]

    [HtmlTargetElement("arbol", Attributes = RecursiveAttributeName)]

    [HtmlTargetElement("arbol", Attributes = StartingCategoryAttributeName)]
    public class ArbolCategoriasTagHelper : TagHelper
    {
        private const string CategoriasAttributeName = "nyp-categorias";
        private const string ActionAttributeName = "nyp-action";
        private const string ControllerAttributeName = "nyp-controller";
        private const string FragmentAttributeName = "nyp-fragment";
        private const string HostAttributeName = "nyp-host";
        private const string ProtocolAttributeName = "nyp-protocol";
        private const string UlClassAttributeName = "nyp-ul-class";
        private const string UlDropdownAnchorClassAttributeName = "nyp-dropdown-a-class";
        private const string UlDropdownListClassAttributeName = "nyp-dropdown-ul-class";
        private const string StartingCategoryAttributeName = "nyp-categoria-inicial";
        private const string RecursiveAttributeName = "nyp-recursivo";


        [HtmlAttributeName(RecursiveAttributeName)]
        public bool Recursivo { get; set; }

        /// <summary>
        /// Diccionario con categorias para dibujar árbol
        /// </summary>
        [HtmlAttributeName(CategoriasAttributeName)]
        public ICollection<ArbolNode> Categorias { get; set; }

        [HtmlAttributeName(UlClassAttributeName)]
        public string UlClass { get; set; }

        [HtmlAttributeName(UlDropdownAnchorClassAttributeName)]
        public string DropdownAnchorClass { get; set; }

        [HtmlAttributeName(UlDropdownListClassAttributeName)]
        public string DropdownListClass { get; set; }

        [HtmlAttributeName(StartingCategoryAttributeName)]
        public long? StartingCategory { get; set; }

        // <summary>
        /// The name of the action method.
        /// </summary>
        [HtmlAttributeName(ActionAttributeName)]
        public string Action { get; set; }

        /// <summary>
        /// The name of the controller.
        /// </summary>
        [HtmlAttributeName(ControllerAttributeName)]
        public string Controller { get; set; }

        /// <summary>
        /// The protocol for the URL, such as &quot;http&quot; or &quot;https&quot;.
        /// </summary>
        [HtmlAttributeName(ProtocolAttributeName)]
        public string Protocol { get; set; }

        /// <summary>
        /// The host name.
        /// </summary>
        [HtmlAttributeName(HostAttributeName)]
        public string Host { get; set; }

        /// <summary>
        /// The URL fragment name.
        /// </summary>
        [HtmlAttributeName(FragmentAttributeName)]
        public string Fragment { get; set; }


        protected IHtmlGenerator Generator { get; set; }

        public ArbolCategoriasTagHelper(IHtmlGenerator generator)
        {
            Generator = generator;
        }

        private TagBuilder lista(long? categoriaId)
        {

            var items = from it in Categorias
                        where it.ParentId == categoriaId
                        orderby it.Order
                        select it;
            var itemCount = items.Count();
            if (itemCount > 0)
            {
                var ul = new TagBuilder("ul");
                if (categoriaId == StartingCategory)
                {
                    ul.AddCssClass(UlClass);
                }
                else
                {
                    ul.AddCssClass(DropdownListClass);
                    ul.MergeAttribute("data-role", "dropdown");
                }

                foreach (var item in items)
                {
                    TagBuilder submenu = null;
                    if (Recursivo)
                    {
                        submenu = lista(item.Id); // depth first
                    }
                    var li = new TagBuilder("li");
                    var routeValues = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    routeValues.Add("id", item.Id.ToString());
                    var anchor = Generator.GenerateActionLink(linkText: item.Nombre,
                                                                  actionName: Action,
                                                                  controllerName: Controller,
                                                                  hostname: Host,
                                                                  protocol: Protocol,
                                                                  fragment: Fragment,
                                                                  routeValues: routeValues.ToDictionary(kvp => kvp.Key, kvp => (object)kvp.Value, StringComparer.OrdinalIgnoreCase),
                                                                  htmlAttributes: new { data_id = item.Id, data_order = item.Order });
                    if (submenu != null)
                    {
                        anchor.AddCssClass(DropdownAnchorClass);
                    }

                    li.InnerHtml.Append(anchor);
                    li.InnerHtml.Append(submenu);
                    ul.InnerHtml.Append(li);
                }

                return ul;
            }
            return null;
        }



        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            var tree = lista(StartingCategory);


            output.PreElement.SetContent(tree);
            output.PostElement.SetContent("");
        }
    }

    public class PagedListTagHelper : TagHelper
    {
        IPagedList _Enumerable = null;
        public IEnumerable Enumerable
        {
            get
            {
                yield return _Enumerable;
            }
            set
            {
                if (value is IPagedList)
                    _Enumerable = value as IPagedList;
                else
                    throw new System.Exception("Enumerable debe ser IPagedList");
            }
        }

        public string LinkURL { get; set; }

        protected IHtmlEncoder HtmlEncoder { get; set; }

        public PagedListTagHelper( IHtmlEncoder htmlEncoder)
        {
            HtmlEncoder = htmlEncoder;
        }


        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            {
                var url = context.AllAttributes["link-url"];
                output.TagName = "nav";
                output.PreContent.SetContent("<ul class=\"pagination pagination-sm\"><li><a href=\"#\" aria-label=\"Previous\"><span aria-hidden=\"true\">&laquo;</span></a></li>");

                for (var i = 1; i <= _Enumerable.PageCount; i++)
                {
                    var a = new TagBuilder("a");
                    a.MergeAttribute("href", $"{url}?page={i}");
                    a.MergeAttribute("title", $"Navegar a página {i}");
                    var li = new TagBuilder("li");
                    if (i == _Enumerable.PageNumber)
                    {
                        li.AddCssClass("active");
                        var span = new TagBuilder("span");
                        span.AddCssClass("sr-only");
                        span.InnerHtml.Append(i.ToString());
                        a.InnerHtml.Append(span);
                    }
                    else
                    {
                        a.InnerHtml.Append(i.ToString());
                    }
                    li.InnerHtml.Append(a);
                    output.Content.Append(li);
                }
                output.PostContent.SetContent("<li><a href=\"#\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li></ul>");
            }
        }
    }
}