﻿using Microsoft.AspNet.Builder;
using Microsoft.AspNet.Http;
using System.Globalization;
using System.Threading;
using System.Threading.Tasks;

namespace nyp.Middleware
{
    public class NYPRequestLocalizationMiddleware
    {
        private readonly RequestDelegate _next;

        public NYPRequestLocalizationMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            var defaultCulture = new CultureInfo("es-CL");
            SetCurrentCulture(defaultCulture, defaultCulture);
            await _next(context);
        }

        private void SetCurrentCulture(CultureInfo culture, CultureInfo uiCulture)
        {
#if DNXCORE50
            CultureInfo.CurrentCulture = culture;
            CultureInfo.CurrentUICulture = uiCulture;
#else
            Thread.CurrentThread.CurrentCulture = culture;
            Thread.CurrentThread.CurrentUICulture = uiCulture;
#endif
        }
    }
}