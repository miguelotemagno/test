﻿using Microsoft.AspNet.Mvc.Routing;
using System;
using System.Web;

namespace nyp.Helpers
{
    public static class UrlHelperExtensions
    {

        /*public static string Content(this UrlHelper urlHelper, string contentPath, bool toAbsolute = false)
        {
            var path = urlHelper.Content(contentPath);
            var url = new Uri(HttpContext.Current.Request.Url, path);

            return toAbsolute ? url.AbsoluteUri : path;
        }
        */
    }
}
