﻿using Microsoft.AspNet.Authorization;
using Microsoft.AspNet.Mvc;
using Microsoft.Data.Entity;
using Newtonsoft.Json;
using nyp.DataModels;
using nyp.Filters;
using nyp.Models;
using nyp.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using nyp.Extensions;
using nyp.Helpers;
using nyp.GestorDocumental.Service;
using Microsoft.AspNet.Hosting;
using Newtonsoft.Json.Linq;

namespace nyp.Controllers
{
    class UsuarioListaDistribucionEqualityComparer : IEqualityComparer<UsuariosEnListaDistribucion>
    {
        public bool Equals(UsuariosEnListaDistribucion left, UsuariosEnListaDistribucion right)
        {
            return left.ListaDistribucionId == right.ListaDistribucionId && left.UsuarioIntranetId == right.UsuarioIntranetId;
        }

        public int GetHashCode(UsuariosEnListaDistribucion obj)
        {
            return obj.GetHashCode();
        }
    }

    class EmailEqualityComparer : IEqualityComparer<ResultadoValidacionCorreos>
    {
        public bool Equals(ResultadoValidacionCorreos left, ResultadoValidacionCorreos right)
        {
            return left.Email == right.Email;
        }

        public int GetHashCode(ResultadoValidacionCorreos obj)
        {
            return obj.Email.GetHashCode();
        }
    }

    //prueba
    [Authorize]
    [ServiceFilter(typeof(OcultarMenuLateralFilter))]
    public class AdminController : ControllerConNotificacion
    {
        public AdminController(
            IEmailSender mailSenderService,
            NYPContext context,
            IGestorDocumental gestorDocumental,
            IHostingEnvironment env,
            ISessionService sessionContext)
            : base(mailSenderService, context, gestorDocumental, env, sessionContext)
        {
        }

        #region Categorias

        public IActionResult AgregarCategoriaRaiz([Bind("NuevaCategoria")]string NuevaCategoria)
        {
            dbContext.Categorias.Add(new Categoria()
            {
                Nombre = NuevaCategoria,
                Orden = 0
            });
            dbContext.SaveChanges();
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("ConfigurarCategorias");
        }

        public IActionResult ConfigurarCategorias()
        {
            var c = dbContext.Categorias.ToList();
            ViewBag.RutaServer = getRutaServer();
            return View(c);
        }

        [HttpPost]
        [Produces("application/json")]
        public IActionResult ConfigurarCategorias([FromBody] Changes changes)
        {
            var added = new Dictionary<string, Categoria>();
            string MensajeError = "";
            var prefs = new Preferencias(dbContext);
            // ---------------------------------------
            // ADD
            // ---------------------------------------
            // Se pueden agregar nuevas categorías y a estas nuevas categorías, a su vez,
            // agregar otra más. Dado que lo único que nos indica que una categoría es 
            // nueva es que su Id no es numérico, usamos esto a nuestro favor.
            if (changes.Adds.Any())
            {
                var missingParent = new Dictionary<Categoria, string>();


                    // Primero creamos categorías, sin parent.
                    foreach (var n in changes.Adds)
                    {

                        var newcat = new Categoria
                        {
                            Nombre = n.Text,
                            Children = new List<Categoria>()
                        };
                        long id;
                        if (long.TryParse(n.ParentId, out id))
                        {
                            var parent = (from c in dbContext.Categorias.Include(t => t.Children)
                                          where c.Id == id
                                          select c).FirstOrDefault();
                            parent.Children.Add(newcat);
                        }
                        else
                        {
                            missingParent.Add(newcat, n.ParentId);
                        }
                        try
                        {
                            added.Add(n.Id, newcat);
                        } catch (Exception e)
                        {
                            MensajeError = e.Message; 
                        }
                    }

                    // Luego, le buscamos el parent correspondiente a aquellos que se agregaron bajo
                    // un nuevo nodo
                    foreach (var pair in missingParent)
                    {
                        added[pair.Value].Children.Add(pair.Key);
                    }

                    dbContext.Categorias.AddRange(added.Values.ToArray());
                
            }

            // ---------------------------------------
            // DELETE
            // ---------------------------------------
            if (changes.Deletes.Any())
            {
                var ids = (from c in changes.Deletes select c.Id).ToList();
                List<long> idCategoriasBorrables = new List<long>();
                List<long> idCategoriasNoBorrables = new List<long>();
                long? testCategoriaVacia, testCategoriaPadre;

                foreach (var id in ids)
                {
                    testCategoriaVacia = (from c in dbContext.CategoriasEnPublicacion
                                          where id == c.CategoriaId
                                          select c.CategoriaId).FirstOrDefault();
                    if (testCategoriaVacia == 0)
                    {

                        //no puede borrarse tasas y comisiones del árbol 
                        if (id == prefs.TasasID)
                        {
                            idCategoriasNoBorrables.Add(id);

                        }
                        else
                        {
                            //la categoria no tiene publicaciones. 
                            //Tampoco se podrá borrar una categoria que tenga a su vez categorias. 
                            testCategoriaPadre = (from c in dbContext.Categorias
                                                  where id == c.CategoriaId
                                                  select c.Id).FirstOrDefault();
                            if (testCategoriaPadre == 0)
                            {

                                var testEnlances = (from e in dbContext.EnlacesCategorias
                                                    where e.CategoriaId == id
                                                    select e.Id).FirstOrDefault();

                                if (testEnlances == 0)
                                {
                                    idCategoriasBorrables.Add(id);
                                }
                                else
                                {
                                    idCategoriasNoBorrables.Add(id);
                                }
                            }
                            else
                            {
                                idCategoriasNoBorrables.Add(id);
                            }
                        }
                    }
                    else
                    {
                        idCategoriasNoBorrables.Add(id);
                    }
                }

                var deletes = from c in dbContext.Categorias
                              where idCategoriasBorrables.Contains(c.Id)
                              select c;
                dbContext.Categorias.RemoveRange(deletes.ToArray());

                if (idCategoriasNoBorrables.Count > 0)
                {
                    var noDeletes = from c in dbContext.Categorias
                                    where idCategoriasNoBorrables.Contains(c.Id)
                                    select c;

                    foreach (var cat in noDeletes)
                    {
                        MensajeError += "<li>" + cat.Nombre + "</li>";
                    }

                }



            }

            /*//Respaldo del proceso original de borrado de categorias. 
            if (changes.Deletes.Any())
            {
                var ids = (from c in changes.Deletes
                           select c.Id).ToList();
                var deletes = from c in dbContext.Categorias
                              where ids.Contains(c.Id)
                              select c;
                dbContext.Categorias.RemoveRange(deletes.ToArray());
            }
            //*/
            // ---------------------------------------
            // RENAMES
            // ---------------------------------------
            if (changes.Renames.Any())
            {
                try
                {
                    var renames = (from c in changes.Renames
                                   select c).ToDictionary(t => t.Id, t => t.Text);

                    var ids = renames.Keys.ToArray();

                    var categorias = from c in dbContext.Categorias
                                     where ids.Contains(c.Id)
                                     select c;
                    foreach (var c in categorias)
                    {
                        if (c.Id == prefs.TasasID)
                        {
                            MensajeError += "<li>La Categoría Tasas y Comisiones no puede ser renombrada</li>";
                        }
                        else
                        {
                            c.Nombre = renames[c.Id];
                        }
                    }
                } catch (Exception e)
                {
                    MensajeError += e.Message;
                }
            }


            // ---------------------------------------
            // MOVES
            // ---------------------------------------
            if (changes.Moves.Any())
            {
                var moves = (from m in changes.Moves
                             select m).ToDictionary(t => t.Id, t => t);

                var ids = moves.Keys.ToList();

                if (ids.Contains(prefs.TasasID))
                {
                    ids.Remove(prefs.TasasID);
                    MensajeError += "<li>La Categoría Tasas y Comisiones no puede ser reubicar</li>";

                }

                var categorias = (from c in dbContext.Categorias
                                  where ids.Contains(c.Id)
                                  select c).ToList();

                foreach (var categoria in categorias)
                {
                    var moveOperation = moves[categoria.Id];
                    var oldParent = (from p in dbContext.Categorias.Include(t => t.Children)
                                     where p.Id == moveOperation.OldParent
                                     select p).FirstOrDefault();
                    if (oldParent != null)
                    {
                        oldParent.Children.Remove(categoria);
                    }

                    Categoria newParent = null;
                    long newParentId;
                    if (long.TryParse(moveOperation.NewParent, out newParentId))
                    {
                        newParent = (from p in dbContext.Categorias.Include(t => t.Children)
                                     where p.Id == newParentId
                                     select p).FirstOrDefault();
                    }
                    else
                    {
                        newParent = added[moveOperation.NewParent];
                    }

                    if (newParent != null)
                    {
                        newParent.Children.Add(categoria);
                    }
                }
            }

            // ---------------------------------------
            // REORDENAMIENTO
            // ---------------------------------------
            if (changes.Reorder.Any())
            {
                foreach (var reorder in changes.Reorder)
                {

                    Categoria node = null;
                    long id;

                    if (long.TryParse(reorder.Id, out id))
                    {
                        if (id == prefs.TasasID)
                        {
                            MensajeError += "<li>La Categoría Tasas y Comisiones no puede ser reordenada</li>";
                        }
                    }
                    else
                    {
                        if (long.TryParse(reorder.Id, out id))
                        {
                            node = (from c in dbContext.Categorias where c.Id == id select c).FirstOrDefault();
                            if (node != null)
                            {
                                dbContext.Categorias.Attach(node);
                                dbContext.Entry(node).State = EntityState.Modified;
                            }
                        }
                        else
                        {
                            node = added[reorder.Id];
                        }
                        node.Orden = reorder.Order;
                    }
                }
            }
            try
            {
                dbContext.SaveChanges();
            } catch(Exception e)
            {
                MensajeError += e.Message; 
            }
            return Ok(new
            {
                success = true,
                mensaje = MensajeError
            });
        }

        public IActionResult ConfigurarCategoriaBusqueda()
        {
            ViewBag.Categorias = JsonConvert.SerializeObject(dbContext.ComboCategorias());
            var prefs = new Preferencias(dbContext);
            ViewBag.RutaServer = getRutaServer();
            return View(new ConfigurarCategoriaBusquedaViewModel
            {
                CategoriaBusqueda = prefs.CategoriaBusqueda,
                CategoriaMenuLateral = prefs.CategoriaMenuLateral
            });
        }

        [HttpPost]
        public IActionResult ConfigurarCategoriaBusqueda([Bind("CategoriaBusqueda,CategoriaMenuLateral")]ConfigurarCategoriaBusquedaViewModel model)
        {
            bool evalResponse = ModelState.IsValid;
            string p1 = Request.Form.ElementAt(0).Value;
            string p2 = Request.Form.ElementAt(2).Value;

            if (p1 != "" && p1 != null && p2 != "" && p2 != null)
            {
                evalResponse = true; 
            }


            if (evalResponse)
            {
                var prefs = new Preferencias(dbContext);
                prefs.CategoriaBusqueda = Int64.Parse(p1);//model.CategoriaBusqueda;
                prefs.CategoriaMenuLateral = Int64.Parse(p2);// model.CategoriaMenuLateral;
                prefs.Guardar();


                var cat = (from c in dbContext.Categorias
                           where c.Id == prefs.CategoriaBusqueda
                           select c).FirstOrDefault();

                ConfirmacionVisual("Categoría de Búsqueda Modificada",
                    string.Format("La categoría de búsqueda a desplegar es {0} - {1}", prefs.CategoriaBusqueda, cat.Nombre));
            }
            ViewBag.Categorias = JsonConvert.SerializeObject(dbContext.ComboCategorias());
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        #endregion Categorias

        #region Listas de Distribución
        public IActionResult VerificarListaCorreos(int id)
        {
            var listaDistribucion = (from l in dbContext.ListasDistribucion.Include(t => t.UsuariosEnListaDistribucion)
                                     where l.Id == id
                                     select l).FirstOrDefault();
            if (listaDistribucion == null)
            {
                return HttpBadRequest();
            }
            ViewBag.OrganicaInicial = JsonConvert.SerializeObject(dbContext.OrganicaInicial(null));
            ViewBag.RutaServer = getRutaServer();
            return View(new EditarListaDistribucionDesdeListadoViewModel
            {
                Id = listaDistribucion.Id,
                Nombre = listaDistribucion.Nombre,
                Notas = listaDistribucion.Notas
            });
        }

        [HttpPost]
        public IActionResult VerificarListaCorreos(EditarListaDistribucionDesdeListadoViewModel model)
        {
            ViewBag.OrganicaInicial = JsonConvert.SerializeObject(dbContext.OrganicaInicial(null));
            if (ModelState.IsValid)
            {
                string strRegex = @"\b[A-Za-z0-9_\-\+.]+@([A-Za-z\.-]+)\.([A-Za-z]{2,7})\b";
                Regex regexEmail = new Regex(strRegex, RegexOptions.None);
                var correosExtraidosDesdeTexto = (from m in regexEmail.Matches(model.Texto).Cast<Match>()
                                                  select m.Groups[0].Value).ToArray();
                var comparer = new EmailEqualityComparer();
                var resultado = (from u in dbContext.UsuariosIntranet
                                 where correosExtraidosDesdeTexto.Contains(u.Email)
                                 select new ResultadoValidacionCorreos
                                 {
                                     Email = u.Email,
                                     Usuario = u
                                 })
                                 .ToList() // Linq no está listo para distinct aún
                                 .Distinct(comparer)
                                 .ToList();

                var encontrados = from u in resultado
                                  select u.Email;
                var faltantes = from faltante in correosExtraidosDesdeTexto.Except(encontrados)
                                select new ResultadoValidacionCorreos
                                {
                                    Email = faltante,
                                    Valido = false,
                                    MensajeValidacion = "Correo no encontrado"
                                };

                resultado.AddRange(faltantes);

                model.ResultadoValidacion = resultado;
                ViewBag.RutaServer = getRutaServer();
                return View(model);
            }
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        [HttpPost]
        public IActionResult AgregarUsuariosListaDistribucion(AgregarUsuariosListaDistribucionViewModel model)
        {
            if (ModelState.IsValid)
            {
                var listaDistribucion = (from l in dbContext.ListasDistribucion.Include(t => t.UsuariosEnListaDistribucion)
                                         where l.Id == model.Id
                                         select l).FirstOrDefault();
                if (listaDistribucion != null)
                {
                    var comparer = new UsuarioListaDistribucionEqualityComparer();
                    var lst = (from u in dbContext.UsuariosIntranet
                               where model.Usuarios.Contains(u.Id)
                               select new UsuariosEnListaDistribucion
                               {
                                   ListaDistribucionId = model.Id,
                                   UsuarioIntranetId = u.Id
                               }).ToList();
                    var add = (from u in lst
                               where !listaDistribucion.UsuariosEnListaDistribucion.Contains(u, comparer)
                               select u).ToList();
                    foreach (var u in add)
                    {
                        listaDistribucion.UsuariosEnListaDistribucion.Add(u);
                    }
                    dbContext.SaveChanges();
                    ViewBag.RutaServer = getRutaServer();
                    return RedirectToAction("ListasDistribucion");
                }
            }
            return HttpBadRequest();
        }

        [HttpPost]
        public IActionResult ListaCorreoDesdeOrganica(EditarListaDistribucionDesdeOrganicaViewModel model)
        {
            if (ModelState.IsValid)
            {
                var listaDistribucion = (from l in dbContext.ListasDistribucion.Include(t => t.UsuariosEnListaDistribucion)
                                         where l.Id == model.Id
                                         select l).FirstOrDefault();
                if (listaDistribucion == null)
                {
                    return HttpBadRequest();
                }
                var aux = dbContext.OrganicaInicial(model.OrganicaId);
                var unidades = new List<int>();
                foreach (var it in aux.Traverse(t => t.children))
                {
                    if (it.id == model.OrganicaId)
                    {
                        var stack = new Stack<ComboTreeViewModel>(new List<ComboTreeViewModel>() { it });
                        while (stack.Any())
                        {
                            var next = stack.Pop();
                            if (next.id.StartsWith("u"))
                            {
                                unidades.Add(Convert.ToInt32(next.id.Substring(1)));
                            }
                            if (next.children != null)
                            {
                                foreach (var child in next.children)
                                {
                                    stack.Push(child);
                                }
                            }
                        }
                        break;
                    }
                }

                return View(new AgregarUsuariosListaDistribucionViewModel
                {
                    Id = listaDistribucion.Id,
                    Usuarios = (from u in dbContext.UsuariosIntranet.Include(t => t.Unidad)
                                where unidades.Contains(u.UnidadId)
                                select u.Id).ToArray()
                });
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("VerificarListaCorreos", new { id = model.Id });
        }

        public IActionResult ListasDistribucion()
        {
            var lst = from l in dbContext.ListasDistribucion.Include(t => t.UsuariosEnListaDistribucion)
                      select l;
            ViewBag.ListasDistribucion = lst;
            ViewBag.RutaServer = getRutaServer();
            return View();
        }

        public IActionResult NuevaListaDistribucion()
        {
            ViewBag.RutaServer = getRutaServer();
            return View();
        }

        [HttpPost]
        public IActionResult NuevaListaDistribucion(NuevaListaDistribucioViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = (from u in dbContext.UsuariosIntranet
                            where u.Id == session.DatosUsuario.RUT
                            select u).FirstOrDefault();
                var lst = new ListaDistribucion()
                {
                    Nombre = model.Nombre,
                    Notas = model.Notas,
                    Historial = new List<EventoConfiguracion>() { new EventoConfiguracion { Autor = user } }
                };
                dbContext.ListasDistribucion.Add(lst);
                dbContext.SaveChanges();
                TempData["MostrarConfirmacion"] = true;
                ViewBag.RutaServer = getRutaServer();
                return RedirectToAction("ListasDistribucion");
            }
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        public IActionResult VerListaDistribucion(int id)
        {
            var listaDistribucion = (from l in dbContext.ListasDistribucion.Include(t => t.UsuariosEnListaDistribucion).ThenInclude(t => t.UsuarioIntranet).ThenInclude(t => t.Unidad)
                                     where l.Id == id
                                     select l).FirstOrDefault();
            if (listaDistribucion == null)
            {
                return HttpBadRequest();
            }
            ViewBag.RutaServer = getRutaServer();
            return View(listaDistribucion);
        }

        public IActionResult EditarListaDistribucion(int id)
        {
            var listaDistribucion = (from l in dbContext.ListasDistribucion.Include(t => t.UsuariosEnListaDistribucion)
                                     where l.Id == id
                                     select l).FirstOrDefault();
            ViewBag.RutaServer = getRutaServer();
            return View(new EditarListaDistribucionViewModel
            {
                Id = listaDistribucion.Id,
                Nombre = listaDistribucion.Nombre,
                Notas = listaDistribucion.Notas,
                Usuarios = (from u in listaDistribucion.UsuariosEnListaDistribucion
                            select u.UsuarioIntranetId
                                ).ToArray()
            });
        }

        [HttpPost]
        public IActionResult EditarListaDistribucion(EditarListaDistribucionViewModel model)
        {
            if (ModelState.IsValid)
            {
                var listaDistribucion = (from l in dbContext.ListasDistribucion.Include(t => t.UsuariosEnListaDistribucion)
                                         where l.Id == model.Id
                                         select l).FirstOrDefault();
                if (listaDistribucion != null)
                {
                    var listaRuts = model.Usuarios;
                    if (listaRuts == null)
                    {
                        foreach (var it in listaDistribucion.UsuariosEnListaDistribucion.ToList())
                        {
                            dbContext.UsuariosEnListaDistribucion.Remove(it);
                        }
                        listaDistribucion.UsuariosEnListaDistribucion.Clear();
                    }
                    else
                    {
                        var nuevaLista = (from rut in listaRuts
                                          select new UsuariosEnListaDistribucion
                                          {
                                              ListaDistribucionId = model.Id,
                                              UsuarioIntranetId = rut
                                          }).ToList();

                        var comparer = new UsuarioListaDistribucionEqualityComparer();

                        var toDelete = from i in listaDistribucion.UsuariosEnListaDistribucion
                                       where !nuevaLista.Contains(i, comparer)
                                       select i;

                        foreach (var it in toDelete.ToList())
                        {
                            listaDistribucion.UsuariosEnListaDistribucion.Remove(it);
                            dbContext.UsuariosEnListaDistribucion.Remove(it);
                        }


                        var toAdd = from i in nuevaLista
                                    where !listaDistribucion.UsuariosEnListaDistribucion.Contains(i, comparer)
                                    select i;
                        foreach (var it in toAdd.ToList())
                        {
                            listaDistribucion.UsuariosEnListaDistribucion.Add(it);
                        }

                    }
                    listaDistribucion.Nombre = model.Nombre;
                    listaDistribucion.Notas = model.Notas;
                    dbContext.SaveChanges();
                }
                ViewBag.RutaServer = getRutaServer();
                return RedirectToAction("VerListaDistribucion", new { id = model.Id });
            }
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        public IActionResult AgregarUsuariosListaDistribucion(int id)
        {
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("VerificarListaCorreos", new { id = id });
        }

        public IActionResult EliminarListaDistribucion(int id)
        {
            var listaDistribucion = (from l in dbContext.ListasDistribucion
                                     where l.Id == id
                                     select l).FirstOrDefault();
            if (listaDistribucion != null)
            {
                ViewBag.RutaServer = getRutaServer();
                return View(new EliminarListaDistribucionViewModel
                {
                    ListaId = id,
                    Autor = session.DatosUsuario.RUT
                });
            }
            return HttpNotFound();
        }

        [HttpPost]
        public IActionResult EliminarListaDistribucion(EliminarListaDistribucionViewModel model)
        {
            var listaDistribucion = (from l in dbContext.ListasDistribucion
                                        .Include(t => t.UsuariosEnListaDistribucion)
                                        .Include(t => t.Historial)
                                     where l.Id == model.ListaId
                                     select l).FirstOrDefault();
            if (listaDistribucion != null)
            {
                dbContext.UsuariosEnListaDistribucion.RemoveRange(listaDistribucion.UsuariosEnListaDistribucion);
                dbContext.ListasDistribucion.Remove(listaDistribucion);
                listaDistribucion.Historial.Clear();
                dbContext.SaveChanges();
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("ListasDistribucion");
        }

        class UsuarioExcel
        {
            public int Id { get; set; }
            public string ApellidoPaterno { get; set; }
            public string ApellidoMaterno { get; set; }
            public string Nombres { get; set; }
            public string Email { get; set; }
            public string Unidad { get; set; }
        }

        public IActionResult ExportarListaDistribucion(int id)
        {
            var listado = (from l in dbContext.ListasDistribucion.Include(t => t.UsuariosEnListaDistribucion)
                           .ThenInclude(u => u.UsuarioIntranet)
                           .ThenInclude(t => t.Unidad)
                           where l.Id == id
                           select l).FirstOrDefault();
            if (listado == null)
            {
                return HttpBadRequest();
            }

            var usuarios = from u in listado.UsuariosEnListaDistribucion
                           select new UsuarioExcel
                           {
                               Id = u.UsuarioIntranet.Id,
                               ApellidoMaterno = u.UsuarioIntranet.ApellidoMaterno,
                               ApellidoPaterno = u.UsuarioIntranet.ApellidoPaterno,
                               Email = u.UsuarioIntranet.Email,
                               Unidad = u.UsuarioIntranet.Unidad.Nombre,
                               Nombres = u.UsuarioIntranet.Nombres
                           };

            return new ExcelFileResult<UsuarioExcel>(usuarios, listado.Nombre);
        }

        #endregion

        #region Analistas (Usuarios)
        public IActionResult ConfigurarAnalistas()
        {
            var analistas = from u in dbContext.UsuariosIntranet
                            where u.AnalistaNYP == true
                            select u;
            ViewBag.RutaServer = getRutaServer();
            return View(analistas);
        }

        private IActionResult CambiarEstadoUsuario(int id, bool AnalistaNYP)
        {
            var analista = (from u in dbContext.UsuariosIntranet
                            where u.Id == id
                            select u).FirstOrDefault();
            if (analista != null)
            {
                analista.AnalistaNYP = AnalistaNYP;
                dbContext.UsuariosIntranet.Update(analista);
                dbContext.SaveChanges();
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("ConfigurarAnalistas");
        }

        [HttpPost]
        public IActionResult EliminarAnalista(int id)
        {
            ViewBag.RutaServer = getRutaServer();
            return CambiarEstadoUsuario(id, false);
        }

        [HttpPost]
        public IActionResult AgregarAnalista(int id)
        {
            ViewBag.RutaServer = getRutaServer();
            return CambiarEstadoUsuario(id, true);
        }
        #endregion

        #region Noticias
        public IActionResult ConfigurarNoticias()
        {
            var noticias = from n in dbContext.Noticias
                           select n;
            ViewBag.RutaServer = getRutaServer();
            return View(noticias);
        }

        [HttpPost]
        public IActionResult EliminarNoticia(int id)
        {
            var noticia = (from n in dbContext.Noticias
                           where n.Id == id
                           select n).FirstOrDefault();
            if (noticia != null)
            {
                dbContext.Noticias.Remove(noticia);
                dbContext.SaveChanges();
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("ConfigurarNoticias");
        }

        public IActionResult AgregarNoticia()
        {
            ViewBag.RutaServer = getRutaServer();
            return View(new NoticiaViewModel());
        }

        [HttpPost]
        public IActionResult AgregarNoticia(NoticiaViewModel nueva)
        {
            if (ModelState.IsValid)
            {
                var noticia = new Noticia()
                {
                    Titulo = nueva.Titulo,
                    Cuerpo = nueva.Contenido,
                    Fecha = DateTime.Now,
                    Autor = session.DatosUsuario.Nombre
                };
                dbContext.Noticias.Add(noticia);
                dbContext.SaveChanges();
                return RedirectToAction("ConfigurarNoticias");
            }
            ViewBag.RutaServer = getRutaServer();
            return View();
        }

        public IActionResult EditarNoticia(int id)
        {
            var noticia = (from n in dbContext.Noticias
                           where n.Id == id
                           select n).FirstOrDefault();
            if (noticia != null)
            {
                ViewBag.RutaServer = getRutaServer();
                return View(new NoticiaViewModel
                {
                    Id = noticia.Id,
                    Contenido = noticia.Cuerpo,
                    Titulo = noticia.Titulo
                });
            }
            return HttpNotFound();
        }

        [HttpPost]
        public IActionResult EditarNoticia(NoticiaViewModel model)
        {
            if (ModelState.IsValid && model.Id > 0)
            {
                var noticia = (from n in dbContext.Noticias
                               where n.Id == model.Id
                               select n).FirstOrDefault();
                if (noticia != null)
                {
                    noticia.Titulo = model.Titulo;
                    noticia.Cuerpo = model.Contenido;
                    noticia.Fecha = DateTime.Now;
                    noticia.Autor = session.DatosUsuario.Nombre;
                    dbContext.SaveChanges();
                    ViewBag.RutaServer = getRutaServer();
                    return RedirectToAction("ConfigurarNoticias");
                }
            }
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }


        #endregion

        #region Secciones
        public IActionResult ConfigurarSecciones()
        {
            var secciones = from n in dbContext.Secciones
                            select n;
            ViewBag.RutaServer = getRutaServer();
            return View(secciones);
        }

        [HttpPost]
        public IActionResult EliminarSeccion(int id)
        {
            var seccion = (from n in dbContext.Secciones
                           where n.Id == id
                           select n).FirstOrDefault();
            if (seccion != null)
            {
                dbContext.Secciones.Remove(seccion);
                dbContext.SaveChanges();
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("ConfigurarSecciones");
        }

        public IActionResult AgregarSeccion()
        {
            ViewBag.RutaServer = getRutaServer();
            return View(new NoticiaViewModel());
        }

        [HttpPost]
        public IActionResult AgregarSeccion(NoticiaViewModel nueva)
        {
            if (ModelState.IsValid)
            {
                var seccion = new Seccion()
                {
                    Titulo = nueva.Titulo,
                    Cuerpo = nueva.Contenido
                };
                dbContext.Secciones.Add(seccion);
                dbContext.SaveChanges();
                ViewBag.RutaServer = getRutaServer();
                return RedirectToAction("ConfigurarSecciones");
            }
            ViewBag.RutaServer = getRutaServer();
            return View();
        }

        public IActionResult EditarSeccion(int id)
        {
            var seccion = (from n in dbContext.Secciones
                           where n.Id == id
                           select n).FirstOrDefault();
            if (seccion != null)
            {
                ViewBag.RutaServer = getRutaServer();
                return View(new NoticiaViewModel
                {
                    Id = seccion.Id,
                    Contenido = seccion.Cuerpo,
                    Titulo = seccion.Titulo
                });
            }
            return HttpNotFound();
        }

        [HttpPost]
        public IActionResult EditarSeccion(NoticiaViewModel model)
        {
            if (ModelState.IsValid && model.Id > 0)
            {
                var seccion = (from s in dbContext.Secciones
                               where s.Id == model.Id
                               select s).FirstOrDefault();
                if (seccion != null)
                {
                    seccion.Titulo = model.Titulo;
                    seccion.Cuerpo = model.Contenido;
                    dbContext.SaveChanges();
                    ViewBag.RutaServer = getRutaServer();
                    return RedirectToAction("ConfigurarSecciones");
                }
            }
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        #endregion

        #region Páginas
        public IActionResult ConfigurarPaginas()
        {
            ConfigurarPaginaViewModel model = CrearConfigurarPaginaViewModel();
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        private ConfigurarPaginaViewModel CrearConfigurarPaginaViewModel()
        {
            var model = new ConfigurarPaginaViewModel();
            model.Paginas = (from n in dbContext.PaginasContenidos
                             select n).ToList();
            model.PaginasPredeterminadas = (from p in dbContext.Propiedades
                                            where p.Id.StartsWith("Pagina")
                                            select p).ToList();
            return model;
        }

        [HttpPost]
        public IActionResult EliminarPagina(int id)
        {
            var pagina = (from n in dbContext.PaginasContenidos
                          where n.Id == id
                          select n).FirstOrDefault();
            if (pagina != null)
            {
                dbContext.PaginasContenidos.Remove(pagina);
                dbContext.SaveChanges();
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("ConfigurarPaginas");
        }

        public IActionResult AgregarPagina()
        {
            ViewBag.RutaServer = getRutaServer();
            return View("EditarPagina", new PaginaViewModel());
        }

        public IActionResult EditarPagina(int id)
        {
            var pagina = (from p in dbContext.PaginasContenidos.Include(t => t.Autor)
                          where p.Id == id
                          select new PaginaViewModel()
                          {
                              Id = p.Id,
                              Contenido = p.Contenido,
                              Titulo = p.Titulo
                          }).FirstOrDefault();
            if (pagina == null)
            {
                return HttpNotFound();
            }
            ViewBag.RutaServer = getRutaServer();
            return View("EditarPagina", pagina);
        }

        [HttpPost]
        public IActionResult ConfigurarPaginaPredeterminada(ConfigurarPaginaViewModel model)
        {
            if (ModelState.IsValid)
            {
                // TODO: esto es lo más simple pero poco óptimo.
                foreach (var pag in model.PaginasPredeterminadas)
                {
                    var entry = (from p in dbContext.Propiedades
                                 where p.Id == pag.Id
                                 select p).FirstOrDefault();
                    entry.Valor = pag.Valor;
                    dbContext.SaveChanges();
                }
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("ConfigurarPaginas");
        }

        [HttpPost]
        public IActionResult GuardarPagina(PaginaViewModel nueva)
        {
            if (ModelState.IsValid)
            {
                var autor = (from u in dbContext.UsuariosIntranet
                             where u.Id == session.DatosUsuario.RUT
                             select u).FirstOrDefault();

                PaginaContenidos pagina;
                if (nueva.Id != null)
                {
                    pagina = (from p in dbContext.PaginasContenidos
                              where p.Id == nueva.Id.Value
                              select p).FirstOrDefault();

                    if (pagina == null)
                    {
                        return HttpBadRequest();
                    }
                }
                else
                {
                    pagina = new PaginaContenidos();
                    dbContext.PaginasContenidos.Add(pagina);
                }
                pagina.Titulo = nueva.Titulo;
                pagina.Contenido = nueva.Contenido;
                pagina.Autor = autor;
                pagina.FechaPublicacion = DateTime.Now;
                dbContext.SaveChanges();
                ViewBag.RutaServer = getRutaServer();
                return RedirectToAction("ConfigurarPaginas");
            }
            ViewBag.RutaServer = getRutaServer();
            return View("EditarPagina", nueva);
        }

        #endregion

        #region MantenedorCodigos


        public IActionResult MantenedorCodigos(string msj)
        {
            ViewBag.Codigos = from c in dbContext.CodigosGlosa
                              select c;
            if (msj != "")
            {
                ViewBag.mensaje = msj;
            }
            ViewBag.RutaServer = getRutaServer();
            return View();
        }

        public IActionResult AdminCodigoGlosa(int? Id)
        {

            if (Id != null)
            {
                ViewBag.Nuevo = false;
                ViewBag.Title = "Editar Código de Documento";
                CodigoGlosa model = (from cg in dbContext.CodigosGlosa where cg.Id == Id select cg).FirstOrDefault();
                ViewBag.RutaServer = getRutaServer();
                return View(model);

            }
            else
            {
                ViewBag.Nuevo = true;
                ViewBag.Title = "Agregar nuevo Código de Documento";
                ViewBag.RutaServer = getRutaServer();
                return View();
            }

        }

        public IActionResult AdminCodigoGlosaRegister(CodigoGlosa elemento)
        {
            string mensaje = "";
            if (elemento.Id == 0)
            {

                // validar codigo de documento no se puede repetir. 
                var TestGlosa = (from c in dbContext.CodigosGlosa
                                 where c.CodigoDocumento == elemento.CodigoDocumento
                                 select c).FirstOrDefault();
                if (TestGlosa == null)
                {
                    mensaje += "I" + elemento.CodigoDocumento;
                    dbContext.CodigosGlosa.Add(elemento);
                    dbContext.SaveChanges();
                }
                else
                {
                    mensaje += "E" + elemento.CodigoDocumento;
                }
            }
            else
            {
                mensaje += "U" + elemento.CodigoDocumento;
                dbContext.CodigosGlosa.Attach(elemento);
                dbContext.Entry(elemento).State = EntityState.Modified;
                dbContext.SaveChanges();
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("MantenedorCodigos", new { msj = mensaje });
        }




        #endregion

        #region Configuración

        public IActionResult Configuracion(ConfiguracionViewModel model)
        {
            if (model.CheckSum() > 0)
            {
                var entry = (from p in dbContext.Propiedades
                             where p.Id == "SLA1"
                             select p).FirstOrDefault();
                entry.Valor = model.SLA1.ToString();
                dbContext.SaveChanges();

                entry = (from p in dbContext.Propiedades
                         where p.Id == "SLA2"
                         select p).FirstOrDefault();
                entry.Valor = model.SLA2.ToString();
                dbContext.SaveChanges();

                entry = (from p in dbContext.Propiedades
                         where p.Id == "SLA3"
                         select p).FirstOrDefault();
                entry.Valor = model.SLA3.ToString();
                dbContext.SaveChanges();

                entry = (from p in dbContext.Propiedades
                         where p.Id == "AlertaRoja"
                         select p).FirstOrDefault();
                entry.Valor = model.AlertaRoja.ToString();
                dbContext.SaveChanges();

                entry = (from p in dbContext.Propiedades
                         where p.Id == "AlertaNaranja"
                         select p).FirstOrDefault();
                entry.Valor = model.AlertaNaranja.ToString();
                dbContext.SaveChanges();

                entry = (from p in dbContext.Propiedades
                         where p.Id == "AlertaVerde"
                         select p).FirstOrDefault();
                entry.Valor = model.AlertaVerde.ToString();
                dbContext.SaveChanges();
            }
            else
            {
                var prefs = new Preferencias(dbContext);
                model = new ConfiguracionViewModel();
                model.SLA1 = prefs.SLA1;
                model.SLA2 = prefs.SLA2;
                model.SLA3 = prefs.SLA3;
                model.AlertaNaranja = prefs.AlertaNaranja;
                model.AlertaRoja = prefs.AlertaRoja;
                model.AlertaVerde = prefs.AlertaVerde;
            }
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }
        #endregion

        #region Tasas y Comisiones

        public IActionResult TasasComisiones()
        {
            TasasComisionesViewModel respuesta = new TasasComisionesViewModel();
            respuesta.categorias = (from c in dbContext.Categorias
                                    where c.CategoriaId == null
                                    select c).ToList();

            var prefs = new Preferencias(dbContext);
            respuesta.TasaCategoriaRaiz = new Categoria(); 
            respuesta.TasaCategoriaRaiz.Id = prefs.TasasID;
            respuesta.CategoriaRaizId = prefs.TasasID;
            var enlances = (from e in dbContext.EnlacesCategorias.Include(t => t.Categoria)
                            select e).ToList();

            respuesta.Enlaces = enlances;
            ViewBag.RutaServer = getRutaServer();
            return View(respuesta);
        }


        public IActionResult AgregarEnlace()
        {
            var prefs = new Preferencias(dbContext);
            ViewBag.error = "0";
            List<ComboTreeViewModel> ComboTree;
            Categoria categoria = (from c in dbContext.Categorias
                             where c.Id == prefs.TasasID
                             select c).FirstOrDefault();
            var combo = new ComboTreeViewModel
            {
                id = categoria.Id.ToString(),
                text = categoria.Nombre
            };
            ComboTree = BuscarChildren(combo);
            ViewBag.Categorias = JsonConvert.SerializeObject(ComboTree);
            ViewBag.RutaServer = getRutaServer();
            return View("AgregarEnlace", new EnlaceViewModel());
        }

        public IActionResult MantenerEnlace(EnlaceViewModel model)
        {
            // Validación de que la categoria no tiene hijos. 
            var testCategoria = (from c in dbContext.Categorias
                                 where c.CategoriaId == model.CategoriaId
                                 select c).ToList();
            if (testCategoria.Count > 0)
            {
                var prefs = new Preferencias(dbContext);

                List<ComboTreeViewModel> ComboTree;
                Categoria categoria = (from c in dbContext.Categorias
                                       where c.Id == prefs.TasasID
                                       select c).FirstOrDefault();
                var combo = new ComboTreeViewModel
                {
                    id = categoria.Id.ToString(),
                    text = categoria.Nombre
                };
                ComboTree = BuscarChildren(combo);
                ViewBag.Categorias = JsonConvert.SerializeObject(ComboTree);
                ViewBag.error = 1;
                ViewBag.RutaServer = getRutaServer();
                return View("AgregarEnlace");
            }

            var enlace = new EnlacesCategoria();
            enlace.Categoria = (from c in dbContext.Categorias where c.Id == model.CategoriaId select c).FirstOrDefault();
            enlace.Titulo = model.Titulo;
            enlace.Hipervinculo = model.Hipervinculo;
            dbContext.EnlacesCategorias.Add(enlace);
            dbContext.SaveChanges();
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("TasasComisiones");
        }

        
        public IActionResult EliminarEnlace(int id)
        {
            var enlace = (from n in dbContext.EnlacesCategorias
                           where n.Id == id
                           select n).FirstOrDefault();
            if (enlace != null)
            {
                dbContext.EnlacesCategorias.Remove(enlace);
                dbContext.SaveChanges();
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("TasasComisiones");
        }

        public IActionResult EditarEnlace(int id)
        {
            var enlace = (from c in dbContext.EnlacesCategorias.Include(t => t.Categoria)
                           where c.Id == id
                           select c).FirstOrDefault();
            if (enlace != null)
            {
                var prefs = new Preferencias(dbContext);

                List<ComboTreeViewModel> ComboTree;
                Categoria categoria = (from c in dbContext.Categorias
                                       where c.Id == prefs.TasasID
                                       select c).FirstOrDefault();
                var combo = new ComboTreeViewModel
                {
                    id = categoria.Id.ToString(),
                    text = categoria.Nombre
                };
                ComboTree = BuscarChildren(combo);
                ViewBag.Categorias = JsonConvert.SerializeObject(ComboTree);
                ViewBag.RutaServer = getRutaServer();
                return View(new EnlaceViewModel
                {
                    EnlaceId = enlace.Id,
                    Categoria = enlace.Categoria,
                    CategoriaId = enlace.Categoria.Id,
                    Titulo = enlace.Titulo,
                    Hipervinculo = enlace.Hipervinculo 
                });
            }
            return HttpNotFound();
        }

        public IActionResult ActualizarEnlace(EnlaceViewModel model)
        {

            if (model != null)
            {

                var enlace = new EnlacesCategoria();
                enlace.Id = model.EnlaceId;
                enlace.CategoriaId = model.CategoriaId;
                enlace.Categoria = (from c in dbContext.Categorias where c.Id == model.CategoriaId select c).FirstOrDefault();
                enlace.Titulo = model.Titulo;
                enlace.Hipervinculo = model.Hipervinculo;
                dbContext.EnlacesCategorias.Attach(enlace);
                dbContext.Entry(enlace).State = EntityState.Modified;
                dbContext.SaveChanges();
                ViewBag.RutaServer = getRutaServer();
                return RedirectToAction("TasasComisiones");
            }



            return HttpNotFound();
        }

        private List<ComboTreeViewModel> BuscarChildren(ComboTreeViewModel comboPadre)
        {
            List<ComboTreeViewModel> ChildrenComboTree = null; 
            var categoriasChildren = (from c in dbContext.Categorias
                                   where c.CategoriaId == long.Parse(comboPadre.id)
                                   select c).ToList();
            if (categoriasChildren.Any())
            {
                ChildrenComboTree = new List<ComboTreeViewModel>();
                foreach (var cat in categoriasChildren)
                {
                    var item = new ComboTreeViewModel
                    {
                        id = cat.Id.ToString(),
                        text = cat.Nombre
                    };
                    item.children = BuscarChildren(item);
                    ChildrenComboTree.Add(item);
                }
            }
            return ChildrenComboTree;
        }

        public IActionResult EstablecerRaiz(TasasComisionesViewModel modelo)
        {
            var Codigo = modelo.CategoriaRaizId;
            var prefs = new Preferencias(dbContext);
            prefs.TasasID = Codigo;
            prefs.Guardar();
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("TasasComisiones");
        }

        #endregion


        private String getRutaServer()
        {
            /*
             var prefs = new Preferencias(dbContext);
            return prefs.RutaServer;
            */
            return ""; 
        }
    }
}
