﻿using Microsoft.AspNet.Hosting;
using Microsoft.AspNet.Mvc;
using Microsoft.Data.Entity;
using Newtonsoft.Json.Linq;
using nyp.DataModels;
using nyp.GestorDocumental.Service;
using nyp.Helpers;
using nyp.Models;
using nyp.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nyp.Controllers
{
    public class NotificacionController : ControllerConNotificacion
    {
        public NotificacionController(
            NYPContext context,
            IEmailSender mailSenderService,
            ISessionService sessionContext,
            IGestorDocumental gestorDocumental,
            IHostingEnvironment env)
            : base(mailSenderService, context, gestorDocumental, env, sessionContext)
        {
           
        }

        public async Task<IActionResult> SolicitarVB(long id)
        {
            var solicitud = GetSolicitud(id);
            var prefs = new Preferencias(dbContext);
            int plazo = prefs.SLA1;

            var message = RenderViewToString("~/Views/Templates/SolicitudAutorizacion", new NotificacionSolicitudViewModel
            {
                Solicitud = solicitud,
                DiasPrimeraInsistencia = plazo
            });

            var autorizadores = from a in solicitud.Autorizadores
                                select new Destinatario
                                {
                                    Email = a.UsuarioIntranet.Email,
                                    Nombre = a.UsuarioIntranet.Nombres + " " + a.UsuarioIntranet.ApellidoPaterno
                                };

            await EmailSender.SendEmailToList(autorizadores, "Solicitud Visto Bueno", message, new List<IAdjunto>());

            solicitud.FechaSolicitudVB = DateTime.Now;
            solicitud.Estado = Valores.EstadoSolicitudString(Valores.EstadoSolicitud.EsperaVB);
            foreach (var a in solicitud.Autorizadores)
            {
                a.Estado = Valores.EstadoAutorizacionString(Valores.EstadoAutorizacion.VBEnviado);
            }

            solicitud.Historial.Add(new Evento()
            {
                Autor = Usuario,
                Fecha = DateTime.Now,
                Titulo = "Vº Bº",
                ValorAnterior = "Solicitud de Vº Bº enviada",
                ValorNuevo = AutorizadoresString(solicitud.Autorizadores)
            });

            dbContext.SaveChanges();
            ViewBag.MostrarMenuLateral = false;
            ViewBag.RutaServer = getRutaServer();
            return View(solicitud);
        }

        public async Task<IActionResult> InsistenciaVB(int id)
        {
                var solicitud = GetSolicitud(id);
                if (solicitud == null)
                    return HttpBadRequest();
                ICollection<AutorizacionSolicitud> AutorizadoresNotificados = new List<AutorizacionSolicitud>();

                if (solicitud.FechaSolicitudVB.HasValue)
                {
                    var autorizadores = from a in solicitud.Autorizadores
                                        where a.Estado != Valores.EstadoAutorizacionString(Valores.EstadoAutorizacion.Autorizado) &&
                                            a.Estado != Valores.EstadoAutorizacionString(Valores.EstadoAutorizacion.Declinado)
                                        select a;

                    var destinatarios = (from a in solicitud.Autorizadores
                                         where a.Estado != Valores.EstadoAutorizacionString(Valores.EstadoAutorizacion.Autorizado) &&
                                             a.Estado != Valores.EstadoAutorizacionString(Valores.EstadoAutorizacion.Declinado)
                                         select new Destinatario
                                         {
                                             Email = a.UsuarioIntranet.Email,
                                             Nombre = a.UsuarioIntranet.Nombres + " " + a.UsuarioIntranet.ApellidoPaterno
                                         }).ToList();

                    if (destinatarios.Count() > 0)
                    {
                        // Verificar SLA
                        var prefs = new Preferencias(dbContext);
                        int plazo = prefs.SLA1;
                        DateTime fechaCalculo = DateTime.Today;

                        if (solicitud.FechaSolicitudVB3.HasValue)
                        {
                            fechaCalculo = solicitud.FechaSolicitudVB3.Value;
                            plazo = prefs.SLA3;
                        }
                        else if (solicitud.FechaSolicitudVB2.HasValue)
                        {
                            fechaCalculo = solicitud.FechaSolicitudVB2.Value;
                            plazo = prefs.SLA2;
                        }
                        else if (solicitud.FechaSolicitudVB.HasValue)
                        {
                            fechaCalculo = solicitud.FechaSolicitudVB.Value;
                            plazo = prefs.SLA1;
                        }
                        // Ahora a asignar al campo correspondiente
                        // Esto modifica el campo de fecha sí y sólo sí el SLA para el tramo anterior ya se cumplió
                        var fechaVencimientoSLA = nyp.Helpers.PrettyDate.SumarDiasHabiles(fechaCalculo, plazo);

                        if (DateTime.Today > fechaVencimientoSLA)
                        {
                            if (!solicitud.FechaSolicitudVB2.HasValue)
                            {
                                solicitud.FechaSolicitudVB2 = DateTime.Today;
                            }
                            else
                            {
                                solicitud.FechaSolicitudVB3 = DateTime.Today;
                            }
                        }

                        var message = RenderViewToString(getRutaServer() + "/Views/Templates/SolicitudAutorizacion", new NotificacionSolicitudViewModel
                        {
                            Solicitud = solicitud,
                            DiasPrimeraInsistencia = plazo
                        });

                        await EmailSender.SendEmailToList(destinatarios, "Solicitud Visto Bueno", message, new List<IAdjunto>());

                        foreach (var a in solicitud.Autorizadores)
                        {
                            if (a.Estado != Valores.EstadoAutorizacionString(Valores.EstadoAutorizacion.Autorizado) &&
                                a.Estado != Valores.EstadoAutorizacionString(Valores.EstadoAutorizacion.Declinado))
                            {
                                a.Estado = Valores.EstadoAutorizacionString(Valores.EstadoAutorizacion.VBEnviado);
                                a.FechaModificacion = DateTime.Now;
                                AutorizadoresNotificados.Add(a);
                            }
                        }

                        solicitud.Historial.Add(new Evento()
                        {
                            Autor = Usuario,
                            Fecha = DateTime.Now,
                            Titulo = "Vº Bº",
                            ValorAnterior = "Solicitud de Vº Bº enviada",
                            ValorNuevo = AutorizadoresString(solicitud.Autorizadores)
                        });

                        dbContext.SaveChanges();
                    }
                    else
                    {
                        ViewBag.Mensaje = "No hay destinatarios para esta solicitud";
                    }
                }
                else
                {
                    ViewBag.Mensaje = "Esta solicitud no registra envío de Vº Bº anterior";
                }
                solicitud.Autorizadores = AutorizadoresNotificados;
                ViewBag.MostrarMenuLateral = false;
                ViewBag.RutaServer = getRutaServer();
                return View(solicitud);
           
        }

        private Solicitud GetSolicitud(long id)
        {
            return (from s in dbContext.Solicitudes
                                          .Include(t => t.Solicitante).ThenInclude(u => u.Unidad)
                                          .Include(t => t.Autorizadores).ThenInclude(u => u.UsuarioIntranet)
                                          .Include(h => h.Historial)
                    where s.Id == id
                    select s).FirstOrDefault();
        }

        public IActionResult NotificarPublicacion(long id)
        {
            var publicacion = (from p in dbContext.Publicaciones
                               where p.Id == id
                               select p).FirstOrDefault();

            if (publicacion == null)
            {
                return HttpBadRequest();
            }

            ViewBag.Publicacion = publicacion;
            ViewBag.ListasDistribucion = from l in dbContext.ListasDistribucion
                                         select l;
            ViewBag.RutaServer = getRutaServer();
            return View(new NotificarNuevaPublicacionViewModel
            {
                PublicacionId = publicacion.Id,
                ListaDistribucionId = 0
            });
        }

        [HttpPost]
        public async Task<IActionResult> NotificarPublicacion(NotificarNuevaPublicacionViewModel model)
        {
            if (model == null)
            {
                return HttpBadRequest();
            }
            var publicacion = (from p in dbContext.Publicaciones
                           .Include(s => s.Solicitud).ThenInclude(s => s.Historial)
                           .Include(s => s.Circular)
                           .Include(d => d.DocumentosEnPublicacion).ThenInclude(d => d.Documento)
                               where p.Id == model.PublicacionId
                               select p).FirstOrDefault();
            if (publicacion == null)
            {
                return HttpBadRequest();
            }
            if (ModelState.IsValid)
            {
                var resultadoEnvio = await NotificarNuevaPublicacion(publicacion, model.ListaDistribucionId);
                if (resultadoEnvio != null)
                {
                    ViewBag.Publicacion = publicacion;
                    ViewBag.ListaDistribucion = resultadoEnvio.ListaDistribucion;
                    ViewBag.RutaServer = getRutaServer();
                    return View("NotificacionPublicacionEnviada", resultadoEnvio.Notificacion);
                }
                else
                {
                    return HttpBadRequest();
                }

            }
            ViewBag.Publicacion = publicacion;
            ViewBag.ListasDistribucion = from l in dbContext.ListasDistribucion
                                         select l;
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        private string AutorizadoresString(ICollection<AutorizacionSolicitud> autorizadores)
        {
            var result = new StringBuilder();
            foreach (var autorizador in autorizadores)
            {
                result.AppendLine(autorizador.UsuarioIntranet.Email);
            }
            return result.ToString();
        }

        private String getRutaServer()
        {
            //var prefs = new Preferencias(dbContext);
            //return prefs.RutaServer;
            return ""; 
        }
    }
}
