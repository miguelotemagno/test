﻿using Microsoft.AspNet.Authorization;
using Microsoft.AspNet.Hosting;
using Microsoft.AspNet.Mvc;
using Microsoft.Data.Entity;
using Newtonsoft.Json.Linq;
using nyp.DataModels;
using nyp.Filters;
using nyp.GestorDocumental.Service;
using nyp.Helpers;
using nyp.Models;
using nyp.Services;
using System;
using System.Linq;

namespace nyp.Controllers
{
    public class tmpObj
    {
        public Solicitud Solicitud { get; set; }
        public Publicacion Publicacion { get; set; }
    }

    [Authorize]
    [ServiceFilter(typeof(OcultarMenuLateralFilter))]
    public class ReportesController : ControllerConNotificacion
    {
        private IHostingEnvironment environment;

        public ReportesController(
            IEmailSender mailSenderService,
            NYPContext context,
            IGestorDocumental gestorDocumental,
            IHostingEnvironment env,
            ISessionService sessionContext) : base(mailSenderService, context, gestorDocumental, env, sessionContext)
        {
            environment = env;

        }

        public IActionResult Index(int? e)
        {
            var model = new ReporteViewModel
            {
                Desde = DateTime.Today.AddDays(-30),
                Hasta = DateTime.Today
            };
            if (e == 1)
            {
                ViewBag.Error = "No se encontraron resultados para mostrar"; 
            } else if (e == 2) {
                ViewBag.Error = "Error en las fechas enviadas";
            }
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        [HttpPost]
        public IActionResult ListadoSolicitudes(ReporteViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    string sql = @"
                    select
	                    a.Id as Solicitud,
	                    case when b.Id is not null then concat(b.Nombres, ' ', b.ApellidoPaterno) else '(Sin asignar)' end as Solicitante,
	                    case when c.Id is not null then concat(c.Nombres, ' ', c.ApellidoPaterno) else '(Sin asignar)' end as Analista,
	                    case when a.Estado = 'OK' then 'ListoPublicar' else a.Estado end as Estado,
	                    coalesce(e.Nombre, '(Sin asignar)') as Unidad,
	                    coalesce(f.Nombre, '(Sin asignar)') as Area,
	                    coalesce(g.Nombre, '(Sin asignar)') as Gerencia,
	                    a.Tipo,
                        a.Titulo as NombreDocumento,
	                    a.Materia,
	                    a.CodigoDocumento,
	                    a.FechaSolicitud,
	                    a.FechaSolicitudVB,
	                    a.FechaSolicitudVB2,
	                    a.FechaSolicitudVB3,
	                     CASE WHEN a.FechaOK = '0001-01-01' THEN NULL ELSE a.FechaOK END as FechaAceptacionVB,
	                    a.Destino as Destino,
                        CASE WHEN a.FechaBorrador = '0001-01-01' THEN NULL ELSE a.FechaBorrador END as FechaBorrador
                    from
	                    Solicitud a
	                    left join UsuarioIntranet b on a.AnalistaId = b.Id
	                    left join UsuarioIntranet c on a.SolicitanteId = c.Id
	                    left join Unidad e on a.UnidadId = e.Id
	                    left join Area f on e.AreaId = f.Id
	                    left join Gerencia g on f.GerenciaId = g.Id
                    where
						FechaSolicitud > '" + model.Desde.AddDays(-1).ToString("yyyy-MM-dd") + @"'
						and FechaSolicitud < '" + model.Hasta.AddDays(1).ToString("yyyy-MM-dd") + @"'
                    group by
	                    a.Id,
	                    b.Id,
	                    a.Estado,
	                    a.Tipo,
                        a.Titulo,
	                    a.Destino,
	                    a.Materia,
	                    a.CodigoDocumento,
	                    a.FechaSolicitud,
	                    a.FechaSolicitudVB,
	                    a.FechaSolicitudVB2,
	                    a.FechaSolicitudVB3,
                        a.FechaOK, 
                        a.FechaBorrador,
	                    a.Impacto,
	                    b.Nombres,
	                    b.ApellidoPaterno,
	                    c.Id,
	                    c.Nombres,
	                    c.ApellidoPaterno,
	                    e.Id,
	                    e.Nombre,
	                    f.Id,
	                    f.Nombre,
	                    g.Id,
	                    g.Nombre
                    ";
                    // case when r.RestriccionId is not null then 'Si' else 'No' end as Restriccion,
                    // left join Restriccion r on a.Id = r.SolicitudId
                    // r.RestriccionId
                    var lst = dbContext.Set<ReporteSolicitudItem>().FromSql(sql);

                    return new ExcelFileResult<ReporteSolicitudItem>(lst, "ListadoSolicitudes", "Listado Solicitudes", environment);
                } 
                catch (Exception ex)
                {
                    ViewBag.RutaServer = getRutaServer();
                    return RedirectToAction("Index", new { e = 1 });
                }
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("Index", new { e = 1 });
        }

        [HttpPost]
        
        public IActionResult ListadoPublicaciones(ReporteViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    string sql = @"
                       select 
	                        p.Id as Id, 
	                        p.CircularId as Circular, 
	                        p.Estado as Estado, 
	                        concat(ua.Nombres, ' ', ua.ApellidoPaterno, ' ', ua.ApellidoMaterno) as Analista, 
	                        p.Division as Gerencia, 
	                        p.Area as Area, 
	                        p.Unidad as Unidad, 
                            FORMAT(p.InicioVigencia,'dd-MM-yyyy') as FechaInicioVigencia,
                            FORMAT(p.FechaPublicacion,'dd-MM-yyyy') as FechaPublicacion,
	                        CASE WHEN p.FechaCertificacion = '0001-01-01' THEN '' ELSE FORMAT(p.FechaCertificacion,'dd-MM-yyyy') END as FinVigencia,
	                        p.NombreDocumento as NombreDocumento, 
	                        p.Codigo, 
	                        d.Version as VersionDocumento,
	                        concat(ur.Nombres, ' ', ur.ApellidoPaterno, ' ', ur.ApellidoMaterno) as Responsable,
                            p.Intervinientes as Intervinientes, 
                            s.Impacto as Impacto, 
	                        p.AreasImpactadas as AreasImpactadas, 
	                        s.Materia as Materia, 
	                        s.FuncionamientoActual as FuncionamientoAnterior, 
	                        s.FuncionamientoNuevo as FuncionamientoNuevo, 
	                        s.Consultas, 
	                        s.Tipo,
	                        s.Id as Solicitud, 
	                        '' as CategoriasEnPublicacion, 
	                        d.NombreArchivo as DocumentosEnPublicacion, 
	                        CASE WHEN r.RestriccionId is not null THEN 'Si' ELSE 'No' END as Restricciones

                    from Publicacion as p
                        inner join Solicitud as s on p.SolicitudId = s.Id
                        inner join UsuarioIntranet as ua on s.AnalistaId = ua.Id

                        inner join (select d1.Id, d1.PublicacionId, d1.NombreArchivo, d1.Version, d1.FechaPublicacion as FechaPubDoc
				                        from Documento as d1 inner join (
				                        SELECT PublicacionId, max(Id) as presunto
				                          FROM Documento where Vigente = 1
				                          GROUP BY PublicacionId
				                        ) as d2 on d1.Id = d2.presunto) as d
				                        on d.PublicacionId = p.Id

                        inner join UsuarioIntranet as ur on p.ResponsableId = ur.Id 
                        left outer join Restriccion as r on p.Id = r.PublicacionId
                    where
						FechaSolicitud > '" + model.Desde.AddDays(-1).ToString("yyyy-MM-dd") + @"'
						and FechaSolicitud < '" + model.Hasta.AddDays(1).ToString("yyyy-MM-dd") + @"'
                        and p.Estado <> 'Borrador'
                    ";

                    var lst = dbContext.Set<ReportePublicacionItem>().FromSql(sql);

                    foreach (var item in lst)
                    {
                        item.Intervinientes = GetIntervinientes(item.Solicitud);
                        item.CategoriasEnPublicacion = GetCategoriasEnPublicacion(item.Id);
                    }
                    

                    return new ExcelFileResult<ReportePublicacionItem>(lst, "ListadoPublicaciones", "Listado Publicaciones", environment);
                }
                catch (Exception ex)
                {
                    ViewBag.RutaServer = getRutaServer();
                    return RedirectToAction("Index", new { e = 1 });
                }
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("Index", new { e = 1 });
        }

        private string GetIntervinientes(long id)
        {
            string respuesta  = ""; 
            var intervinientes = (from inter in dbContext.Autorizadores
                                 .Include(t => t.UsuarioIntranet)
                                  where inter.SolicitudId == id
                                  select inter.UsuarioIntranet);
            int count = 0; 
            foreach (var autorizador in intervinientes)
            {
                if (count > 0) respuesta += ", "; 
                respuesta += autorizador.NombreCompleto();
                count++;
            }
            return respuesta;
        }

        private string GetCategoriasEnPublicacion(long id)
        {
            string respuesta = "";
            var categorias = (from cp in dbContext.CategoriasEnPublicacion
                                 .Include(t => t.Categoria)
                                  where cp.PublicacionId == id
                                  select cp.Categoria);
            int count = 0;
            foreach (var categoria in categorias)
            {
                if (count > 0) respuesta += ", ";
                respuesta += categoria.Nombre;
                count++;
            }
            return respuesta;
        }

        public IActionResult ReportesCertificacion(int? e)
        {
            var model = new ReporteViewModel
            {
                Desde = DateTime.Today.AddDays(-30),
                Hasta = DateTime.Today
            };
            if (e == 1)
            {
                ViewBag.Error = "No se encontraron resultados para mostrar";
            }
            else if (e == 2)
            {
                ViewBag.Error = "Error en las fechas enviadas";
            }
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        [HttpPost]
        public IActionResult ListadoPorCertificar(ReporteViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {


                    string sql = @"
                   select 
	                    p.Id as Id,
	                    COALESCE(c.AnalistaEjecutor, '') as AnalistaEjecutor,
	                    FORMAT(c.FechaProceso,'dd-MM-yyyy') as FechaProceso,
	                    FORMAT(p.FechaCertificacion,'dd-MM-yyyy') as FechaCertificacion,
	                    p.Codigo as Codigo,
	                    s.Tipo as Tipo,
	                    p.NombreDocumento as NombreDocumento,
	                    d.Version as Version, 
                        FORMAT(p.FechaPublicacion,'dd-MM-yyyy') as FechaCreacion,                   
                        FORMAT(COALESCE(c.FechaProceso, p.FechaPublicacion),'dd-MM-yyyy') as FechaPublicacion, 	                    
	                    COALESCE(c.GerenciaAnterior, '') as GerenciaAnterior,
	                    COALESCE(c.AreaAnterior, '') as AreaAnterior,
	                    COALESCE(c.UnidadAnterior, '') as UnidadAnterior,
	                    p.Division as Gerencia,
	                    p.Area as Area, 
	                    p.Unidad as Unidad,
	                    COALESCE (c.ResponsableAnterior, '') as ResponsableAnterior,
	                    CONCAT(u.Nombres, ' ', u.ApellidoPaterno, ' ', u.ApellidoMaterno) as ResponsableActual,
	                    COALESCE(c.Comentarios, '') as Comentarios
	
                    from publicacion as p 
	                    inner join UsuarioIntranet as u on p.ResponsableId = u.Id

	                    inner join (select d1.Id, d1.PublicacionId, d1.NombreArchivo, d1.Version, d1.FechaPublicacion as FechaPubDoc
				                    from Documento as d1 inner join (
				                    SELECT PublicacionId, max(Id) as presunto
				                      FROM Documento where Vigente = 1
				                      GROUP BY PublicacionId
				                    ) as d2 on d1.Id = d2.presunto) as d
				                    on d.PublicacionId = p.Id

                      inner join Solicitud as s on p.SolicitudId = s.id 
                      left outer join (
                      select  c1.Id, 
		                    c1.PublicacionId, 
		                    concat(u1.Nombres, ' ', u1.ApellidoPaterno, ' ', u1.ApellidoMaterno) as AnalistaEjecutor, 
		                    FechaProceso,
		                    GerenciaAnterior, 
		                    AreaAnterior, 
		                    UnidadAnterior, 
		                    concat(u2.Nombres, ' ', u2.ApellidoPaterno, ' ', u2.ApellidoMaterno) as ResponsableAnterior,
		                    Comentarios
                    from 
	                    ProcesoCertificacion as c1 
	                    inner join UsuarioIntranet as u1 
		                    on c1.AnalistaEjecutorId = u1.Id
	                    inner join UsuarioIntranet as u2 
		                    on c1.ResponsableAnteriorId = u2.Id
                      ) as c on p.Id = c.PublicacionId
                      
                    where p.FechaCertificacion <= '" + DateTime.Now.AddMonths(1).ToString("yyyy-MM-dd") + @"'
						
                    ";
                    
                    var lst = dbContext.Set<ReporteCertificacionItem>().FromSql(sql);

                    return new ExcelFileResult<ReporteCertificacionItem>(lst, "ListaCertificaciones", "Lista Certificaciones Pendientes", environment);
                }
                catch (Exception ex)
                {
                    ViewBag.RutaServer = getRutaServer();
                    return RedirectToAction("ReportesCertificacion", new { e = 1 });
                }
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("ReportesCertificacion", new { e = 1 });
        }

        [HttpPost]
        public IActionResult ListadoCertificadas(ReporteViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {


                    string sql = @"
                   select 
	                    p.Id as Id,
	                    COALESCE(c.AnalistaEjecutor, '') as AnalistaEjecutor,
	                    FORMAT(c.FechaProceso,'dd-MM-yyyy') as FechaProceso,
	                    FORMAT(p.FechaCertificacion,'dd-MM-yyyy') as FechaCertificacion,
	                    p.Codigo as Codigo,
	                    s.Tipo as Tipo,
	                    p.NombreDocumento as NombreDocumento,
	                    d.Version as Version, 
                        FORMAT(p.FechaPublicacion,'dd-MM-yyyy') as FechaCreacion,                   
                        FORMAT(COALESCE(c.FechaProceso, p.FechaPublicacion),'dd-MM-yyyy') as FechaPublicacion, 	                    
	                    COALESCE(c.GerenciaAnterior, '') as GerenciaAnterior,
	                    COALESCE(c.AreaAnterior, '') as AreaAnterior,
	                    COALESCE(c.UnidadAnterior, '') as UnidadAnterior,
	                    p.Division as Gerencia,
	                    p.Area as Area, 
	                    p.Unidad as Unidad,
	                    COALESCE (c.ResponsableAnterior, '') as ResponsableAnterior,
	                    CONCAT(u.Nombres, ' ', u.ApellidoPaterno, ' ', u.ApellidoMaterno) as ResponsableActual,
	                    COALESCE(c.Comentarios, '') as Comentarios
	
                    from publicacion as p 
	                    inner join UsuarioIntranet as u on p.ResponsableId = u.Id

	                    inner join (select d1.Id, d1.PublicacionId, d1.NombreArchivo, d1.Version, d1.FechaPublicacion as FechaPubDoc
				                    from Documento as d1 inner join (
				                    SELECT PublicacionId, max(Id) as presunto
				                      FROM Documento where Vigente = 1
				                      GROUP BY PublicacionId
				                    ) as d2 on d1.Id = d2.presunto) as d
				                    on d.PublicacionId = p.Id

                      inner join Solicitud as s on p.SolicitudId = s.id 
                      left outer join (
                      select  c1.Id, 
		                    c1.PublicacionId, 
		                    concat(u1.Nombres, ' ', u1.ApellidoPaterno, ' ', u1.ApellidoMaterno) as AnalistaEjecutor, 
		                    FechaProceso,
		                    GerenciaAnterior, 
		                    AreaAnterior, 
		                    UnidadAnterior, 
		                    concat(u2.Nombres, ' ', u2.ApellidoPaterno, ' ', u2.ApellidoMaterno) as ResponsableAnterior,
		                    Comentarios
                    from 
	                    ProcesoCertificacion as c1 
	                    inner join UsuarioIntranet as u1 
		                    on c1.AnalistaEjecutorId = u1.Id
	                    inner join UsuarioIntranet as u2 
		                    on c1.ResponsableAnteriorId = u2.Id
                      ) as c on p.Id = c.PublicacionId
                      
                     where c.FechaProceso is not null and 
                        c.FechaProceso > '" + model.Desde.AddDays(-1).ToString("yyyy-MM-dd") + @"'
						and c.FechaProceso < '" + model.Hasta.AddDays(1).ToString("yyyy-MM-dd") + @"'
						
                    ";

                    var lst = dbContext.Set<ReporteCertificacionItem>().FromSql(sql);

                    return new ExcelFileResult<ReporteCertificacionItem>(lst, "ListaCertificaciones", "Lista Certificaciones Realizadas", environment);
                }
                catch (Exception ex)
                {
                    ViewBag.RutaServer = getRutaServer();
                    return RedirectToAction("ReportesCertificacion", new { e = 1 });
                }
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("ReportesCertificacion", new { e = 1 });
        }

        private String getRutaServer()
        {
            //var prefs = new Preferencias(dbContext);
            //return prefs.RutaServer;
            return ""; 
        }

    }
}
