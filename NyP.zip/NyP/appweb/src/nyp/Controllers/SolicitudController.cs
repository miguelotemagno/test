﻿using Microsoft.AspNet.Authorization;
using Microsoft.AspNet.Hosting;
using Microsoft.AspNet.Http;
using Microsoft.AspNet.Mvc;
using Microsoft.AspNet.Mvc.ModelBinding;
using Microsoft.Data.Entity;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using nyp.DataModels;
using nyp.Filters;
using nyp.GestorDocumental.Service;
using nyp.Helpers;
using nyp.Models;
using nyp.Services;
using nyp.Extensions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace nyp.Controllers
{
    [Authorize]
    [ServiceFilter(typeof(OcultarMenuLateralFilter))]
    public class SolicitudController : ControllerConNotificacion
    {
        public SolicitudController(
            NYPContext context,
            IEmailSender mailSenderService,
            ISessionService sessionContext,
            IGestorDocumental gestorDocumental,
            IHostingEnvironment env)
            : base(mailSenderService, context, gestorDocumental, env, sessionContext)
        {

        }

        #region Acciones

        public IActionResult Index()
        {
            ViewBag.RutaServer = getRutaServer();
            return View();
        }

        /// <summary>
        /// Punto de entrada para crear una nueva solicitud.
        /// </summary>
        /// <returns></returns>
        public IActionResult Nueva()
        {
            var user = GetUserViewModelFromId(session.DatosUsuario.RUT);

            if (user == null)
                return HttpBadRequest();

            var nueva = new SolicitudViewModel()
            {
                Estado = Valores.EstadoSolicitudString(Valores.EstadoSolicitud.Nueva),
                Solicitante = session.DatosUsuario.AnalistaNYP ? null : user,
                SolicitanteId = session.DatosUsuario.AnalistaNYP ? 0 : user.Id,
                Analista = session.DatosUsuario.AnalistaNYP ? user : null,
                AnalistaId = session.DatosUsuario.AnalistaNYP ? user.Id : 0,
                Autorizadores = new List<EstadoAutorizacionViewModel>(),
                AutorizadoresId = new int[] { }
            };

            CargarAnalistasParaComboBox(nueva);

            if (nueva.Solicitante != null)
            {
                nueva.UnidadId = "u" + Usuario.UnidadId;
                ViewBag.OrganicaInicial = JsonConvert.SerializeObject(dbContext.OrganicaInicial("u" + Usuario.UnidadId.ToString()));
            }
            else
            {
                ViewBag.OrganicaInicial = JsonConvert.SerializeObject(dbContext.OrganicaInicial(null));
            }
            ViewBag.RutaServer = getRutaServer();
            return View(nueva);
        }
        
        [HttpPost]
        public IActionResult Nueva(SolicitudViewModel model, ICollection<IFormFile> files)
        {
            if (model == null)
            {
                return HttpBadRequest();
            }
            if (VerificarDatosSolicitud(model, ModelState, files))
            {
                model.Estado = Valores.EstadoSolicitudString(Valores.EstadoSolicitud.Nueva);

                var nueva = new Solicitud();
                nueva.Historial = new List<Evento>();
                TraspasarDatosDesdeViewModelAEntity(model, nueva);

                // Si solicitante no es analista
                nueva.FechaSolicitud = DateTime.Now;
                if (User.IsInRole("AnalistaNYP"))
                {
                    nueva.FechaIngreso = DateTime.Now;
                }
                if (nueva.Titulo == null)
                {
                    nueva.Titulo = "";
                }
                CalcularEstado(model);
                dbContext.Solicitudes.Add(nueva);
                dbContext.SaveChanges();
                string msg;
                bool ad;// = AgregarArchivo(nueva, model.CodigoDocumento, model.Titulo, model.TipoDocumento, model.ArchivoAdjunto, out msg, false);
                //Ciclo que recorre la coleccion de archivos
                //foreach f in files
                foreach (var f in files)
                {
                    ad = AgregarArchivo(nueva, model.CodigoDocumento, model.Titulo, model.TipoDocumento, f, out msg, false);
                    if (!ad)
                    {
                        ModelState.AddModelError("ArchivoAdjunto", msg);
                        CargarAnalistasParaComboBox(model);

                        if (nueva.Solicitante != null)
                        {
                            model.UnidadId = "u" + Usuario.UnidadId;
                            ViewBag.OrganicaInicial = JsonConvert.SerializeObject(dbContext.OrganicaInicial("u" + Usuario.UnidadId.ToString()));
                        }
                        else
                        {
                            ViewBag.OrganicaInicial = JsonConvert.SerializeObject(dbContext.OrganicaInicial(null));
                        }

                        // Hacer rollback de solicitud creada  
                        dbContext.Evento.RemoveRange(nueva.Historial);
                        dbContext.Solicitudes.Remove(nueva);
                        dbContext.SaveChanges();

                        return View(model);
                    }
                }

                //AgregarArchivo(entry, model.Codigo, model.Descripcion, model.TipoDocumento, model.ArchivoAdjunto, out msg, true))
                //                bool ad = AgregarArchivo(nueva, model.CodigoDocumento, model.Titulo, model.TipoDocumento, model.ArchivosAdjuntos, out msg, false);



                GuardarAutorizadoresDesdeViewModelEnContext(nueva, model);
                GuardarUsuariosNotificadosDesdeViewModelEnContext(nueva, model);


                nueva.Historial = new List<Evento>();
                nueva.Historial.Add(new Evento()
                {
                    Autor = Usuario,
                    Titulo = "Nueva solicitud",
                    Fecha = DateTime.Now
                });
                dbContext.SaveChanges();

                NotificarNuevaSolicitud(nueva);
                ConfirmacionVisual("Su solicitud ha sido creada", string.Format("El número de su solicitud es {0}", nueva.Id));
                ViewBag.RutaServer = getRutaServer();
                return RedirectToAction("Ver", new { id = nueva.Id });
            }

            ViewBag.OrganicaInicial = JsonConvert.SerializeObject(dbContext.OrganicaInicial(model.UnidadId));
            ViewBag.RutaServer = getRutaServer();
            return View(RefrescarSolicitudViewModel(model));
        }

        public IActionResult Ver(long id)
        {
            var viewModel = ExtraerSolicitudViewModelDesdeModelId(id);
            if (viewModel == null)
            {
                return HttpNotFound();
            }
            LlenarDatosUnidad(viewModel);

            var notas = from n in dbContext.Notas.Include(a => a.Autor)
                        where n.SolicitudId == id
                        select n;
            if (!User.IsInRole("AnalistaNYP"))
            {
                notas = notas.Where(s => s.Privada == false || s.AutorId == Usuario.Id);
            }

            ViewBag.Notas = notas;

            var referencias = from d in dbContext.DocumentosExistentesEnSolicitud.Include(t => t.Documento)
                              where d.SolicitudId == id
                              select d;
            ViewBag.DocumentosExistentes = referencias;
            ViewBag.RutaServer = getRutaServer();
            return View("Ver", viewModel);
        }

        public IActionResult HistorialSolicitud(long id)
        {
            var solicitud = GetSolicitud(id);

            if (solicitud == null)
            {
                return HttpNotFound();
            }
            ViewBag.RutaServer = getRutaServer();
            return View(solicitud);
        }

        public IActionResult AgregarNota(long? id, string e)
        {
            if (e != null)
            {
                ViewBag.Error = e; 
            }

            if (id.HasValue)
            {
                var solicitud = GetSolicitud(id.Value);
                if (solicitud == null)
                {
                    return HttpBadRequest();
                }
                var model = new AgregarNotaViewModel() { SolicitudId = solicitud.Id };
                ViewBag.Solicitud = solicitud;
                ViewBag.RutaServer = getRutaServer();
                return View(model);
            }
            return HttpBadRequest();
        }

        [HttpPost]
        public IActionResult AgregarNota(AgregarNotaViewModel model)
        {
            if (ModelState.IsValid)
            {
                var nota = new Nota
                {
                    SolicitudId = model.SolicitudId.Value,
                    AutorId = Usuario.Id,
                    Fecha = DateTime.Now,
                    Privada = model.Privado,
                    Texto = model.Texto
                };
                dbContext.Notas.Add(nota);
                dbContext.SaveChanges();
                ViewBag.RutaServer = getRutaServer();
                return RedirectToAction("Ver", new { id = model.SolicitudId.Value });
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("AgregarNota", new { id = model.SolicitudId, e = "1" });
        }

        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult Publicar(long id)
        {
            //verificar si existe ya una publicacion con esta solicitud
            var testPublicacion = (from p in dbContext.Publicaciones
                                   where p.SolicitudId == id
                                   select p).FirstOrDefault();
            if (testPublicacion != null)
            {
                return RedirectToAction("Ver", "Publicacion", new { id = testPublicacion.Id });
            }


            var solicitud = ExtraerSolicitudViewModelDesdeModelId(id);
            if (solicitud != null)
            {
                if (!VerificarDatosSolicitud(solicitud, ModelState, null))
                {
                    var errores = new List<string>();
                    foreach (var v in ModelState.Values)
                    {
                        foreach (var e in v.Errors)
                        {
                            errores.Add(e.ErrorMessage);
                        }
                    }
                    return MensajeError("Error en solicitud", "Solicitud incompleta, por favor revisar antes de publicar", errores);
                }

                if (!VerificarDatosAntesDePublicar(solicitud, ModelState))
                {
                    var errores = new List<string>();
                    foreach (var v in ModelState.Values)
                    {
                        foreach (var e in v.Errors)
                        {
                            errores.Add(e.ErrorMessage);
                        }
                    }
                    return MensajeError("Error en solicitud", "Solicitud incompleta, por favor revisar antes de publicar", errores);
                }

                var fechaPublicacion = solicitud.FechaPublicacion ?? DateTime.Now;
                var fechaInicioVigencia = solicitud.FechaInicioVigencia ?? fechaPublicacion;
                var fechaCertificacion = fechaInicioVigencia.AddYears(1);
                var publicacion = new NuevaPublicacionViewModel()
                {
                    SolicitudId = id,
                    FechaPublicacion = fechaPublicacion,
                    FechaInicioVigencia = fechaInicioVigencia,
                    FechaCertificacion = fechaCertificacion,
                    Solicitud = solicitud,
                };
                var referencias = from d in dbContext.DocumentosExistentesEnSolicitud.Include(t => t.Documento)
                                  where d.SolicitudId == id
                                  select d;
                ViewBag.DocumentosExistentes = referencias;

                //Cargar la lista de Gerencia. 
                ViewBag.Gerencias = dbContext.Gerencias.ToList();

                return View(publicacion);
            }
            return HttpNotFound();
        }

        private string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        [Authorize(Roles = "AnalistaNYP")]
        [HttpPost]
        public IActionResult Publicar([Bind("SolicitudId,Nombre,Tipo,FechaPublicacion,FechaInicioVigencia,FechaCertificacion,Categorias,NivelAcceso")]NuevaPublicacionViewModel model)
        {

            var solicitudViewModel = ExtraerSolicitudViewModelDesdeModelId(model.SolicitudId);
            if (VerificarDatosAntesDePublicar(solicitudViewModel, ModelState))
            {

                var solicitud = GetSolicitud(model.SolicitudId);
                model.Solicitud = solicitudViewModel;

                



                var pub = new Publicacion()
                {
                    FechaPublicacion = model.FechaPublicacion,
                    InicioVigencia = model.FechaInicioVigencia,
                    FechaCertificacion = model.FechaCertificacion,
                    Responsable = solicitud.Solicitante,
                    NombreDocumento = solicitud.Titulo,
                    Solicitud = solicitud,
                    Codigo = solicitud.CodigoDocumento,
                    AreasImpactadas = solicitud.Destino,
                    Estado = Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Borrador),
                    Tipo = solicitud.Tipo,
                    Consultas = solicitud.Consultas,

                    // Gerencia, Área, Unidad
                    Division = solicitud.Unidad.Area.Gerencia.Nombre,
                    Area = solicitud.Unidad.Area.Nombre,
                    Unidad = solicitud.Unidad.Nombre,

                    FuncionamientoAnterior = solicitud.FuncionamientoActual,
                    FuncionamientoNuevo = solicitud.FuncionamientoNuevo,
                    Impacto = solicitud.Impacto,
                    NivelAcceso = model.NivelAcceso
                };
                dbContext.Publicaciones.Add(pub);
                dbContext.SaveChanges();
                pub.Circular = CrearCircularDesdePublicacion(model);
                dbContext.SaveChanges();
                //Actualizar el estado de la solicitud a Borrador
                solicitud.Estado = Valores.EstadoSolicitud.Borrador.ToString();
                solicitud.FechaBorrador = DateTime.Now;
                solicitud.FechaInicioVigencia = model.FechaInicioVigencia;
                dbContext.Solicitudes.Attach(solicitud);
                dbContext.Entry(solicitud).State = EntityState.Modified;
                dbContext.SaveChanges();


                // Agregar categorías
                if (model.Categorias.Any())
                {
                    var cat = from c in dbContext.Categorias
                              where model.Categorias.Contains(c.Id)
                              select c;
                    foreach (var c in cat)
                    {
                        dbContext.CategoriasEnPublicacion.Add(new CategoriasEnPublicacion()
                        {
                            CategoriaId = c.Id,
                            PublicacionId = pub.Id
                        });
                    }
                }
                dbContext.SaveChanges();
                NotificarSolicitudModificada(solicitud, Usuario);
                ViewBag.RutaServer = getRutaServer();
                return RedirectToAction("Ver", "Publicacion", new { id = pub.Id });
            }
            // siempre necesitamos la solicitud acá
            model.Solicitud = ExtraerSolicitudViewModelDesdeModelId(model.SolicitudId);
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }


        
        /// <summary>
        /// Anula una solicitud en curso.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult Anular(long id)
        {
            var solicitud = ExtraerSolicitudViewModelDesdeModelId(id);
            if (solicitud != null)
            {
                // Para verificar
                var anulacion = new AnularSolicitudViewModel()
                {
                    SolicitudId = id,
                    Motivo = "Anulado por analista",
                };
                ViewBag.RutaServer = getRutaServer();
                return View(anulacion);
            }
            return HttpNotFound();
        }

        [Authorize(Roles = "AnalistaNYP")]
        [HttpPost]
        public IActionResult Anular(AnularSolicitudViewModel model)
        {
            if (ModelState.IsValid)
            {
                var solicitud = GetSolicitud(model.SolicitudId);
                if (solicitud == null)
                {
                    return HttpBadRequest();
                }
                AgregarCambio(solicitud, "Estado", solicitud.Estado, Valores.EstadoSolicitudString(Valores.EstadoSolicitud.Rechazado));
                solicitud.Estado = Valores.EstadoSolicitudString(Valores.EstadoSolicitud.Rechazado);
                solicitud.Motivo = model.Motivo;
                if (solicitud.Analista == null)
                {
                    solicitud.Analista = Usuario;
                }
                dbContext.SaveChanges();
                var refresca = GetSolicitud(solicitud.Id);
                NotificarSolicitudAnuladaPorAnalista(refresca, Usuario, model.Motivo);
                ViewBag.RutaServer = getRutaServer();
                return RedirectToAction("Ver", new { id = solicitud.Id });
            }
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        public IActionResult Editar(long? id)
        {
            if (id == null || !id.HasValue)
            {
                ViewBag.RutaServer = getRutaServer();
                return RedirectToAction("Nueva");
            }

            var viewModel = ExtraerSolicitudViewModelDesdeModelId(id.Value);
            if (viewModel == null)
            {
                return HttpNotFound();
            }
            ViewBag.OrganicaInicial = JsonConvert.SerializeObject(dbContext.OrganicaInicial(viewModel.UnidadId));
            ViewBag.RutaServer = getRutaServer();
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult Editar(SolicitudViewModel model)
        {
            model = RefrescarSolicitudViewModel(model);
            if (ModelState.IsValid)
            {
                var entry = GetSolicitud(model.Id);
                if (entry != null)
                {
                    var autor = GetUsuarioIntranet(session.DatosUsuario.RUT);
                    var anterior = ExtraerSolicitudViewModelDesdeModelId(model.Id);
                    GuardarAutorizadoresDesdeViewModelEnContext(entry, model);
                    GuardarUsuariosNotificadosDesdeViewModelEnContext(entry, model);
                    RevertirEstadoAutorizadores(entry);
                    entry.Estado = CalcularEstadoSolicitud(entry);
                    TraspasarDatosDesdeViewModelAEntity(model, entry);
                    entry.FechaOK = DateTime.Parse("0001-01-01 00:00:00.0000000");
                    CalcularEstado(model);
                    var n = entry.Historial.Count();
                    
                    RegistrarCambios(entry, anterior, model);
                    
                    
                    dbContext.Solicitudes.Attach(entry);
                    dbContext.Entry(entry).State = EntityState.Modified;
                    dbContext.SaveChanges();
                    // ahora cargar de nuevo
                    var solicitud = GetSolicitud(entry.Id);
                    NotificarSolicitudModificada(solicitud, Usuario);
                    ViewBag.RutaServer = getRutaServer();
                    return RedirectToAction("Ver", new { id = entry.Id });
                }
            }
            ViewBag.OrganicaInicial = JsonConvert.SerializeObject(dbContext.OrganicaInicial(model.UnidadId));
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        public IActionResult Adjuntar(long id)
        {
            var solicitud = ExtraerSolicitudViewModelDesdeModelId(id);
            if (solicitud == null)
            {
                return HttpBadRequest();
            }
            var model = new AdjuntarArchivoViewModel()
            {
                Solicitud = solicitud,
                SolicitudId = id
            };
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        [HttpPost]
        public IActionResult Adjuntar([Bind("SolicitudId")]AdjuntarArchivoViewModel model, ICollection<IFormFile> files)
        {
            var entry = GetSolicitud(model.SolicitudId);

            if (entry == null)
            {
                return HttpBadRequest();
            }
            if (ModelState.IsValid)
            {
                string msg;
                foreach (var file in files)
                {
                    if (!AgregarArchivo(entry, entry.CodigoDocumento, entry.Titulo, entry.Tipo, file, out msg, true))
                    {
                        ModelState.AddModelError("ArchivoAdjunto", msg);
                    }
                }
                ViewBag.RutaServer = getRutaServer();
                ConfirmacionVisual("Documento(s) Adjuntado(s)",
                    "Documento(s) adjuntado(s) satisfactoriamente");
                return RedirectToAction("Ver", new { id = entry.Id });
            }
            model.Solicitud = ExtraerSolicitudViewModelDesdeModelId(entry.Id);
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult AdjuntarExistente(long id)
        {
            var solicitud = ExtraerSolicitudViewModelDesdeModelId(id);
            if (solicitud == null)
            {
                return HttpBadRequest();
            }
            var model = new AdjuntarArchivoExistenteViewModel()
            {
                SolicitudId = id
            };
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        [Authorize(Roles = "AnalistaNYP")]
        [HttpPost]
        public IActionResult AdjuntarExistente(AdjuntarArchivoExistenteViewModel model)
        {
            var solicitud = GetSolicitud(model.SolicitudId);
            if (solicitud == null)
            {
                return HttpBadRequest();
            }
            if (ModelState.IsValid)
            {
                var documento = dbContext.Documentos.FirstOrDefault(t => t.Id == model.DocumentoId);
                if (documento == null)
                {
                    ViewBag.Error = "Archivo no econtrado";
                    ViewBag.RutaServer = getRutaServer();
                    return RedirectToAction("AdjuntarExistente", new { id = solicitud.Id });
                }
                dbContext.DocumentosExistentesEnSolicitud.Add(
                    new DocumentosExistentesEnSolicitud
                    {
                        SolicitudId = model.SolicitudId,
                        DocumentoId = model.DocumentoId
                    });

                AgregarCambio(solicitud, "Referencia", null, documento.NombreArchivo);
                try
                {
                    dbContext.SaveChanges();
                }
                catch (Exception e)
                {
                    var mensaje = e.Message;
                }
                
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("Ver", new { id = solicitud.Id });
        }

        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult EliminarExistente(AdjuntarArchivoExistenteViewModel model)
        {
            var solicitud = GetSolicitud(model.SolicitudId);
            if (solicitud == null)
            {
                return HttpBadRequest();
            }
            if (ModelState.IsValid)
            {
                var referencia = dbContext.DocumentosExistentesEnSolicitud
                    .Include(t => t.Documento)
                    .FirstOrDefault(t => t.SolicitudId == model.SolicitudId && t.DocumentoId == model.DocumentoId);
                if (referencia == null)
                {
                    return HttpBadRequest();
                }
                AgregarCambio(solicitud, "Referencia", referencia.Documento.NombreArchivo, null);
                dbContext.DocumentosExistentesEnSolicitud.Remove(referencia);
                dbContext.SaveChanges();
                ConfirmacionVisual("Referencia Eliminada", string.Format("La referencia al documento {0} ha sido eliminada", referencia.Documento.NombreArchivo));
                ViewBag.RutaServer = getRutaServer();
                return RedirectToAction("Ver", new { id = solicitud.Id });
            }
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        public IActionResult EliminarDocumento(int documentoId, long solicitudId, string callbackController = "Solicitud", string callbackAction = "Ver", long callbackId = 0)
        {
            var doc = (from d in dbContext.Archivos
                       where d.Id == documentoId
                       select d).FirstOrDefault();
            if (doc != null)
            {
                var solicitud = (from s in dbContext.Solicitudes.Include(t => t.Solicitante)
                                 where s.Id == solicitudId
                                 select s).FirstOrDefault();
                if (solicitud != null)
                {
                    // Sólo permite borrar si es analista o si el solicitante es el mismo usuario
                    if (!User.IsInRole("AnalistaNYP") && solicitud.Solicitante.Id != Usuario.Id)
                    {
                        return HttpUnauthorized();
                    }
                    var model = new EliminarDocumentoViewModel
                    {
                        DocumentoId = doc.Id,
                        SolicitudId = solicitud.Id,
                        CallbackController = callbackController,
                        CallbackAction = callbackAction,
                        CallbackId = callbackId > 0 ? callbackId : solicitudId
                    };

                    var calculoNombreOriginal = doc.NombreArchivoOriginal.Split('\\');

                    var data = new SolicitudYDocumentoViewModel
                    {
                        SolicitudId = solicitud.Id,
                        DocumentoId = doc.Id,
                        NombreSolicitud = solicitud.Titulo,
                        NombreDocumento = doc.TituloDocumento,
                        NombreArchivo = calculoNombreOriginal[calculoNombreOriginal.Length - 1]
                    };
                    ViewBag.DatosDocumento = data;
                    ViewBag.RutaServer = getRutaServer();
                    return View(model);
                }
            }
            return HttpBadRequest();
        }

        [HttpPost]
        public IActionResult EliminarDocumento(EliminarDocumentoViewModel model)
        {
            if (ModelState.IsValid)
            {
                var doc = (from d in dbContext.Archivos
                           where d.Id == model.DocumentoId
                           select d).FirstOrDefault();

                if (doc != null)
                {
                    var solicitud = (from s in dbContext.Solicitudes.Include(t => t.Solicitante).Include(t => t.Historial)
                                     where s.Id == model.SolicitudId
                                     select s).FirstOrDefault();
                    if (solicitud != null)
                    {
                        // Sólo permite borrar si es analista o si el solicitante es el mismo usuario
                        if (!User.IsInRole("AnalistaNYP") && solicitud.Solicitante.Id != Usuario.Id)
                        {
                            return HttpUnauthorized();
                        }
                        dbContext.Archivos.Remove(doc);

                        solicitud.Historial.Add(new Evento()
                        {
                            Autor = Usuario,
                            Campo = "Adjuntos",
                            Fecha = DateTime.Now,
                            Titulo = "Eliminación",
                            ValorAnterior = doc.NombreArchivoOriginal,
                            ValorNuevo = ""
                        });
                        RevertirEstadoAutorizadores(solicitud);
                        dbContext.SaveChanges();
                        NotificarSolicitudModificada(solicitud, Usuario);

                        try
                        {
                            System.IO.File.Delete(GetPhysicalFilename(doc.NombreFisico));
                        }
                        catch
                        {
                            // nada?
                        }
                        ConfirmacionVisual("Documento Eliminado", string.Format("El documento adjunto {0} ha sido eliminado", doc.NombreArchivoOriginal));
                        ViewBag.RutaServer = getRutaServer();
                        return RedirectToAction(model.CallbackAction, model.CallbackController, new { id = model.CallbackId });
                    }
                }
            }
            // Acá no hay intervención del usuario más que presionar "Sí, acepto"
            return HttpBadRequest();
        }

        public IActionResult SolicitarPublicacion()
        {
            // Obtener página predeterminada
            var propiedades = new Preferencias(dbContext);
            PaginaContenidos pagina = null;
            if (propiedades.PaginaSolicitarPublicacion <= 0)
            {
                pagina = new PaginaContenidos();
            }
            else
            {
                pagina = (from p in dbContext.PaginasContenidos.Include(p => p.Autor)
                          where p.Id == propiedades.PaginaSolicitarPublicacion
                          select p).FirstOrDefault();
                if (pagina == null)
                {
                    pagina = new PaginaContenidos();
                }
            }
            ViewBag.RutaServer = getRutaServer();
            return View(pagina);
        }

        public IActionResult Doc(int id)
        {
            var doc = (from d in dbContext.Archivos
                       where d.Id == id
                       select d).FirstOrDefault();

            if (doc != null)
            {
                var mime = GetMimeMapping(doc.NombreArchivoOriginal);
                if (mime == null)
                {
                    // Tipo de archivo no permitido
                    return HttpNotFound();
                }
                byte[] fileBytes = System.IO.File.ReadAllBytes(GetPhysicalFilename(doc.NombreFisico));
                if (fileBytes != null)
                {
                    return File(fileBytes, mime, doc.NombreArchivoOriginal);
                }
            }
            return HttpNotFound();
        }

        public IActionResult Autorizar(long id)
        {
            var model = new AutorizacionSolicitudViewModel()
            {
                Estado = "Autorizado",
                SolicitudId = id,
                TipoEvento = "Autorizada"
            };
            ViewBag.RutaServer = getRutaServer();
            return CambioEstadoAutorizador(model);
        }

        public IActionResult Declinar(long id)
        {
            var model = new AutorizacionSolicitudViewModel()
            {
                Estado = "Declinado",
                SolicitudId = id,
                TipoEvento = "Rechazada"
            };
            ViewBag.RutaServer = getRutaServer();
            return CambioEstadoAutorizacionObservaciones(model);
        }

        [HttpPost]
        public IActionResult Declinar(AutorizacionSolicitudViewModel model)
        {
            model.TipoEvento = "Rechazada";
            ViewBag.RutaServer = getRutaServer();
            return CambioEstadoAutorizacionObservaciones(model);
        }

        [Produces("application/json")]
        public Dictionary<long, string> GetCategorias(long? id)
        {
            // Agregar count() a mano pues EF7 aún no soporta GroupBy. Bleh.
            var conteos = (from c in dbContext.Categorias
                           group c by c.CategoriaId into g
                           where g.Key != null
                           select new { id = g.Key, valor = g.Count() });

            // Categorias para esta selección
            var categorias = (from c in dbContext.Categorias
                              where c.CategoriaId == id
                              select c).ToDictionary(t => t.Id, t => t.Nombre);

            // Agregarle al diccionario si encuentro match
            foreach (var qty in conteos)
            {
                string value;
                if (categorias.TryGetValue(qty.id.Value, out value))
                {
                    categorias[qty.id.Value] = value + string.Format("({0})", qty.valor);
                }
            }

            return categorias;
        }

        //Manejo de combo box en Area/Unidad/Usuarios

        [Produces("application/json")]
        public JsonResult Area(int GerenciaID)
        {
            var areas = from Area in dbContext.Areas
                        where Area.GerenciaId == GerenciaID
                        orderby Area.Nombre ascending
                        select Area;
            return Json(areas);
        }

        [Produces("application/json")]
        public JsonResult Unidad(int AreaID)
        {
            var unidades = from Unidad in dbContext.Unidades
                           where Unidad.AreaId == AreaID
                           orderby Unidad.Nombre ascending
                           select Unidad;
            return Json(unidades);
        }

        [Produces("application/json")]
        public JsonResult Usuarios(int UnidadId)
        {

            var usuarios = from UsuarioIntranet in dbContext.UsuariosIntranet
                           where UsuarioIntranet.UnidadId == UnidadId
                           select UsuarioIntranet;
            var entry = new { data = usuarios };
            return Json(entry);
        }

        #endregion

        #region Bandeja
        private IQueryable<Solicitud> GetListaSolicitudes()
        {
            return from s in dbContext.Solicitudes
                        .Include(t => t.Solicitante)
                        .Include(t => t.Analista)
                        .Include(t => t.Autorizadores)
                   select s;
        }

        private IQueryable<Solicitud> GetListadoSolicitudesActivas()
        {
            var qry = GetListaSolicitudes();
            var estados = new string[] {
                    Valores.EstadoSolicitudString(Valores.EstadoSolicitud.Nueva),
                    Valores.EstadoSolicitudString(Valores.EstadoSolicitud.EnProceso),
                    Valores.EstadoSolicitudString(Valores.EstadoSolicitud.OK),
                    Valores.EstadoSolicitudString(Valores.EstadoSolicitud.EsperaVB),
                    Valores.EstadoSolicitudString(Valores.EstadoSolicitud.VBRechazado),
                    Valores.EstadoSolicitudString(Valores.EstadoSolicitud.Borrador)
                };

            return qry.Where(s => estados.Contains(s.Estado));
        }

        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult Listado()
        {
            var qry = GetListadoSolicitudesActivas();
            return ListadoSolicitudes(qry.ToList(), "Listado", 0);
        }

        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult Asignadas(int? page)
        {
            var analista = GetUsuarioIntranet(session.DatosUsuario.RUT);
            var qry = GetListadoSolicitudesActivas();
            qry = qry.Where(t => t.Analista != null && t.Analista.Id == analista.Id);
            return ListadoSolicitudes(qry.ToList(), "Asignadas", page);
        }

        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult Inactivas(int? page)
        {
            var qry = GetListaSolicitudes();
            var estados = new string[] {
                    Valores.EstadoSolicitudString(Valores.EstadoSolicitud.Rechazado)
                    //Valores.EstadoSolicitudString(Valores.EstadoSolicitud.Publicado)
                };

            qry = qry.Where(s => estados.Contains(s.Estado));
            return ListadoSolicitudes(qry.ToList(), "Inactivas", page);
        }

        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult Borrador(int? page)
        {
            var qry = GetListaSolicitudes();
            var estados = new string[] {
                    Valores.EstadoSolicitudString(Valores.EstadoSolicitud.Borrador)
                };

            qry = qry.Where(s => estados.Contains(s.Estado));
            return ListadoSolicitudes(qry.ToList(), "Borrador", page);
        }

        public IActionResult MisSolicitudes(int? page)
        {
            var solicitante = GetUsuarioIntranet(session.DatosUsuario.RUT);
            var solicitudesInterviniente = (from a in dbContext.Autorizadores
                                            where a.UsuarioIntranetId == solicitante.Id
                                            select a.SolicitudId).ToArray();

            var qry = GetListadoSolicitudesActivas();
            qry = qry.Where(t => solicitudesInterviniente.Contains(t.Id) || (t.Solicitante != null && t.Solicitante.Id == solicitante.Id));

            return ListadoSolicitudes(qry.ToList(), "MisSolicitudes", page);
        }
        #endregion

        #region Métodos privados

        private static Solicitud GetSolicitud(long id)
        {
            return (from s in dbContext.Solicitudes
                        .Include(t => t.Historial).ThenInclude(h => h.Autor)
                        .Include(t => t.Unidad).ThenInclude(t => t.Area).ThenInclude(t => t.Gerencia)
                        .Include(t => t.Autorizadores).ThenInclude(t => t.UsuarioIntranet)
                        .Include(t => t.Solicitante)
                        .Include(t => t.Analista)
                    where s.Id == id
                    select s).FirstOrDefault();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="viewModel"></param>
        private void CargarAutorizadoresDesdeBaseDatos(SolicitudViewModel viewModel)
        {
            viewModel.Autorizadores = (from i in dbContext.Autorizadores
                                       join u in dbContext.UsuariosIntranet on i.UsuarioIntranetId equals u.Id
                                       where i.SolicitudId == viewModel.Id
                                       select new EstadoAutorizacionViewModel()
                                       {
                                           Interviniente = UserToApplicationUser(u),
                                           Autorizacion = new AutorizacionSolicitudViewModel()
                                           {
                                               SolicitudId = i.SolicitudId,
                                               Estado = i.Estado,
                                               Observaciones = i.Observaciones
                                           }
                                       }).ToList();
        }

        private SolicitudViewModel ExtraerSolicitudViewModelDesdeModelId(long id, bool cargarAutorizadores = true)
        {
            var solicitud = GetSolicitud(id);
            if (solicitud == null)
            {
                return null;
            }

            var viewModel = new SolicitudViewModel()
            {
                Id = solicitud.Id,
                Estado = solicitud.Estado,
                Destino = solicitud.Destino,
                Consultas = solicitud.Consultas,
                Titulo = solicitud.Titulo,
                Objetivo = solicitud.Objetivo,
                TipoDocumento = solicitud.Tipo,
                Unidad = solicitud.Unidad,
                UnidadId = string.Format("u{0}", solicitud.Unidad != null ? solicitud.Unidad.Id : 0),

                CodigoDocumento = solicitud.CodigoDocumento,
                Impacto = solicitud.Impacto,

                FechaIngreso = solicitud.FechaIngreso,
                FechaSolicitud = solicitud.FechaSolicitud,
                FechaSolicitudVB = solicitud.FechaSolicitudVB,
                FechaSolicitudVB2 = solicitud.FechaSolicitudVB2,
                FechaSolicitudVB3 = solicitud.FechaSolicitudVB3,
                FechaInicioVigencia = solicitud.FechaInicioVigencia,
                Materia = solicitud.Materia,

                FuncionamientoActual = solicitud.FuncionamientoActual,
                FuncionamientoNuevo = solicitud.FuncionamientoNuevo,

                Analista = UserToApplicationUser(solicitud.Analista),
                Solicitante = UserToApplicationUser(solicitud.Solicitante),
                Motivo = solicitud.Motivo
            };

            // Intervinientes
            if (cargarAutorizadores)
                CargarAutorizadoresDesdeBaseDatos(viewModel);

            if (viewModel.Analista != null)
            {
                viewModel.AnalistaId = viewModel.Analista.Id;
            }
            if (viewModel.Solicitante != null)
            {
                viewModel.SolicitanteId = viewModel.Solicitante.Id;
            }

            // autorizadoresId
            viewModel.AutorizadoresId = (from a in viewModel.Autorizadores
                                         select a.Interviniente.Id).ToList();

            // autorizadoresId
            //viewModel.UsuariosNotificadosEmails = (from a in viewModel.UsuariosNotificados
            //                             select a.Interviniente.Email).ToList();

            viewModel.UsuariosNotificados = (from un in dbContext.UsuariosNotificados
                                             where un.Solicitud.Id == solicitud.Id
                                             select un)
                                             .ToList()
                                             .Select(un => new ApplicationOpenUserViewModel
                                             {
                                                 Email = un.Email,
                                                 Id = un.Email,
                                                 Cargo = un.Usuario != null ? un.Usuario.Cargo : "",
                                                 Nombre = un.Usuario != null ? string.Format("{0}, {1}", un.Usuario.ApellidoPaterno, un.Usuario.Nombres) : un.Email
                                             })
                                             .ToList();

            // Archivos
            viewModel.ArchivosAdjuntos = (from a in dbContext.ArchivosEnSolicitud
                                          join f in dbContext.Archivos on a.ArchivoId equals f.Id
                                          where a.SolicitudId == solicitud.Id
                                          select new ArchivoViewModel()
                                          {
                                              Id = a.ArchivoId,
                                              Descripcion = f.TituloDocumento,
                                              NombreFisico = f.NombreFisico,
                                              NombreOriginal = f.NombreArchivoOriginal
                                          }).ToList();

            // Ver si se están reemplazando archivos en otra publicación
            if (viewModel.Estado != "Borrador" && viewModel.Estado != "Publicado")
            {
                foreach (var archivo in viewModel.ArchivosAdjuntos)
                {
                    var doc = (from d in dbContext.Documentos.Include(t => t.Publicacion)
                               where d.NombreArchivo == archivo.NombreOriginal
                               select d).FirstOrDefault();
                    //  if (documentManager.GetDocumentoPorNombre(archivo.NombreOriginal) != null)
                    if (doc != null)
                    {
                        archivo.Reemplazo = true;
                        archivo.NombreDocumento = doc.Publicacion.Id + " - " + doc.Publicacion.NombreDocumento;
                    }
                }
            }
            CargarAnalistasParaComboBox(viewModel);
            //CalcularEstado(viewModel);

            return viewModel;

        }

        private void asignarFecha(object source, object target, string name)
        {
            Type sourceType = source.GetType();
            Type targetType = target.GetType();
            PropertyInfo sourceProp = sourceType.GetProperty(name);
            PropertyInfo targetProp = targetType.GetProperty(name);

            var val = sourceProp.GetValue(source);
            if (val != null)
            {
                targetProp.SetValue(target, val, null);
            }
        }

        private SolicitudViewModel RefrescarSolicitudViewModel(SolicitudViewModel model)
        {
            // refrescar analista, autorizadores, solicitante
            if (model == null)
            {
                return null;
            }

            var viewModel = new SolicitudViewModel()
            {
                Id = model.Id,
                Estado = model.Estado,
                Destino = model.Destino,
                Titulo = model.Titulo,
                Objetivo = model.Objetivo,
                TipoDocumento = model.TipoDocumento,
                Consultas = model.Consultas,
                AutorizadoresId = model.AutorizadoresId,
                //UsuariosNotificadosEmails = model.UsuariosNotificadosEmails,
                UsuariosNotificados = model.UsuariosNotificados,
                ArchivoAdjunto = model.ArchivoAdjunto,
                ArchivosAdjuntos = model.ArchivosAdjuntos,
                CodigoDocumento = model.CodigoDocumento,
                UnidadId = model.UnidadId,
                Impacto = model.Impacto,
                Materia = model.Materia,
                FuncionamientoActual = model.FuncionamientoActual,
                FuncionamientoNuevo = model.FuncionamientoNuevo,
            };

            asignarFecha(model, viewModel, "FechaIngreso");
            asignarFecha(model, viewModel, "FechaInicioVigencia");
            asignarFecha(model, viewModel, "FechaPublicacion");
            asignarFecha(model, viewModel, "FechaSolicitud");
            asignarFecha(model, viewModel, "FechaSolicitudVB");

            if (model.AnalistaId.HasValue)
            {
                viewModel.Analista = GetUserViewModelFromId(model.AnalistaId.Value);
                viewModel.AnalistaId = model.AnalistaId;
            }

            if (model.SolicitanteId.HasValue)
            {
                viewModel.Solicitante = GetUserViewModelFromId(model.SolicitanteId.Value);
                viewModel.SolicitanteId = model.SolicitanteId;
            }

            CargarAutorizadoresDesdeBaseDatos(viewModel);

            // si autorizadores es nulo...
            if (viewModel.AutorizadoresId != null)
            {
                // viewModel.AutorizadoresId = new int[] { };
            }

            CargarAnalistasParaComboBox(viewModel);
            CargarUnidad(viewModel);

            CalcularEstado(viewModel);

            return viewModel;
        }

        private void CargarUnidad(SolicitudViewModel viewModel)
        {
            var unidadId = dbContext.GetUnidadId(viewModel.UnidadId);
            if (unidadId > 0)
            {
                viewModel.Unidad = GetUnidad(unidadId);
            }
        }

        private Unidad GetUnidad(int unidadId)
        {
            return (from u in dbContext.Unidades
                    where u.Id == unidadId
                    select u).FirstOrDefault();
        }

        private ApplicationUserViewModel FromUsuarioIntranet(UsuarioIntranet other)
        {
            if (other == null)
                return new ApplicationUserViewModel()
                {
                    Id = -1,
                    Nombre = "Sin asignar",
                    Email = ""
                };

            return new ApplicationUserViewModel()
            {
                Id = other.Id,
                Nombre = other.Nombres + " " + other.ApellidoPaterno,
                Email = other.Email
            };
        }

        private IActionResult ListadoSolicitudes(ICollection<Solicitud> query, string ActionName, int? page)
        {
            ViewBag.Propiedades = new Preferencias(dbContext);
            ViewBag.contadores = CalcularContadores();
            ViewBag.RutaServer = getRutaServer();
            return View("Listado", new ListadoSolicitudesViewModel()
            {
                ActionName = ActionName,
                Solicitudes = query
            });
        }

        private List<int> CalcularContadores()
        {
            List<int> contadores = new List<int>();
            var prefs = new Preferencias(dbContext);

            // todas las solicitudes. 
            var todas = GetListadoSolicitudesActivas();
            contadores.Add(todas.Count());

            // solicitudes asignadas al analista. 
            var analista = GetUsuarioIntranet(session.DatosUsuario.RUT);
            var qry = todas.Where(t => t.Analista != null && t.Analista.Id == analista.Id);
            contadores.Add(qry.Count());

            //Por publicar
            var estados = new string[] {
                    Valores.EstadoSolicitudString(Valores.EstadoSolicitud.Borrador)
                };
            qry = todas.Where(s => estados.Contains(s.Estado));
            contadores.Add(qry.Count());

            //Publicaciones a certificar
            var pubInCertificacion = (from p in dbContext.Publicaciones.Include(t => t.Circular)
                                      where p.Estado == Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Activo)
                                      && p.FechaCertificacion <= nyp.Helpers.PrettyDate.SumarDiasHabiles(DateTime.Now, prefs.AlertaVerde)
                                      select p);
            contadores.Add(pubInCertificacion.Count());
            return contadores;
        }

        private string GetPhysicalFilename(string fileName)
        {

            var prefs = new Preferencias(dbContext);            
            string rutaArchivo = prefs.DirectorioTemporal;
            rutaArchivo = Path.Combine(rutaArchivo, "tmp-upload-zone", fileName);
            return rutaArchivo; 

        }

        private void RevertirEstadoAutorizadores(Solicitud solicitud)
        {
            var queryAutorizadores = from a in dbContext.Autorizadores.Include(u => u.UsuarioIntranet)
                                     where a.SolicitudId == solicitud.Id
                                     select a;
            if (solicitud.FechaSolicitudVB.HasValue)
            {
                RegistrarCambioCampo(solicitud, "SolicitudVB", solicitud.FechaSolicitudVB.ToString(), "Sin asignar");
            }
            solicitud.FechaSolicitudVB = null;
            solicitud.FechaSolicitudVB2 = null;
            solicitud.FechaSolicitudVB3 = null;

            foreach (var aut in queryAutorizadores)
            {
                if (aut.Estado != Valores.EstadoAutorizacionString(Valores.EstadoAutorizacion.Ingresado))
                {
                    RegistrarCambioCampo(solicitud, string.Format("Autorización {0}, {1}", aut.UsuarioIntranet.Nombres, aut.UsuarioIntranet.ApellidoPaterno),
                        aut.Estado, "Autorización VºBº revertida");
                    aut.Estado = Valores.EstadoAutorizacionString(Valores.EstadoAutorizacion.Ingresado);
                }
            }
        }

        private IActionResult CambioEstadoAutorizador(AutorizacionSolicitudViewModel model)
        {
            TryValidateModel(model);
            if (ModelState.IsValid)
            {
                var solicitud = GetSolicitud(model.SolicitudId);
                var aut = (from a in dbContext.Autorizadores
                           where a.SolicitudId == model.SolicitudId && a.UsuarioIntranetId == session.DatosUsuario.RUT
                           select a).FirstOrDefault();
                if (aut != null)
                {
                    if (aut.Estado != model.Estado || aut.Observaciones != model.Observaciones)
                    {
                        var u = GetUsuarioIntranet(session.DatosUsuario.RUT);
                        if (aut.Estado != model.Estado)
                        {
                            AgregarCambio(solicitud, "Estado Autorización", aut.Estado, model.Estado);
                        }
                        if (model.Observaciones != null && aut.Observaciones != model.Observaciones)
                        {
                            AgregarCambio(solicitud, "Observaciones Autorización", aut.Observaciones, model.Observaciones);
                        }
                        aut.Estado = model.Estado;
                        aut.FechaModificacion = DateTime.Now;
                        aut.Observaciones = model.Observaciones;

                        dbContext.SaveChanges();
                        if (RefrescarEstado(solicitud))
                        {
                            NotificarSolicitudVistoBueno(solicitud, Usuario, model.TipoEvento);
                            dbContext.SaveChanges();
                        }
                    }
                    return Ver(model.SolicitudId);
                }
            }
            return HttpBadRequest();
        }

        private void NotificarNuevaSolicitud(Solicitud nueva)
        {
            var dst = new List<IDestinatario>();
            // si la solicitud tiene analista, enviar a él / ella
            if (nueva.Analista != null)
            {
                dst.Add(new Destinatario { Email = nueva.Analista.Email, Nombre = nueva.Analista.Nombres + " " + nueva.Analista.ApellidoPaterno });
            }
            else
            {
                // todos los analistas
                var q = from a in dbContext.UsuariosIntranet
                        where a.AnalistaNYP == true
                        select new Destinatario { Email = a.Email, Nombre = a.Nombres + " " + a.ApellidoPaterno };
                dst.AddRange(q.ToList());
            }

            // Añadir destinatarios copia 
            dst.AnadirUsuariosACopiar(nueva);

            if (dst.Count() > 0)
            {
                var msg = RenderViewToString("~/Views/Templates/Nuevasolicitud", new NotificacionSolicitudViewModel
                {
                    Solicitud = nueva
                });
                EmailSender.SendEmailToList(dst, "Nueva Solicitud de Publicación", msg, null);
            }
        }

        //private static void AnadirUsuariosACopiar(Solicitud solicitud, List<IDestinatario> destinatarios)
        //{
        //    foreach (var dc in solicitud.UsuariosNotificados)
        //    {
        //        if (!destinatarios.Any(x => x.Email == dc.Email)) // Evitar agregar email repetido
        //            destinatarios.Add(new Destinatario { Email = dc.Email, Nombre = dc.Usuario != null ? dc.Usuario.Nombres + " " + dc.Usuario.ApellidoPaterno : dc.Email });
        //    }
        //}

        private void NotificarSolicitudModificada(Solicitud solicitud, UsuarioIntranet autor)
        {
            var dst = new List<IDestinatario>();
            // si la solicitud tiene analista, enviar a él / ella
            if (solicitud.Analista != null)
            {
                if (solicitud.Analista.Id == autor.Id)
                {
                    // return;
                }
                dst.Add(new Destinatario { Email = solicitud.Analista.Email, Nombre = solicitud.Analista.NombreCompleto() });
            }
            else
            {
                // todos los analistas
                var analistas = from a in dbContext.UsuariosIntranet
                                where a.AnalistaNYP == true
                                select new Destinatario { Email = a.Email, Nombre = a.NombreCompleto() };
                dst.AddRange(analistas.ToList());
            }

            // Intervinientes
            var intervinientes = from a in solicitud.Autorizadores
                                 select new Destinatario { Email = a.UsuarioIntranet.Email, Nombre = a.UsuarioIntranet.NombreCompleto() };
            dst.AddRange(intervinientes.ToList());

            dst.AnadirUsuariosACopiar(solicitud);

            if (dst.Count() > 0)
            {
                var msg = RenderViewToString("~/Views/Templates/SolicitudModificada", new NotificacionSolicitudModificadaViewModel
                {
                    Autor = autor,
                    Solicitud = solicitud
                });
                EmailSender.SendEmailToList(dst, string.Format("Se ha realizado una acción sobre la Solicitud Nº {0}", solicitud.Id), msg, null);
            }
        }

        private void NotificarSolicitudAnuladaPorAnalista(Solicitud solicitud, UsuarioIntranet usuario, string MotivoAnulacion)
        {

            var dst = new List<IDestinatario>();
            // si la solicitud tiene analista, enviar a él / ella
            if (solicitud.Analista != null)
            {
                dst.Add(new Destinatario { Email = solicitud.Analista.Email, Nombre = solicitud.Analista.NombreCompleto() });
            }
            else
            {
                // todos los analistas
                var analistas = from a in dbContext.UsuariosIntranet
                                where a.AnalistaNYP == true
                                select new Destinatario { Email = a.Email, Nombre = a.NombreCompleto() };
                dst.AddRange(analistas.ToList());
            }

            // Intervinientes
            var intervinientes = from a in solicitud.Autorizadores
                                 select new Destinatario { Email = a.UsuarioIntranet.Email, Nombre = a.UsuarioIntranet.NombreCompleto() };
            dst.AddRange(intervinientes.ToList());
            //((IEnumerable<Destinatario>)dst).ana

            dst.AnadirUsuariosACopiar(solicitud);

            if (dst.Count() > 0)
            {
                var msg = RenderViewToString("~/Views/Templates/SolicitudAnulada", new NotificacionSolicitudAnuladaViewModel
                {
                    MotivoAnulacion = MotivoAnulacion,
                    Solicitud = solicitud
                });
                EmailSender.SendEmailToList(dst, string.Format("Se ha realizado una acción sobre la Solicitud Nº {0}", solicitud.Id), msg, null);
            }
        }

        private void NotificarSolicitudVistoBueno(Solicitud solicitud, UsuarioIntranet usuario, string TipoEvento)
        {
            var dst = new List<IDestinatario>();
            // si la solicitud tiene analista, enviar a él / ella
            if (solicitud.Analista != null)
            {
                dst.Add(new Destinatario { Email = solicitud.Analista.Email, Nombre = solicitud.Analista.NombreCompleto() });
            }
            else
            {
                // todos los analistas
                var analistas = from a in dbContext.UsuariosIntranet
                                where a.AnalistaNYP == true
                                select new Destinatario { Email = a.Email, Nombre = a.NombreCompleto() };
                dst.AddRange(analistas.ToList());
            }

            // Intervinientes
            var intervinientes = from a in solicitud.Autorizadores
                                 select new Destinatario { Email = a.UsuarioIntranet.Email, Nombre = a.UsuarioIntranet.NombreCompleto() };
            dst.AddRange(intervinientes.ToList());

            dst.AnadirUsuariosACopiar(solicitud);

            if (dst.Count() > 0)
            {
                var msg = RenderViewToString("~/Views/Templates/SolicitudAutorizadaVB", new NotificacionSolicitudAutorizadaViewModel
                {
                    Autor = usuario,
                    TipoEvento = TipoEvento,
                    Solicitud = solicitud
                });
                EmailSender.SendEmailToList(dst, string.Format("Solicitud Nº {0} {1} por autorizador", solicitud.Id, TipoEvento.ToUpper()), msg, null);
            }
        }

        private bool RefrescarEstado(Solicitud s)
        {
            var solicitudViewModel = ExtraerSolicitudViewModelDesdeModelId(s.Id);
            var estadoAnterior = s.Estado;
            CalcularEstado(solicitudViewModel);
            s.Estado = solicitudViewModel.Estado;
            if (s.Estado == "OK")
            {
                s.FechaOK = DateTime.Now;
            }
            return estadoAnterior != s.Estado;
        }

        private IActionResult CambioEstadoAutorizacionObservaciones(AutorizacionSolicitudViewModel model)
        {
            SolicitudViewModel solicitud = null;
            if (ModelState.IsValid)
            {
                solicitud = ExtraerSolicitudViewModelDesdeModelId(model.SolicitudId);
                if (solicitud == null)
                {
                    return HttpBadRequest();
                }
                if (string.IsNullOrEmpty(model.Observaciones))
                {
                    ModelState.AddModelError("Observaciones", "Debe indicar la razón de su decisión");
                }
                else
                {
                    return CambioEstadoAutorizador(model);
                }
            }
            ViewBag.Titulo = string.Format("{0} - Nº {1}", model.Estado, solicitud.Id);
            ViewBag.RutaServer = getRutaServer();
            return View("CambioEstadoAutorizacion", model);
        }

        private ApplicationUserViewModel UserToApplicationUser(UsuarioIntranet user)
        {
            if (user != null)
                return new ApplicationUserViewModel()
                {
                    Id = user.Id,
                    Cargo = user.Cargo,
                    Email = user.Email,
                    Nombre = string.Format("{0}, {1}", user.ApellidoPaterno, user.Nombres)
                };
            return null;
        }

        private UsuarioIntranet GetUsuarioIntranet(ApplicationUserViewModel user)
        {
            if (user != null)
            {
                return GetUsuarioIntranet(user.Id);
            }
            return null;
        }

        private UsuarioIntranet GetUsuarioIntranetWithEmail(string email)
        {
            var res = (from u in dbContext.UsuariosIntranet.Include(t => t.Unidad).ThenInclude(t => t.Area).ThenInclude(t => t.Gerencia)
                    where u.Email == email
                    select u);

            if (res.Count() == 0) return null;

            return res.FirstOrDefault();
        }

        private UsuarioIntranet GetUsuarioIntranet(int id)
        {
            return (from u in dbContext.UsuariosIntranet.Include(t => t.Unidad).ThenInclude(t => t.Area).ThenInclude(t => t.Gerencia)
                    where u.Id == id
                    select u).FirstOrDefault();
        }

        private ApplicationUserViewModel GetUserViewModelFromId(int id)
        {
            return UserToApplicationUser(GetUsuarioIntranet(id));
        }

        private void TraspasarDatosDesdeViewModelAEntity(SolicitudViewModel model, Solicitud dst)
        {
            var solicitante = dst.Solicitante;
            // Analista puede usar cualquier valor para solicitante
            if (Usuario.AnalistaNYP)
            {
                if (model.SolicitanteId.HasValue)
                {
                    solicitante = GetUsuarioIntranet(model.SolicitanteId.Value);
                }

                // Si no había solicitante, refrescamos la fecha de ingreso
                if (dst.Solicitante == null && !dst.FechaSolicitud.HasValue)
                {
                    dst.FechaSolicitud = DateTime.Now;
                }
            }
            else
            {
                // Sólo asignar solicitante si este era nulo, dado que no tenemos
                // la autoridad para cambiarlo
                if (dst.Solicitante == null)
                {
                    solicitante = GetUsuarioIntranet(session.DatosUsuario.RUT);
                    if (!dst.FechaSolicitud.HasValue)
                    {
                        dst.FechaSolicitud = DateTime.Now;
                    }
                }
            }
            dst.Solicitante = solicitante;

            var analista = dst.Analista;
            if (Usuario.AnalistaNYP)
            {
                if (model.AnalistaId.HasValue)
                {
                    analista = GetUsuarioIntranet(model.AnalistaId.Value);
                }
                if (dst.Analista == null && analista != null)
                {
                    dst.FechaIngreso = DateTime.Now;
                }
            }
            
            dst.Analista = analista;


            dst.Consultas = model.Consultas;
            dst.Titulo = model.Titulo;

            CalcularEstado(model);
            dst.Estado = model.Estado;

            dst.CodigoDocumento = model.CodigoDocumento;
            dst.Objetivo = model.Objetivo;
            dst.Tipo = model.TipoDocumento;
            dst.Destino = model.Destino;
            dst.FuncionamientoActual = model.FuncionamientoActual;
            dst.FuncionamientoNuevo = model.FuncionamientoNuevo;

            // Asignar usuarios a notificar
            //dst.UsuariosNotificados = new List<UsuarioNotificado>();
            //foreach(var email in model.UsuariosNotificadosEmails)
            //{
            //    dst.UsuariosNotificados.Add(new UsuarioNotificado
            //    {
            //        Email = email,
            //        Usuario = GetUsuarioIntranetWithEmail(email) 
            //    });
            //}

            asignarFecha(model, dst, "FechaIngreso");
            asignarFecha(model, dst, "FechaInicioVigencia");
            asignarFecha(model, dst, "FechaPublicacion");
            asignarFecha(model, dst, "FechaSolicitud");
            asignarFecha(model, dst, "FechaSolicitudVB");

            asignarUnidad(dst, model.UnidadId);

            dst.Impacto = model.Impacto;
            dst.Materia = model.Materia;
        }

        private void asignarUnidad(Solicitud dst, string unidadId)
        {
            var iUnidadId = dbContext.GetUnidadId(unidadId);
            if (dst.Unidad != null)
            {
                if (dst.Unidad.Id == iUnidadId)
                {
                    return;
                }
            }
            var unidad = GetUnidad(iUnidadId);
            if (unidad != null)
            {
                dst.Unidad = unidad;
            }
        }

        private void GuardarAutorizadoresDesdeViewModelEnContext(Solicitud solicitud, SolicitudViewModel model)
        {
            if (model.AutorizadoresId == null)
            {
                // borrar todo
                model.AutorizadoresId = new List<int>();
            }

            // 0. Lista anterior, para registro
            var existentes = (from uid in dbContext.Autorizadores
                              where uid.SolicitudId == solicitud.Id
                              select uid.UsuarioIntranetId).ToList();

            // Para actualizar intervinientes:
            // 1. Generar nueva lista de intervinientes 

            var nuevaLista = from uId in model.AutorizadoresId
                             select new AutorizacionSolicitud()
                             {
                                 Estado = Valores.EstadoAutorizacionString(Valores.EstadoAutorizacion.Ingresado),
                                 FechaModificacion = DateTime.Now,
                                 Observaciones = "",
                                 SolicitudId = solicitud.Id,
                                 UsuarioIntranetId = uId
                             };

            var nuevosItems = (from u in nuevaLista
                               select u.UsuarioIntranetId).ToArray();

            // 2. Generar una lista con los intervinientes que se deben mantener
            var toKeep = (from u in dbContext.Autorizadores
                          where u.SolicitudId == solicitud.Id && nuevosItems.Contains(u.UsuarioIntranetId)
                          select u.UsuarioIntranetId).ToArray();

            // 3. Generar una lista con los elementos a borrar
            var toDelete = from u in dbContext.Autorizadores
                           where u.SolicitudId == solicitud.Id && !toKeep.Contains(u.UsuarioIntranetId)
                           select u;

            // 4. Procesar lista a insertar (ignorando aquellos que vamos a mantener, para no modificar sus estados)
            var toInsert = from u in nuevaLista
                           where !toKeep.Contains(u.UsuarioIntranetId)
                           select u;


            // 4. Procesar inserts
            dbContext.Autorizadores.AddRange(toInsert);

            // 5. Procesar deletes
            dbContext.Autorizadores.RemoveRange(toDelete);

            if (toInsert.Any() || toDelete.Any())
            {
                string rutsExistentes = "(sin valores)", rutsInsertados = "", rutsEliminados = "";
                if (existentes.Any())
                {
                    rutsExistentes = string.Join(", ", existentes);
                }
                if (toInsert.Any())
                {
                    rutsInsertados = "Agregados: " + string.Join(", ", string.Join(", ", toInsert));
                }
                if (toDelete.Any())
                {
                    rutsEliminados = "Eliminados: " + string.Join(", ", string.Join(", ", toDelete));
                }

                if (rutsEliminados != "" && rutsInsertados != "")
                {
                    rutsEliminados = rutsEliminados + ", ";
                }
                AgregarCambio(solicitud, "Autorizadores", rutsExistentes, rutsEliminados + rutsInsertados);
            }
        }

        private void GuardarUsuariosNotificadosDesdeViewModelEnContext(Solicitud solicitud, SolicitudViewModel model)
        {
            if (model.UsuariosNotificadosEmails == null)
            {
                // borrar todo
                model.UsuariosNotificadosEmails = new List<string>();
            }

            // 0. Lista anterior, para registro
            var existentes = (from uid in dbContext.UsuariosNotificados
                              where uid.Solicitud.Id == solicitud.Id
                              select uid).ToList();

            // Para actualizar intervinientes:
            // 1. Generar nueva lista de usuarios a notificar (copia) 
            var nuevaLista = from email in model.UsuariosNotificadosEmails
                             select new UsuarioNotificado()
                             {
                                 Email = email,
                                 Solicitud = solicitud,
                                 Usuario = GetUsuarioIntranetWithEmail(email)
                             };

            var nuevosEmails = (from u in nuevaLista
                               select u.Email).ToArray();

            // 2. Generar una lista con los usuarios que se deben mantener
            var toKeep = (from u in dbContext.UsuariosNotificados
                          where u.Solicitud.Id == solicitud.Id && nuevosEmails.Contains(u.Email)
                          select u.Email).ToArray();

            // 3. Generar una lista con los elementos a borrar
            var toDelete = from u in dbContext.UsuariosNotificados
                           where u.Solicitud.Id == solicitud.Id && !toKeep.Contains(u.Email)
                           select u;

            // 4. Procesar lista a insertar 
            var toInsert = from u in nuevaLista
                           where !toKeep.Contains(u.Email)
                           select u;

            // 4. Procesar inserts
            dbContext.UsuariosNotificados.AddRange(toInsert);

            // 5. Procesar deletes
            dbContext.UsuariosNotificados.RemoveRange(toDelete);

            if (toInsert.Any() || toDelete.Any())
            {
                string rutsExistentes = "(sin valores)", rutsInsertados = "", rutsEliminados = "";
                if (existentes.Any())
                {
                    rutsExistentes = string.Join(", ", existentes);
                }
                if (toInsert.Any())
                {
                    rutsInsertados = "Agregados: " + string.Join(", ", string.Join(", ", toInsert));
                }
                if (toDelete.Any())
                {
                    rutsEliminados = "Eliminados: " + string.Join(", ", string.Join(", ", toDelete));
                }

                if (rutsEliminados != "" && rutsInsertados != "")
                {
                    rutsEliminados = rutsEliminados + ", ";
                }
                AgregarCambio(solicitud, "Usuarios Notificados (Copiados)", rutsExistentes, rutsEliminados + rutsInsertados);
            }
        }

        private static void CargarAnalistasParaComboBox(SolicitudViewModel nueva)
        {
            nueva.Analistas = (from u in dbContext.UsuariosIntranet
                               where u.AnalistaNYP == true
                               select new ApplicationUserViewModel()
                               {
                                   Id = u.Id,
                                   Cargo = u.Cargo,
                                   Email = u.Email,
                                   Nombre = string.Format("{0}, {1}", u.ApellidoPaterno, u.Nombres)
                               }).ToList();
        }

        private IActionResult MensajeError(string titulo, string mensaje, IList<string> errores)
        {
            ViewBag.RutaServer = getRutaServer();
            return View("MensajeError", new MensajeErrorViewModel()
            {
                Titulo = titulo,
                Mensaje = mensaje,
                Errores = errores
            });
        }

        private bool VerificarDatosAntesDePublicar(SolicitudViewModel solicitud, ModelStateDictionary modelState)
        {
            if (modelState.IsValid)
            {
                // Verificar que todos los autorizadores hayan dado el visto bueno
                if (solicitud.Autorizadores.Any())
                {
                    foreach (var aut in solicitud.Autorizadores)
                    {
                        if (aut.Autorizacion.Estado != "Autorizado")
                        {
                            modelState.AddModelError("", string.Format("Autorización faltante: {0} (estado: {1})", aut.Interviniente.Nombre, aut.Autorizacion.Estado));
                        }
                    }
                }
                if (solicitud.AutorizadoresId.Count != solicitud.Autorizadores.Count)
                {
                    modelState.AddModelError("", string.Format("ERROR Interno: No se cargaron todos los Autorizadores"));
                }
                return modelState.IsValid;
            }
            return false;
        }

        private bool VerificarDatosSolicitud(SolicitudViewModel model, ModelStateDictionary modelState, ICollection<IFormFile> colArchivos)
        {
            if (model.AutorizadoresId == null || !model.AutorizadoresId.Any())
            {
                modelState.AddModelError("AutorizadoresId", "Debe existir al menos un autorizador para la solicitud");
            }
            if (colArchivos != null)
            {
                if (colArchivos.Count == 0)
                {
                    modelState.AddModelError("ArchivosAdjuntos", "Debe adjuntar al menos un archivo para la publicación");
                }
            }


            /*if ((model.ArchivosAdjuntos == null || !model.ArchivosAdjuntos.Any()) && (model.ArchivoAdjunto == null))
            {
                modelState.AddModelError("ArchivosAdjuntos", "Debe adjuntar al menos un archivo para la publicación");
            }
            */

            var unidadId = dbContext.GetUnidadId(model.UnidadId);
            if (unidadId == 0)
            {
                modelState.AddModelError("UnidadId", "Unidad organizacional incorrecta (no seleccionar Gerencia o Área)");
            }
            return modelState.IsValid;
        }

        private bool AgregarArchivo(Solicitud solicitud, string codigoArchivo, string descripcionArchivo,
            string tipoDocumento, IFormFile archivoAdjunto, out string mensaje, bool notificar)
        {
            var archivos = new List<Archivo>();

            {
                var contentDisposition = ContentDispositionHeaderValue.Parse(archivoAdjunto.ContentDisposition);
                var filenameAUX = contentDisposition.FileName.Trim('"').Split('\\');
                var filename = filenameAUX[filenameAUX.Length - 1]; 

                var adjuntos = (from ad in dbContext.ArchivosEnSolicitud
                                where ad.SolicitudId == solicitud.Id
                                select ad.ArchivoId).ToList();

                var repetido = (from a in dbContext.Archivos
                                where a.NombreArchivoOriginal == filename && adjuntos.Contains(a.Id)
                                select a).FirstOrDefault();

                if (repetido != null)
                {
                    mensaje = string.Format("El archivo '{0}' ya esta registrado", filename);
                    return false;
                }

                var mime = GetMimeMapping(filename);
                if (mime == null)
                {
                    var extension = Path.GetExtension(filename);
                    // Tipo de archivo no permitido
                    mensaje = string.Format("Tipo de archivo '{0}' no permitido", extension);
                    return false;
                }

                var internalName = Guid.NewGuid().ToString("n");
                var physicalFilename = GetPhysicalFilename(internalName);
                archivoAdjunto.SaveAs(physicalFilename);

                if (descripcionArchivo == null)
                    descripcionArchivo = "";

                archivos.Add(new Archivo()
                {
                    CodigoDocumento = codigoArchivo != null ? codigoArchivo : "",
                    TituloDocumento = descripcionArchivo,
                    Tipo = tipoDocumento,
                    NombreArchivoOriginal = filename,
                    NombreFisico = internalName
                });
            }
            dbContext.Archivos.AddRange(archivos);
            RevertirEstadoAutorizadores(solicitud);
            dbContext.SaveChanges();

            // crear nav
            foreach (var a in archivos)
            {
                dbContext.ArchivosEnSolicitud.Add(new ArchivosEnSolicitud()
                {
                    ArchivoId = a.Id,
                    SolicitudId = solicitud.Id
                });
            }

            AgregarCambio(solicitud, "Adjuntos", null, string.Join(", ", archivos));
            dbContext.SaveChanges();

            var refresco = GetSolicitud(solicitud.Id);
            if (notificar)
            {
                NotificarSolicitudModificada(refresco, Usuario);
            }
            mensaje = "Archivo guardado con éxito";
            return true;
        }

        private Valores.EstadoSolicitud CalcularEstado(SolicitudViewModel s)
        {
            int countVBEnviado = 0, countDeclinado = 0;
            if (s.Estado != Valores.EstadoSolicitud.Rechazado.ToString())
            {
                if (s.SolicitanteId == null)
                {
                    s.Estado = Valores.EstadoSolicitudString(Valores.EstadoSolicitud.Nueva);
                    return Valores.EstadoSolicitud.Nueva;
                }
                if (s.Estado != Valores.EstadoSolicitud.Publicado.ToString() && s.Estado != Valores.EstadoSolicitud.Borrador.ToString())
                {

                    if (s.AnalistaId == null)
                    {
                        s.Estado = Valores.EstadoSolicitudString(Valores.EstadoSolicitud.Nueva);
                        return Valores.EstadoSolicitud.Nueva;
                    }
                    s.Estado = Valores.EstadoSolicitudString(Valores.EstadoSolicitud.EnProceso);

                    if (s.AutorizadoresId != null && s.AutorizadoresId.Any())
                    {
                        var modelState = new ModelStateDictionary();
                        modelState.Clear();
                        if (VerificarDatosSolicitud(s, modelState, null) && VerificarDatosAntesDePublicar(s, modelState))
                        {
                            s.Estado = Valores.EstadoSolicitudString(Valores.EstadoSolicitud.OK);
                            return Valores.EstadoSolicitud.OK;
                        }
                        else
                        {
                            foreach (var aut in s.Autorizadores)
                            {
                                if (aut.Autorizacion.Estado == Valores.EstadoAutorizacionString(Valores.EstadoAutorizacion.Declinado))
                                {
                                    countDeclinado++;
                                }
                                else if (aut.Autorizacion.Estado == Valores.EstadoAutorizacionString(Valores.EstadoAutorizacion.VBEnviado))
                                {
                                    countVBEnviado++;
                                }
                            }

                            if (countDeclinado > 0)
                            {
                                s.Estado = Valores.EstadoSolicitudString(Valores.EstadoSolicitud.VBRechazado);
                                return Valores.EstadoSolicitud.VBRechazado;
                            }
                            else if (countVBEnviado > 0)
                            {
                                s.Estado = Valores.EstadoSolicitudString(Valores.EstadoSolicitud.EsperaVB);
                                return Valores.EstadoSolicitud.EsperaVB;
                            }
                            else
                            {
                                s.Estado = Valores.EstadoSolicitudString(Valores.EstadoSolicitud.EnProceso);
                                return Valores.EstadoSolicitud.EnProceso;
                            }
                        }
                    }
                    else
                        return Valores.EstadoSolicitud.EnProceso;

                }
                else if (s.Estado != Valores.EstadoSolicitud.Publicado.ToString())
                    return Valores.EstadoSolicitud.Publicado;
                else
                    return Valores.EstadoSolicitud.Borrador;
            }
            else
                return Valores.EstadoSolicitud.Rechazado;
        }


        private String CalcularEstadoSolicitud(Solicitud s)
        {
            SolicitudViewModel sol = ExtraerSolicitudViewModelDesdeModelId(s.Id, false);
            return CalcularEstado(sol).ToString();
        }

        private string NombreUsuario(int? id, ApplicationUserViewModel usuario)
        {
            var result = "sin asignar";
            if (id != null)
            {
                if (usuario == null)
                {
                    var u = GetUsuarioIntranet(id.Value);
                    result = u.Nombres + " " + u.ApellidoPaterno;
                }
                else
                {
                    result = usuario.Nombre;
                }
            }
            return result;
        }

        private void RegistrarCambioNombre(Solicitud solicitud, string campo, int? idAnterior, int? idNuevo, ApplicationUserViewModel usuarioAnterior, ApplicationUserViewModel usuarioNuevo)
        {
            if (idAnterior != idNuevo)
            {
                var nombreAnterior = NombreUsuario(idAnterior, usuarioAnterior);
                var nombreNuevo = NombreUsuario(idNuevo, usuarioNuevo);
                AgregarCambio(solicitud, campo, nombreAnterior, nombreNuevo);
            }
        }

        private void AgregarCambio(Solicitud solicitud, string nombreCampo, string valorAnterior, string valorNuevo)
        {
            solicitud.Historial.Add(new Evento()
            {
                Autor = Usuario,
                Campo = nombreCampo,
                Fecha = DateTime.Now,
                Titulo = "Modificación",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo
            });
        }

        private void RegistrarCambios(Solicitud solicitud, SolicitudViewModel anterior, SolicitudViewModel nuevo)
        {
            RegistrarCambioNombre(solicitud, "Analista", anterior.AnalistaId, nuevo.AnalistaId, anterior.Analista, nuevo.Analista);
            RegistrarCambioNombre(solicitud, "Solicitante", anterior.SolicitanteId, nuevo.SolicitanteId, anterior.Solicitante, nuevo.Solicitante);
            RegistrarCambioCampo(solicitud, "Código Documento", anterior.CodigoDocumento, nuevo.CodigoDocumento);
            RegistrarCambioCampo(solicitud, "Nombre Documento", anterior.Titulo, nuevo.Titulo);
            RegistrarCambioCampo(solicitud, "Áreas Impactadas", anterior.Destino, nuevo.Destino);
            RegistrarCambioCampo(solicitud, "Datos para Consulta", anterior.Consultas, nuevo.Consultas);
            RegistrarCambioCampo(solicitud, "Impacto", anterior.Impacto, nuevo.Impacto);
            RegistrarCambioCampo(solicitud, "Estado", anterior.Estado, nuevo.Estado);
            var ant = "Sin asignar";
            var nueva = "Sin asignar";
            if (anterior.Unidad != null)
            {
                ant = anterior.Unidad.Nombre;
            }
            if (nuevo.Unidad != null)
            {
                nueva = nuevo.Unidad.Nombre;
            }
            RegistrarCambioCampo(solicitud, "Unidad", ant, nueva);
        }

        private void RegistrarCambioCampo(Solicitud solicitud, string campo, string valorAnterior, string valorNuevo)
        {
            if (valorAnterior != valorNuevo)
            {
                AgregarCambio(solicitud, campo, valorAnterior, valorNuevo);
            }
        }

        private string AutorizadoresString(IList<EstadoAutorizacionViewModel> autorizadores)
        {
            var result = new StringBuilder();
            foreach (var autorizador in autorizadores)
            {
                result.AppendLine(string.Format("{0} - {1}", autorizador.Interviniente.Nombre, autorizador.Interviniente.Cargo));
            }
            return result.ToString();
        }

        private Circular CrearCircularDesdePublicacion(NuevaPublicacionViewModel model)
        {
            var result = new Circular()
            {
                Consultas = model.Solicitud.Consultas,
                Destino = model.Solicitud.Destino,
                //InicioVigencia = model.Solicitud.FechaInicioVigencia != null ? model.Solicitud.FechaInicioVigencia.Value : model.FechaInicioVigencia,
                InicioVigencia = model.FechaInicioVigencia,
                Materia = model.Solicitud.Materia,
                Objetivo = model.Solicitud.Objetivo,
                Responsable = AutorizadoresString(model.Solicitud.Autorizadores),
                FuncionamientoActual = model.Solicitud.FuncionamientoActual,
                FuncionamientoNuevo = model.Solicitud.FuncionamientoNuevo
            };
            return result;
        }

        public void LlenarDatosUnidad(SolicitudViewModel model)
        {
            model.Area = (from a in dbContext.Areas where a.Id == model.Unidad.AreaId.Value select a).SingleOrDefault();
            if (model.Area != null)
            {
                model.Gerencia = (from g in dbContext.Gerencias where g.Id == model.Area.GerenciaId select g).SingleOrDefault();
            }
        }


        #endregion

        private String getRutaServer()
        {
            //var prefs = new Preferencias(dbContext);
            //return prefs.RutaServer;
            return ""; 
        }
    }
}
