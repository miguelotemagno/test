﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Mvc;
using Microsoft.AspNet.Authorization;
using nyp.DataModels;
using Microsoft.Data.Entity.Infrastructure;
using Newtonsoft.Json;
using nyp.GestorDocumental.Service;
using Microsoft.AspNet.Hosting;
using nyp.Services;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace nyp.Controllers
{
    public class RestriccionController : ControllerNYP
    {
        private IEmailSender emailSender;
        private NYPContext dbContext;
        private IGestorDocumental documentManager;
        private IHostingEnvironment hostingEnvironment;
        private ISessionService session;

        public RestriccionController(
            Services.IEmailSender mailSenderService,
            NYPContext context,
            IGestorDocumental gestorDocumental,
            IHostingEnvironment env,
            ISessionService sessionContext)
        {
            emailSender = mailSenderService;
            dbContext = context;
            documentManager = gestorDocumental;
            hostingEnvironment = env;
            session = sessionContext;
        }

        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }


        [HttpPost]
        [Authorize(Roles = "AnalistaNYP")]
        public string Agregar(int SolicitudID, int GerenciaID, int AreaID, int UnidadID, string ListaUsuarios, string DescRegla)
        {
            //obtener el objeto gerencia a partir del ID

            var objGerencia = (from gerencia in dbContext.Gerencias
                               where gerencia.Id == GerenciaID
                               select gerencia).FirstOrDefault();

            var objArea = (from area in dbContext.Areas
                           where area.Id == AreaID
                           select area).FirstOrDefault();

            var objUnidad = (from unidad in dbContext.Unidades
                             where unidad.Id == UnidadID
                             select unidad).FirstOrDefault();

            var objSolicitud = (from sol in dbContext.Solicitudes
                                where sol.Id == SolicitudID
                                select sol).FirstOrDefault();

            var objPublicacion = (from publicacion in dbContext.Publicaciones
                                  where publicacion.Solicitud.Id == SolicitudID
                                  select publicacion).FirstOrDefault();



            var excepciones = new List<ExclusionUsuario>();
            if (ListaUsuarios != null)
            {
                string[] lista_usuarios = ListaUsuarios.Split(',');
                for (int i = 0; i < lista_usuarios.Length; i++)
                {
                    var usuarioAux = (from usuario in dbContext.UsuariosIntranet
                                      where usuario.Id == Int32.Parse(lista_usuarios[i])
                                      select usuario).FirstOrDefault();
                    excepciones.Add(new ExclusionUsuario
                    {
                        UsuarioIntranet = usuarioAux
                    });

                }
            }


            var restriccion = dbContext.Set<Restriccion>();
            restriccion.Add(new Restriccion
            {
                DescRegla = DescRegla,
                Gerencia = objGerencia,
                Area = objArea,
                Unidad = objUnidad,
                Publicacion = objPublicacion,
                Solicitud = objSolicitud,
                ExclusionUsuario = excepciones

            });
            dbContext.SaveChanges();
            return "1";
        }

        [HttpPost]
        [Authorize(Roles = "AnalistaNYP")]
        public JsonResult Consultar(int SolicitudID)
        {
            var restricciones = (from restric in dbContext.Restricciones
                                 where restric.Solicitud.Id == SolicitudID
                                 select restric);

            return Json(restricciones);

        }

        [HttpPost]
        [Authorize(Roles = "AnalistaNYP")]
        public JsonResult ConsultarPublicacion(int PublicacionID)
        {
            var restricciones = (from restric in dbContext.Restricciones
                                 where restric.PublicacionId == PublicacionID
                                 select restric);

            return Json(restricciones);

        }

        [HttpPost]
        [Authorize(Roles = "AnalistaNYP")]
        public string ConsultarDetalles(int ReglaID)
        {
            string response = "No se encontraron resultados";
            Restriccion regla = (from rest in dbContext.Restricciones
                                 where rest.RestriccionId == ReglaID
                                 select rest).FirstOrDefault();
            Gerencia gerencia = (from geren in dbContext.Gerencias
                                 where geren.Id == regla.GerenciaId
                                 select geren).FirstOrDefault();
            if (gerencia != null)
                response = "<b>GERENCIA:</b> " + gerencia.Nombre + "<br/>";
            
            Area area = (from ar in dbContext.Areas
                         where ar.Id == regla.AreaId
                         select ar).FirstOrDefault();
            if (area != null)
                response += "<b>AREA:</b> " + area.Nombre + "<br/>";
            
            else
                return response;

            Unidad unidad = (from uni in dbContext.Unidades
                             where uni.Id == regla.UnidadId
                             select uni).FirstOrDefault();
            if (unidad != null)
            {
                response += "<b>UNIDAD:</b> " + unidad.Nombre + "<br/>";
            }

            var usuariosE = (from r in dbContext.Restricciones
                             join eu in dbContext.ExclusionesUsuario
                             on r.RestriccionId equals eu.RestriccionRestriccionId
                             join user in dbContext.UsuariosIntranet
                                  on eu.UsuarioIntranetId equals user.Id
                             where r.RestriccionId == ReglaID
                             select user);


            foreach (UsuarioIntranet ru in usuariosE)
            {
                response += "<b> - Excepto Usuario:</b> " + ru.NombreCompleto() + " " + " (" + ru.Cargo + ")<br/>";
            }
            return response;

            //*/

        }
        [HttpPost]
        [Authorize(Roles = "AnalistaNYP")]
        public string Eliminar(int ReglaID)
        {
            var exlusiones = (from eu in dbContext.ExclusionesUsuario where eu.RestriccionRestriccionId == ReglaID select eu); 
            foreach (ExclusionUsuario ex in exlusiones)
            {
                dbContext.ExclusionesUsuario.Remove(ex); 
            }
            var restriccion = (from rt in dbContext.Restricciones where rt.RestriccionId == ReglaID select rt);
            foreach (Restriccion rest3 in restriccion)
            {
                dbContext.Restricciones.Remove(rest3);
            }

            dbContext.SaveChanges(); 
            return "1";
        }

        [HttpPost]
        [Authorize(Roles = "AnalistaNYP")]
        public string EliminarTodos(long SolicitudID)
        {
            var exlusiones = (from eu in dbContext.ExclusionesUsuario join 
                              rt in dbContext.Restricciones on eu.RestriccionRestriccionId equals rt.RestriccionId
                              where rt.SolicitudId == SolicitudID
                              select eu);
            foreach (ExclusionUsuario ex in exlusiones)
            {
                dbContext.ExclusionesUsuario.Remove(ex);
            }
            var restriccion = (from rt in dbContext.Restricciones where rt.SolicitudId == SolicitudID select rt);
            foreach (Restriccion rest3 in restriccion)
            {
                dbContext.Restricciones.Remove(rest3);
            }

            dbContext.SaveChanges();
            return "1";
        }

    }


}
