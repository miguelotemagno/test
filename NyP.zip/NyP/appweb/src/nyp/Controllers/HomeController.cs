﻿using Microsoft.AspNet.Authorization;
using Microsoft.AspNet.Mvc;
using Microsoft.Data.Entity;
using nyp.DataModels;
using nyp.GestorDocumental.Service;
using nyp.Models;
using nyp.Session;
using nyp.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text.RegularExpressions;
using Newtonsoft.Json.Linq;



namespace nyp.Controllers
{
    public class PublicacionEnCategoria : IPublicacionUri
    {
        public DatosPublicacion DatosPublicacion { get; set; }
        public Uri Uri { get; set; }
    }
    [Authorize]
    public class HomeController : Controller
    {
        private INYPContext db;
        private IGestorDocumental cm;

        public HomeController(INYPContext context, IGestorDocumental cmservice)
        {
            db = context;
            cm = cmservice;
        }

        private HomeModel ObtenerCategorias(long? id)
        {
            var estadoABuscar = Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Activo);
            var root = db.ListaCategorias(id);
            var homeMenu = db.ListaCategorias(null);

            NYPSessionData datosSesion = NYPSession.Load(db);
            List<Restriccion> listRest = datosSesion.PublicacionesBloqueadas;

            var result = new HomeModel()
            {
                Categorias = root.Select(c => new CategoriasViewModel()
                {
                    id = c.Id,
                    Name = c.Nombre,
                    Children = c.Children.Select(ch => new CategoriasViewModel()
                    {
                        id = ch.Id,
                        Name = ch.Nombre
                    }).ToList()
                }).ToList()
            };

            if (!id.HasValue)
            {
                var docs = from p in db.Publicaciones.Include(t => t.Circular)
                           where p.Estado == estadoABuscar && (listRest.Find(x => x.PublicacionId == p.Id) == null)
                           select p;
                try
                {

                    if (docs != null)
                    {
                        result.Hoy.Titulo = "Documentos publicados hoy " + DateTime.Now.Date.ToString();
                        result.Hoy.Documentos = docs.Where(d => d.FechaPublicacion.Date == DateTime.Now).ToList();

                        result.UltimaSemana.Titulo = "Documentos publicados durante la última semana";
                        result.UltimaSemana.Documentos = docs.Where(d => d.FechaPublicacion.Date > DateTime.Today.AddDays(-7f)).ToList();

                        result.Ultimos30Dias.Titulo = "Documentos publicados durante los últimos 30 días";
                        result.Ultimos30Dias.Documentos = docs.Where(d => d.FechaPublicacion.Date > DateTime.Today.AddDays(-30f)).ToList();
                    }
                    else {
                        result.Hoy.Titulo = "Documentos publicados hoy " + DateTime.Now.Date.ToString();
                        result.Hoy.Documentos = null;

                        result.UltimaSemana.Titulo = "Documentos publicados durante la última semana";
                        result.UltimaSemana.Documentos = null;

                        result.Ultimos30Dias.Titulo = "Documentos publicados durante los últimos 30 días";
                        result.Ultimos30Dias.Documentos = null;

                    }
                }
                catch (Exception ex)
                {
                    result.Hoy.Titulo = "Documentos publicados hoy " + DateTime.Now.Date.ToString();
                    result.Hoy.Documentos = null;

                    result.UltimaSemana.Titulo = "Documentos publicados durante la última semana";
                    result.UltimaSemana.Documentos = null;

                    result.Ultimos30Dias.Titulo = "Documentos publicados durante los últimos 30 días";
                    result.Ultimos30Dias.Documentos = null;
                }


            }
            else
            {
                var pubIds = (from c in db.CategoriasEnPublicacion
                              where c.CategoriaId == id 
                              select c.PublicacionId).ToList();
                var pubs = from p in db.Publicaciones
                           .Include(t => t.Circular)
                           where p.Estado == estadoABuscar && pubIds.Contains(p.Id) //&& (listRest.Find(x => x.PublicacionId == p.Id) == null)
                           select p;
                result.Documentos.Documentos = pubs.Where(t => t.Estado == estadoABuscar).ToList();
            }

            if (id.HasValue)
            {
                result.Path = ObtenerPathCategoriaViewModel(id.Value);
            }

            if (result.Documentos != null)
            {
                foreach (var docs in result.Documentos.Documentos)
                {
                    if (docs.Circular != null)
                        docs.Circular.Objetivo = RemoveHtmlTags(docs.Circular.Objetivo);
                }
            }

            if (result.Hoy.Documentos != null)
            {
                foreach (var docs in result.Hoy.Documentos)
                {
                    if (docs.Circular != null)
                        docs.Circular.Objetivo = RemoveHtmlTags(docs.Circular.Objetivo);
                }
            }
            if (result.UltimaSemana.Documentos != null)
            {
                foreach (var docs in result.UltimaSemana.Documentos)
                {
                    if (docs.Circular != null)
                        docs.Circular.Objetivo = RemoveHtmlTags(docs.Circular.Objetivo);
                }
            }

            if (result.Ultimos30Dias.Documentos != null)
            {
                foreach (var docs in result.Ultimos30Dias.Documentos)
                {
                    if (docs.Circular != null)
                        docs.Circular.Objetivo = RemoveHtmlTags(docs.Circular.Objetivo);
                }
            }



            return result;
        }


        private string RemoveHtmlTags(string strHtml)
        {
            string strText = Regex.Replace(strHtml, "<(.|\n)*?>", String.Empty);
            strText = HttpUtility.HtmlDecode(strText);
            strText = Regex.Replace(strText, @"\s+", " ");
            return strText;
        }

        private List<CategoriasViewModel> ObtenerPathCategoriaViewModel(long id)
        {
            IList<Categoria> tmpColl = db.ObtenerPathCategoria(id);
            return (from el in tmpColl
                    select new CategoriasViewModel()
                    {
                        id = el.Id,
                        Name = el.Nombre
                    }).Reverse().ToList();
        }

        public IActionResult Index()
        {
            var model = ObtenerCategorias(null);
            PrepararEstadisticas();
            ViewBag.RutaServer = getRutaServer(); 
            return View(model);

        }

        public IActionResult Categoria(long id)
        {
            ViewBag.RutaServer = getRutaServer();
            return View(ObtenerCategorias(id));
        }

        public IActionResult Error()
        {
            ViewBag.RutaServer = getRutaServer();
            return View("~/Views/Shared/Error.cshtml");
        }

        public IActionResult Pagina(int id)
        {
            var pagina = (from p in db.PaginasContenidos.Include(p => p.Autor)
                          where p.Id == id
                          select p).FirstOrDefault();
            if (pagina == null)
            {
                return HttpNotFound();
            }
            ViewBag.MostrarMenuLateral = false;
            ViewBag.RutaServer = getRutaServer();
            return View(pagina);
        }

        public IActionResult PaginaPredeterminada(string id)
        {
            var pagina = (from p in db.Propiedades
                          where p.Id == id
                          select p).FirstOrDefault();
            if (pagina == null)
            {
                return HttpNotFound();
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("Pagina", new { id = pagina.Valor });
        }

        private void PrepararEstadisticas()
        {
            var fecha = DateTime.Today.AddMonths(-1);
            NYPSessionData datosSesion = NYPSession.Load(db);
            List<Restriccion> listRest = datosSesion.PublicacionesBloqueadas;
            string strFiltro = " (0) ";
            if (listRest != null)
            {
                if (listRest.Count() > 0)
                {
                    strFiltro = " ( ";
                    for (int i = 0; i < listRest.Count(); i++)
                    {
                        strFiltro += listRest[i].PublicacionId;

                        if (i < listRest.Count() - 1)
                        {
                            strFiltro += ", ";
                        }
                    }
                    strFiltro += ") ";
                }
            }
            

            string sql1 = @"
                select top 5
	                b.Id, 
	                b.GestorDocumentalId, 
	                b.NombreDocumento, 
	                b.NombreArchivo, 
	                count(*) as Cantidad
                from 
	                EstadisticaDocumento a
	                join Documento b on a.DocumentoId = b.Id
		            join Publicacion p on b.PublicacionId = p.Id
	            where   
		            p.Id not in " + strFiltro + @" AND a.Fecha > DATEADD (month, -1, GETDATE()) AND b.Vigente = 1
                group by
	                b.Id, b.GestorDocumentalId, b.NombreDocumento, b.NombreArchivo
                ";
            var documentos = db.Set<DocumentosMasVisitados>().FromSql(sql1).Select(t => t);


            sql1 = @"
                select top 5
	                b.Id, 
	                b.NombreDocumento, 
	                b.FechaPublicacion,
	                b.Codigo,
	                count(*) as Cantidad
                from 
	                EstadisticaPublicacion a
	                join Publicacion b on a.PublicacionId = b.Id
				where  b.Id not in " + strFiltro + @" AND a.Fecha > DATEADD (month, -1, GETDATE()) AND b.Estado = 'Activo'
                group by
	                b.Id, 
	                b.NombreDocumento, 
	                b.FechaPublicacion,
	                b.Codigo
				order by Cantidad desc
            ";
            var publicaciones = db.Set<PublicacionesMasVisitadas>().FromSql(sql1).Select(t => t);

            ViewBag.EstadisticasDocumentos = documentos;
            ViewBag.EstadisticasPublicaciones = publicaciones;
        }

        [AllowAnonymous]
        public IActionResult Test()
        {
            ViewBag.RutaServer = getRutaServer();
            return View();
        }

        public IActionResult TasasComisiones()
        {
            ViewBag.MostrarMenuLateral = false;
            var prefs = new Preferencias(db);
            HomeTasasComisionesViewModel model = new HomeTasasComisionesViewModel();
            model.CategoriaId = prefs.TasasID;
            CargarArbolTasasComisiones(ref model);
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        private void CargarArbolTasasComisiones(ref HomeTasasComisionesViewModel model)
        {
            long auxId = model.CategoriaId;
            var cat = (from c in db.Categorias where c.Id == auxId select c).FirstOrDefault();
            model.padre = new GrupoTasasCategorias();
            model.padre.raiz = cat;
            model.padre.CategoriaId = cat.Id;
            GrupoTasasCategorias aux = model.padre;
            model.padre.Categorias = CalcularArbol(ref aux, 1);

        }

        private List<GrupoTasasCategorias> CalcularArbol(ref GrupoTasasCategorias padre, int nivel)
        {
            List<GrupoTasasCategorias> resultado = null;
            long auxId = padre.CategoriaId; 
            var categorias = (from c in db.Categorias
                              where c.CategoriaId == auxId
                              select c).ToList();
            if (nivel == 3)
            {
                var pubs = (from cp in db.CategoriasEnPublicacion.Include(t => t.Publicacion)
                                       where cp.CategoriaId == auxId && cp.Publicacion.Estado == "Activo"
                                       select cp.Publicacion).ToList();
                if (pubs.Any())
                {
                    padre.Publicaciones = new List<EnlacePublicacion>();
                    foreach (var pub in pubs)
                    {
                        var enlacePublicacion = new EnlacePublicacion
                        {
                            PublicacionID = pub.Id,
                            Titulo = pub.NombreDocumento
                        };
                        padre.Publicaciones.Add(enlacePublicacion); 
                    }

                    foreach (var ep in padre.Publicaciones)
                    {
                        var codDocumento = (from d in db.DocumentosEnPublicaciones
                                            where d.PublicacionId == ep.PublicacionID
                                            select d.DocumentoId).FirstOrDefault();
                        ep.CodDocumento = codDocumento; 
                    }
                }

                padre.Enlaces = (from e in db.EnlacesCategorias
                               where e.CategoriaId == auxId
                               select e).ToList();                

            } else if (categorias.Any())
            {
                resultado = new List<GrupoTasasCategorias>();
                foreach (var cat in categorias)
                {
                    GrupoTasasCategorias gtc = new GrupoTasasCategorias();
                    GrupoTasasCategorias aux2; 
                    gtc.raiz = cat;
                    gtc.CategoriaId = cat.Id;
                    aux2 = gtc; 
                    gtc.Categorias = CalcularArbol(ref aux2, nivel + 1);
                    resultado.Add(gtc);
                }
            }

            return resultado; 
        }

        private String getRutaServer()
        {
            /*
            var prefs = new Preferencias(db);
            return prefs.RutaServer;
            */
            return ""; 
        }
    }
}
