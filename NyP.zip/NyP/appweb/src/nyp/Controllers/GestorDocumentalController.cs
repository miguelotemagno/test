﻿using Microsoft.AspNet.Hosting;
using Microsoft.AspNet.Mvc;
using nyp.DataModels;
using nyp.Models;
using nyp.GestorDocumental.Service;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json.Linq;
using nyp.Helpers;

namespace nyp.Controllers
{


    public class GestorDocumentalController : ControllerNYP
    {
        [FromServices]
        public IHostingEnvironment HostingEnvironment { get; set; }

        [FromServices]
        public IGestorDocumental GestorDocumental { get; set; }

        [FromServices]
        public INYPContext DbContext { get; set; }

        public ActionResult Doc(long id)
        {
            var doc = (from d in DbContext.Documentos
                       where d.Id == id
                       select d).FirstOrDefault();
            if (doc != null)
            {
                try
                {
                    var gDoc = GestorDocumental.GetDocumento(doc.GestorDocumentalId);

                    if (gDoc != null)
                    {
                        DbContext.EstadisticasDocumentos.Add(new EstadisticaDocumento
                        {
                            Documento = doc,
                            Fecha = DateTime.Now
                        });
                        DbContext.SaveChanges();
                        return File(gDoc.Contenidos, gDoc.MimeType, gDoc.Nombre);
                    }
                }
                catch (System.Net.Sockets.SocketException e)
                {
                    ViewBag.RutaServer = getRutaServer();
                    return RedirectToAction("Desconectado");
                }
            }
            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("Desconectado");
        }

        public IActionResult Index(PruebaEncodeViewModel model)
        {
            if (model == null)
                model = new PruebaEncodeViewModel();

            model.EncondeText = Base64Encode(model.TextoOriginal);
            model.DecodeText = Base64Decode(model.EncondeText);
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        public ActionResult Desconectado()
        {
            return View(); 
        }

        #region private


        public string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }






        private string GetPhysicalFilename(string fileName)
        {
            return Path.Combine(HostingEnvironment.WebRootPath, "tmp-upload-zone", fileName);
        }
        #endregion

        private String getRutaServer()
        {
            /*var prefs = new Preferencias(DbContext);
            return prefs.RutaServer;*/
            return ""; 
        }
    }
}
