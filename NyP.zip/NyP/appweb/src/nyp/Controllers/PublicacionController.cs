﻿using Microsoft.AspNet.Authorization;
using Microsoft.AspNet.Hosting;
using Microsoft.AspNet.Http;
using Microsoft.AspNet.Mvc;
using Microsoft.Data.Entity;
using Microsoft.Data.Entity.Internal;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using nyp.DataModels;
using nyp.Extensions;
using nyp.Filters;
using nyp.GestorDocumental.Service;
using nyp.Helpers;
using nyp.Models;
using nyp.Services;
using nyp.Session;
using PagedList;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Text.RegularExpressions;

namespace nyp.Controllers
{
    [Authorize]
    public class PublicacionController : ControllerConNotificacion
    {
        public PublicacionController(
            INYPContext context,
            IEmailSender mailSenderService,
            ISessionService sessionContext,
            IGestorDocumental gestorDocumental,
            IHostingEnvironment env)
            : base(mailSenderService, context, gestorDocumental, env, sessionContext)
        {

        }

        #region acciones 

        public IActionResult Index(int? page)
        {
            var estadoABuscar = Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Activo);
            var q = from p in dbContext.Publicaciones
                    where p.Estado == estadoABuscar
                    select p;
            var pageNumber = page ?? 1;
            var unaPagina = q.ToPagedList(pageNumber, 25);
            ViewBag.RutaServer = getRutaServer();
            return View(unaPagina);
        }

        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult Editar(long id)
        {
            var estados = new string[] {
                Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Activo),
                Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Borrador)
            };
            var publicacion = GetPublicacion(id);
            if (publicacion == null)
            {
                return HttpNotFound();
            }

            var model = EditarPublicacionViewModelDesdePublicacion(publicacion);
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        [Authorize(Roles = "AnalistaNYP")]
        [HttpPost]
        public IActionResult Editar([Bind("Id,Categorias")]EditarPublicacionViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Obtener publicación para verificar su estado
                var publicacion = (from p in dbContext.Publicaciones
                                   where p.Id == model.Id
                                   select p).FirstOrDefault();
                if (publicacion != null)
                {
                    // Si es borrador estamos OK
                    if (publicacion.Estado == Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Borrador)
                        || publicacion.Estado == Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Activo))
                    {
                        // grabar todo menos archivos

                        if (model.Categorias.Any())
                        {
                            var categoriasExistentes = (from cp in dbContext.CategoriasEnPublicacion
                                                        where cp.PublicacionId == publicacion.Id
                                                        select cp.CategoriaId).ToList();

                            // borrar todo lo que no esté 
                            var itemsToDelete = (categoriasExistentes.Select(t => new CategoriasEnPublicacion()
                            {
                                CategoriaId = t,
                                PublicacionId = publicacion.Id
                            }).Where(item => !model.Categorias.Contains(item.CategoriaId))).ToArray();

                            // agregar los que no están
                            var itemsToInsert = (model.Categorias.Select(t => new CategoriasEnPublicacion()
                            {
                                CategoriaId = t,
                                PublicacionId = publicacion.Id
                            }).Where(item => !categoriasExistentes.Contains(item.CategoriaId))).ToArray();

                            // agregar
                            dbContext.CategoriasEnPublicacion.AddRange(itemsToInsert);
                            dbContext.CategoriasEnPublicacion.RemoveRange(itemsToDelete);
                            dbContext.SaveChanges();
                            ViewBag.RutaServer = getRutaServer();
                            return Ver(publicacion.Id);
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("Estado", string.Format("Una publicación en estado '{0}' no puede ser modificada",
                            publicacion.Estado));
                    }
                }
                return HttpBadRequest();
            }
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        public IActionResult Ver(long id)
        {
            var publicacion = GetPublicacion(id);
            if (publicacion == null)
            {
                return RedirectToAction("PublicacionNoExiste");
            }

            NYPSessionData datosSesion = NYPSession.Load(dbContext);
            datosSesion.PublicacionesBloqueadas = IntranetAuthController.CalcularBloqueos(datosSesion.RUT);
            List<Restriccion> listRest = datosSesion.PublicacionesBloqueadas;

            bool flat = false;

            if (listRest != null)
            {
                foreach (Restriccion restB in listRest)
                {
                    if (restB.PublicacionId == id) flat = true;
                }

                if (flat)
                {
                    //return RedirectToAction("AccesoDenagado"); 
                    ViewBag.RutaServer = getRutaServer();
                    return View("AccesoDenegado");
                }
            }

            var catIds = (from cp in dbContext.CategoriasEnPublicacion
                          where cp.PublicacionId == id
                          join cat in dbContext.Categorias on cp.CategoriaId equals cat.Id
                          select cat.Id).ToList();

            var categoriasViewModel = new List<List<CategoriasViewModel>>();
            foreach (var catId in catIds)
            {
                categoriasViewModel.Add(ObtenerPathCategoriaViewModel(catId));
            }

            var viewModel = new PublicacionViewModel()
            {
                Id = publicacion.Id,
                Destino = publicacion.AreasImpactadas,
                Fecha = publicacion.FechaPublicacion,
                FechaCertiicacion = publicacion.FechaCertificacion,
                Nombre = publicacion.NombreDocumento,
                Codigo = publicacion.Codigo,
                Categorias = categoriasViewModel,
                Estado = publicacion.Estado,
                Tipo = publicacion.Tipo,
                NumeroCircular = publicacion.Circular != null ? publicacion.Circular.Id : 0,
                Objetivo = publicacion.Circular != null ? publicacion.Circular.Objetivo : "Por asignar",
                Motivo = publicacion.Motivo,
                NivelAcceso = publicacion.NivelAcceso,
                SolicitudId = publicacion.SolicitudId
            };


            if (publicacion.Estado == Valores.EstadoPublicacion.Borrador.ToString())
            {
                // Archivos
                viewModel.Archivos = (from a in dbContext.ArchivosEnSolicitud
                                      join f in dbContext.Archivos on a.ArchivoId equals f.Id
                                      where a.SolicitudId == publicacion.SolicitudId
                                      select new ArchivoViewModel()
                                      {
                                          Id = a.ArchivoId,
                                          Descripcion = f.TituloDocumento,
                                          NombreFisico = f.NombreFisico,
                                          NombreOriginal = f.NombreArchivoOriginal
                                      }).ToList();

            }
            else
            {
                viewModel.Documentos = from a in dbContext.DocumentosEnPublicaciones
                                       join b in dbContext.Documentos on a.DocumentoId equals b.Id
                                       where a.PublicacionId == id
                                       select new DocumentoViewModel()
                                       {
                                           Id = b.Id,
                                           GestorDocumentalId = b.GestorDocumentalId,
                                           Filename = b.NombreArchivo,
                                           Titulo = b.NombreDocumento,
                                           Visible = b.Vigente,
                                           Version = b.Version,
                                           Referencia = a.Referencia
                                       };
            }

            if (publicacion.Estado == Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Activo))
            {
                dbContext.EstadisticasPublicaciones.Add(new EstadisticaPublicacion
                {
                    Fecha = DateTime.Now,
                    Publicacion = publicacion
                });
                dbContext.SaveChangesAsync();
            }

            ViewBag.RutaServer = getRutaServer();
            return View("Ver", viewModel);
        }
        public IActionResult PublicacionNoExiste()
        {
            ViewBag.RutaServer = getRutaServer();
            return View();
        }


        public IActionResult Descartar(long id)
        {
            var publicacion = (from p in dbContext.Publicaciones
                               where p.Id == id
                               select p).FirstOrDefault();

            if (publicacion != null)
            {
                if (publicacion.Estado == Valores.EstadoPublicacion.Borrador.ToString())
                {
                    var resticciones = from r in dbContext.Restricciones
                                       where r.PublicacionId == publicacion.Id
                                       select r;
                    foreach (var res in resticciones)
                    {
                        res.PublicacionId = null;
                    }
                    var solicitud = (from s in dbContext.Solicitudes
                                     where s.Id == publicacion.SolicitudId
                                     select s).FirstOrDefault();
                    solicitud.Estado = Valores.EstadoSolicitud.OK.ToString();


                    //var docsPublicacion = from dp in dbContext.DocumentosEnPublicaciones.Include(t => t.Documento)
                    //                      where dp.PublicacionId == publicacion.Id
                    //                      select dp;

                    //foreach (var doc in docsPublicacion)
                    //{
                    //    dbContext.Database.ExecuteSqlCommand("DELETE FROM EventoDocumento WHERE DocumentoId = " + doc.DocumentoId);
                    //    dbContext.Documentos.Remove(doc.Documento);
                    //}

                    //dbContext.DocumentosEnPublicaciones.RemoveRange(docsPublicacion);
                    dbContext.Publicaciones.Remove(publicacion);

                    dbContext.SaveChanges();
                    ViewBag.RutaServer = getRutaServer();
                    return RedirectToAction("Ver", "Solicitud", new { id = solicitud.Id });
                }
                else
                {
                    ViewBag.error = 1;
                    ViewBag.RutaServer = getRutaServer();
                    return View();
                }
            }
            else
            {
                ViewBag.error = 2;
                ViewBag.RutaServer = getRutaServer();
                return View();
            }
        }


        public IActionResult Buscar([Bind("Terminos,Area,Tipo,TargetTipo,TargetTerminos,buscarContenido")]BusquedaViewModel model)
        {
            if (model != null)
            {


                var estadoABuscar = Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Activo);

                NYPSessionData datosSesion = NYPSession.Load(dbContext);
                List<Restriccion> listRest = datosSesion.PublicacionesBloqueadas;



                var busqueda = from p in dbContext.Publicaciones
                                .Include(t => t.Circular)
                               where p.Estado == estadoABuscar && (listRest.Find(x => x.PublicacionId == p.Id) == null)
                               select p;
                int categoriaId;
                var bajoCategoria = new List<Publicacion>();
                if (int.TryParse(model.Area, out categoriaId))
                {
                    // Categorias
                    // Al obtener todas las categorias se llenan inmediatamente todos los hijos
                    // Al borrar categorias de la lista los hijos se mantienen
                    var allCategories = (from c in dbContext.Categorias
                                         select c).ToList();
                    allCategories.RemoveAll(t => t.Id != categoriaId);
                    var categoria = allCategories.FirstOrDefault();
                    if (categoria != null)
                    {
                        var categorias = categoria.Descendants();
                        var ids = categorias.Select(t => t.Id).ToList();
                        if (categorias.Count() > 0)
                        {
                            var pubIds = (from d in dbContext.CategoriasEnPublicacion
                                          where ids.Contains(d.CategoriaId)
                                          select d.Publicacion.Id).ToList();
                            busqueda = from d in dbContext.Publicaciones
                                        .Include(c => c.Circular)
                                       where pubIds.Contains(d.Id) && (listRest.Find(x => x.PublicacionId == d.Id) == null)
                                       select d;
                            model.Listado.Glosa.Add(new Tuple<string, string>("Áreas", string.Join(", ", categorias.Select(t => t.Nombre).ToArray())));
                        }
                    }
                }

                if (model.Terminos != null)
                {
                    var punctuation = model.Terminos.Where(char.IsPunctuation).Distinct().ToArray();
                    var terms = model.Terminos.Split().Select(x => x.ToLower().Trim(punctuation));

                    if (terms.Any())
                    {
                        foreach (var t in terms)
                        {
                            busqueda = busqueda.Where(e => e.NombreDocumento.ToLower().Contains(t));
                        }
                        model.Listado.Glosa.Add(new Tuple<string, string>("Términos de búsqueda", terms.Join(", ")));
                    }
                }

                if (!string.IsNullOrEmpty(model.TargetTerminos))
                {

                    switch (model.TargetTipo)
                    {
                        case "Codigo":
                            busqueda = busqueda.Where(t => t.Codigo.ToLowerInvariant().Contains(model.TargetTerminos.ToLowerInvariant()));
                            model.Listado.Glosa.Add(new Tuple<string, string>("Código", model.TargetTerminos));
                            break;
                        case "Gerencia":
                            busqueda = busqueda.Where(t => t.Division.ToLowerInvariant().Contains(model.TargetTerminos.ToLowerInvariant()));
                            model.Listado.Glosa.Add(new Tuple<string, string>("Gerencia", model.TargetTerminos));
                            break;
                        case "Area":
                            busqueda = busqueda.Where(t => t.Area.ToLowerInvariant().Contains(model.TargetTerminos.ToLowerInvariant()));
                            model.Listado.Glosa.Add(new Tuple<string, string>("Área", model.TargetTerminos));
                            break;
                        case "Unidad":
                            busqueda = busqueda.Where(t => t.Unidad.ToLowerInvariant().Contains(model.TargetTerminos.ToLowerInvariant()));
                            model.Listado.Glosa.Add(new Tuple<string, string>("Unidad", model.TargetTerminos));
                            break;
                        case "Tipo":
                            busqueda = busqueda.Where(t => t.Solicitud.Tipo.ToLowerInvariant().Contains(model.TargetTerminos.ToLowerInvariant()));
                            model.Listado.Glosa.Add(new Tuple<string, string>("Tipo", model.TargetTerminos));
                            break;
                        case "Materia":
                            busqueda = busqueda.Where(t => t.Solicitud.Materia.ToLowerInvariant().Contains(model.TargetTerminos.ToLowerInvariant()));
                            model.Listado.Glosa.Add(new Tuple<string, string>("Materia", model.TargetTerminos));
                            break;
                        case "Circular":
                            int numeroCircular;
                            if (Int32.TryParse(model.TargetTerminos, out numeroCircular))
                            {
                                busqueda = busqueda.Where(t => t.Circular.Id.Equals(numeroCircular));
                                model.Listado.Glosa.Add(new Tuple<string, string>("Número de Circular", numeroCircular.ToString()));
                            }
                            break;
                        default:
                            break;
                    }
                }
                if (model.buscarContenido)
                {
                    var publicacionesContextual = GestorDocumental.Search(0, model.TargetTerminos);
                    if (publicacionesContextual != null) 
                        foreach(var test in publicacionesContextual)
                        {

                        }

                }
                

                busqueda = busqueda.Where(e => e.Estado == estadoABuscar);
                model.Listado.Titulo = "Resultados de búsqueda";
                if (busqueda != null)
                {
                    foreach (var docs in busqueda)
                    {
                        if (docs.Circular != null)
                            docs.Circular.Objetivo = RemoveHtmlTags(docs.Circular.Objetivo);
                    }
                }
                model.Listado.Documentos = busqueda.ToList();
            }
            else
            {
                model.Listado.Titulo = "No se ha realizado ninguna búsqueda";

            }
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        private string RemoveHtmlTags(string strHtml)
        {
            string strText = Regex.Replace(strHtml, "<(.|\n)*?>", String.Empty);
            strText = HttpUtility.HtmlDecode(strText);
            strText = Regex.Replace(strText, @"\s+", " ");
            return strText;
        }

        [FromServices]
        public IGestorDocumental GestorDocumental { get; set; }

        public IActionResult VerCircular(long id)
        {
            var pub = GetPublicacion(id);
            if (pub != null && pub.Circular != null)
            {
                ViewBag.RutaServer = getRutaServer();
                return View(pub.Circular);
            }
            return HttpNotFound();
        }

        public IActionResult VerCircularWord(long id)
        {
            var pub = GetPublicacion(id);
            if (pub != null && pub.Circular != null)
            {
                var filename = string.Format(@"Circular-{0}.docx", pub.Circular.Id);
                var wu = new WordUtils(hostingEnvironment, Url);
                var ms = wu.GetCircularWord(pub);
                ViewBag.RutaServer = getRutaServer();
                return File(ms, "application/vnd.openxmlformats-officedocument.wordprocessingml.document", filename);
            }
            return HttpNotFound();
        }

        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult Publicar(long id)
        {
            var publicacion = GetPublicacion(id);
            if (publicacion == null || publicacion.Estado != Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Borrador))
            {
                return HttpBadRequest();
            }
            ViewBag.Publicacion = publicacion;
            ViewBag.ListasDistribucion = from l in dbContext.ListasDistribucion select l;
            ViewBag.RutaServer = getRutaServer();

            ICollection<string> usuariosNotificados = new List<string>();
            if (publicacion.Solicitud.UsuariosNotificados != null)
            {
                usuariosNotificados = publicacion.Solicitud.UsuariosNotificados.Select(x => x.Email).ToList();
            }

            return View(new PublicarBorradorViewModel { Id = publicacion.Id, UsuariosNotificadosEmails = usuariosNotificados });
        }

        private string msjError;

        [HttpPost]
        public async Task<IActionResult> Publicar(PublicarBorradorViewModel model)
        {
            var publicacion = GetPublicacion(model.Id);
            if (publicacion == null)
            {
                return HttpBadRequest();
            }
            if (ModelState.IsValid)
            {
                if (publicacion == null || publicacion.Estado != Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Borrador))
                {
                    return HttpBadRequest();
                }


                // el movimiento de los archivos se ejecuta aqui. 

                var solicitud = (from s in dbContext.Solicitudes
                                 where s.Id == publicacion.SolicitudId
                                 select s).FirstOrDefault();


                // obtener los archivos
                var files = (from nav in dbContext.ArchivosEnSolicitud
                             join f in dbContext.Archivos on nav.ArchivoId equals f.Id
                             where nav.SolicitudId == solicitud.Id
                             select f).ToList();

                //subir los archivos al content
                foreach (var f in files)
                {
                    //Trasnformar el archivo a Base64
                    Byte[] bytes = System.IO.File.ReadAllBytes(GetPhysicalFilename(f.NombreFisico));
                    String file = Convert.ToBase64String(bytes);
                    String contenidoBase64 = "";
                    //Insertar saltos de linea. 
                    for (int i = 0; i < file.Length; i = i + 76)
                    {
                        if (i + 76 < file.Length)
                            contenidoBase64 += file.Substring(i, 76) + "\n";
                        else
                            contenidoBase64 += file.Substring(i, file.Length - i);
                    }

                    var res = documentManager.Almacenar(new DatosPublicacion()
                    {
                        Id = f.Id,
                        Tipo = f.Tipo,
                        NombreFisico = f.NombreArchivoOriginal,
                        Descripcion = f.TituloDocumento,
                        CodigoDocumento = f.CodigoDocumento,
                        Fecha = publicacion.FechaPublicacion
                    }, f.NombreFisico, contenidoBase64);


                    if (!res.Ok)
                    {
                        if (res != null)
                            msjError = res.Mensaje;
                        else
                            msjError = "";
                        ViewBag.RutaServer = getRutaServer();
                        return RedirectToAction("ProblemaPublicar", new { Id = 1 });
                    }
                }


                foreach (var f in files)
                {

                    // Primero ver si existe
                    var documento = (from d in dbContext.Documentos.Include(t => t.Publicacion).Include(t => t.Historial)
                                     where d.NombreArchivo == f.NombreArchivoOriginal && d.Vigente == true
                                     select d).FirstOrDefault();
                    Documento documentoNuevo;

                    //Segundo verificar si existe pero ya esta oculto. calcular la maxima version. 
                    if (documento == null)
                    {
                        documento = (from d in dbContext.Documentos.Include(t => t.Publicacion).Include(t => t.Historial)
                                     where d.NombreArchivo == f.NombreArchivoOriginal
                                     orderby d.Version descending
                                     select d).FirstOrDefault();
                    }


                    if (documento != null)
                    {

                        documento.Vigente = false;
                        documento.Historial.Add(new EventoDocumento
                        {
                            Autor = Usuario,
                            Descripcion = "Versión Actualizada: " + documento.Version + 1,
                            Fecha = DateTime.Now,
                        });

                        dbContext.Documentos.Attach(documento);
                        var entry = dbContext.Entry(documento);
                        entry.State = EntityState.Modified;

                        documentoNuevo = new Documento()
                        {
                            NombreDocumento = f.TituloDocumento,
                            Publicacion = publicacion,
                            FechaPublicacion = publicacion.FechaPublicacion,
                            FechaCertificacion = publicacion.FechaPublicacion,
                            NombreArchivo = Path.GetFileName(f.NombreArchivoOriginal),
                            GestorDocumentalId = f.NombreFisico,
                            Vigente = true,
                            Version = documento.Version + 1,
                            Historial = new List<EventoDocumento>() {
                                new EventoDocumento {
                                    Autor = Usuario,
                                    Descripcion = "Upload",
                                    Fecha = DateTime.Now
                                }
                            }
                        };
                    }
                    else
                    {
                        documentoNuevo = new Documento()
                        {
                            NombreDocumento = f.TituloDocumento,
                            Publicacion = publicacion,
                            FechaPublicacion = publicacion.FechaPublicacion,
                            FechaCertificacion = publicacion.FechaPublicacion,
                            NombreArchivo = Path.GetFileName(f.NombreArchivoOriginal),
                            GestorDocumentalId = f.NombreFisico,
                            Vigente = true,
                            Version = 0,
                            Historial = new List<EventoDocumento>() {
                                new EventoDocumento {
                                    Autor = Usuario,
                                    Descripcion = "Upload",
                                    Fecha = DateTime.Now
                                }
                            }
                        };
                    }
                    dbContext.Documentos.Add(documentoNuevo);
                    dbContext.SaveChanges();

                    dbContext.DocumentosEnPublicaciones.Add(new DocumentosEnPublicacion()
                    {
                        DocumentoId = documentoNuevo.Id,
                        PublicacionId = publicacion.Id
                    });
                    dbContext.SaveChanges();

                    if (documento != null)
                    {
                        ActualizarReferenciasEstatisticas(documento, documentoNuevo);
                    }

                }
                var referencias = from d in dbContext.DocumentosExistentesEnSolicitud.Include(t => t.Documento)
                                  where d.SolicitudId == solicitud.Id
                                  select new DocumentosEnPublicacion
                                  {
                                      DocumentoId = d.DocumentoId,
                                      PublicacionId = publicacion.Id,
                                      Referencia = true
                                  };

                dbContext.DocumentosEnPublicaciones.AddRange(referencias);
                AgregarCambio(solicitud, "Publicación", null, string.Format("Nueva publicación: {0}", publicacion.Id));
                dbContext.SaveChanges();


                //Actualizar las restricciones.
                var restricciones = (from rest in dbContext.Restricciones
                                     where rest.SolicitudId == solicitud.Id
                                     select rest);
                foreach (Restriccion restriccion in restricciones)
                {
                    restriccion.PublicacionId = publicacion.Id;
                    dbContext.Restricciones.Attach(restriccion);
                    dbContext.Entry(restriccion).State = EntityState.Modified;
                }
                dbContext.SaveChanges();
                //Fin de actualizar restricciones. 


                publicacion.Estado = Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Activo);

                if (publicacion.Solicitud != null)
                {
                    AgregarCambio(publicacion.Solicitud, null, "Borrador", "Publicada");
                }
                publicacion.Solicitud.Estado = Valores.EstadoSolicitud.Publicado.ToString();
                dbContext.Solicitudes.Attach(publicacion.Solicitud);
                dbContext.Entry(publicacion.Solicitud).State = EntityState.Modified;
                dbContext.SaveChanges();

                var usuariosNotificados = model.UsuariosNotificadosEmails;

                await NotificarNuevaPublicacion(publicacion, model.ListaDistribucionId, usuariosNotificados.ToList());

                ConfirmacionVisual("Publicación Exitosa", string.Format("La publicación '{0}' ha sido publicada exitosamente.", publicacion.NombreDocumento));
                ViewBag.RutaServer = getRutaServer();
                return RedirectToAction("Ver", new { id = publicacion.Id });
            }
            ViewBag.Publicacion = publicacion;
            ViewBag.ListasDistribucion = from l in dbContext.ListasDistribucion
                                         select l;
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult SuspenderPublicacion(long id)
        {
            var publicacion = GetPublicacion(id);
            if (publicacion == null)
            {
                return HttpBadRequest();
            }
            ViewBag.TituloPublicacion = publicacion.NombreDocumento;
            ViewBag.FechaPublicacion = publicacion.FechaPublicacion;
            ViewBag.RutaServer = getRutaServer();
            return View(new SuspenderPublicacionViewModel { PublicacionId = publicacion.Id });
        }

        [HttpPost]
        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult SuspenderPublicacion(SuspenderPublicacionViewModel model)
        {
            if (ModelState.IsValid)
            {
                var publicacion = GetPublicacion(model.PublicacionId);
                publicacion.Estado = Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Inactivo);
                publicacion.FinVigencia = DateTime.Now;
                publicacion.Motivo = model.Motivo;

                dbContext.Entry(publicacion).State = EntityState.Modified;
                dbContext.SaveChanges();

                //Eliminar las estadisticas. confirmar con Giovanni. 


                ConfirmacionVisual("Publicación Suspendida", "La publicación ha sido suspendida.");
                ViewBag.RutaServer = getRutaServer();
                return RedirectToAction("Ver", new { id = publicacion.Id });
            }
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        public IActionResult Reactivar(long id)
        {

            var publicacion = (from p in dbContext.Publicaciones
                               where p.Id == id
                               select p).FirstOrDefault();
            if (publicacion != null)
            {
                var documentos = from d in dbContext.DocumentosEnPublicaciones.Include(t => t.Documento)
                                 where d.Referencia == false && d.Documento.Vigente == true && d.PublicacionId == publicacion.Id
                                 select d;
                if (documentos.Any())
                {
                    publicacion.Estado = Valores.EstadoPublicacion.Activo.ToString();
                    dbContext.SaveChanges();
                    ViewBag.RutaServer = getRutaServer();
                    return RedirectToAction("Ver", new { id = id });
                }
                else
                {
                    ViewBag.error = 2;
                    ViewBag.RutaServer = getRutaServer();
                    return View();
                }
            }
            ViewBag.error = 1;
            ViewBag.RutaServer = getRutaServer();
            return View();

        }

        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult SuspenderDocumento(long publicacionId, long documentoId)
        {
            var doc = dbContext.Documentos.FirstOrDefault(t => t.Id == documentoId);
            if (doc == null)
            {
                return HttpBadRequest();
            }
            ViewBag.Documento = doc;
            var model = new SuspenderDocumentoViewModel
            {
                PublicacionId = publicacionId,
                DocumentoId = documentoId
            };
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        [HttpPost]
        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult SuspenderDocumento(SuspenderDocumentoViewModel model)
        {
            if (model == null)
            {
                return HttpBadRequest();
            }
            var doc = dbContext.Documentos
                    .Include(t => t.Historial)
                    .FirstOrDefault(t => t.Id == model.DocumentoId);
            if (doc == null)
            {
                return HttpBadRequest();
            }
            ViewBag.Documento = doc;
            if (ModelState.IsValid)
            {
                var user = dbContext.UsuariosIntranet.FirstOrDefault(u => u.Id == Usuario.Id);
                doc.Vigente = false;
                doc.Historial.Add(new EventoDocumento { Autor = user, Descripcion = "Documento suspendido: " + model.Motivo, Fecha = DateTime.Now });
                dbContext.SaveChanges();
                ConfirmacionVisual("Documento Suspendido", "El documento " + doc.NombreArchivo + " ya no es visible en la publicación.");
                ViewBag.RutaServer = getRutaServer();
                return RedirectToAction("Ver", new { id = model.PublicacionId });
            }
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult ActivarDocumento(long publicacionId, long documentoId)
        {
            var doc = dbContext.Documentos.FirstOrDefault(t => t.Id == documentoId);
            if (doc == null)
            {
                return HttpBadRequest();
            }
            ViewBag.Documento = doc;
            var model = new SuspenderDocumentoViewModel
            {
                PublicacionId = publicacionId,
                DocumentoId = documentoId
            };
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }


        public ActionResult ProblemaPublicar(long Id)
        {
            if (Id == 1)
            {
                msjError = "No se pudo establecer una conexión con el servidor de archivos. ";
            }
            ViewBag.Mensaje = msjError;
            ViewBag.RutaServer = getRutaServer();
            return View();
        }


        [HttpPost]
        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult ActivarDocumento(SuspenderDocumentoViewModel model)
        {
            if (model == null)
            {
                return HttpBadRequest();
            }
            var doc = dbContext.Documentos
                    .Include(t => t.Historial)
                    .FirstOrDefault(t => t.Id == model.DocumentoId);
            if (doc == null)
            {
                return HttpBadRequest();
            }
            ViewBag.Documento = doc;
            if (ModelState.IsValid)
            {
                var user = dbContext.UsuariosIntranet.FirstOrDefault(u => u.Id == Usuario.Id);
                doc.Vigente = true;
                doc.Historial.Add(new EventoDocumento { Autor = user, Descripcion = "Documento visible: " + model.Motivo, Fecha = DateTime.Now });
                dbContext.SaveChanges();
                ConfirmacionVisual("Documento Reactivado", "El documento " + doc.NombreArchivo + " es nuevamente visible en todas las publicaciones.");
                ViewBag.RutaServer = getRutaServer();
                return RedirectToAction("Ver", new { id = model.PublicacionId });
            }
            ViewBag.RutaServer = getRutaServer();
            return View(model);
        }

        public string GetNombreDocumento(string CodigoDocumento)
        {
            string NombreDocumento = "* Documento no encontrado, Especifique: 'código + nombre del documento' en el campo anterior.";
            var codigoGlosa = (from cg in dbContext.CodigosGlosa
                               where cg.CodigoDocumento == CodigoDocumento
                               select cg).FirstOrDefault();
            if (codigoGlosa != null)
            {
                NombreDocumento = codigoGlosa.NombreDocumento;
            }

            return NombreDocumento;
        }

        [Produces("application/json")]
        public Autocomplete Codigos(string query)
        {
            if (string.IsNullOrEmpty(query))
            {
                return null;
            }
            var sql = string.Format("select distinct(CodigoDocumento) as Codigo from CodigoGlosa where "
                + "upper(substring(CodigoDocumento, 1, {0})) = upper(@p0) and Vigente = 1 order by 1 desc",
                query.Length);
            var suggestions = new List<AutocompleteSuggestion>();
            using (var con = dbContext.Database.GetDbConnection())
            {
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Parameters.Add(new SqlParameter("p0", query.ToUpper()));
                    con.Open();
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var codigo = reader.GetString(reader.GetOrdinal("Codigo"));
                            suggestions.Add(new AutocompleteSuggestion { value = codigo, data = codigo });
                        }
                    }
                }
            }
            return new Autocomplete
            {
                suggestions = suggestions.ToArray()
            };
        }

        [Produces("application/json")]
        public Autocomplete TiposDeDocumento(string query)
        {
            if (string.IsNullOrEmpty(query))
            {
                return null;
            }
            var sql = string.Format("select distinct(Tipo) as Tipo from Publicacion where Tipo like '{0}%' order by Tipo", query);
            var suggestions = new List<AutocompleteSuggestion>();
            using (var con = dbContext.Database.GetDbConnection())
            {
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandText = sql;
                    con.Open();
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var tipo = reader.GetString(reader.GetOrdinal("Tipo"));
                            suggestions.Add(new AutocompleteSuggestion { value = tipo, data = tipo });
                        }
                    }
                }
            }
            return new Autocomplete
            {
                suggestions = suggestions.ToArray()
            };
        }

        [Produces("application/json")]
        public Autocomplete DocumentosExistentes(string query)
        {
            if (string.IsNullOrEmpty(query))
            {
                return null;
            }
            var sql = @"
                select 
                    a.Id, b.PublicacionId, c.Codigo, c.Estado,
                    c.NombreDocumento, c.Tipo, a.NombreArchivo
                from 
                    Documento a 
                    join DocumentosEnPublicacion b on a.id = b.DocumentoId 
                    join Publicacion c on c.Id = b.PublicacionId 
                where 
                    Estado = 'Activo' 
                    and a.Vigente = 1
                    and (UPPER(c.Codigo) = @p0 
                    or UPPER(a.NombreDocumento) like @p1
                    or UPPER(c.NombreDocumento) like @p1
                    or UPPER(a.NombreArchivo) like @p1)
            ";
            var suggestions = new List<AutocompleteSuggestion>();
            using (var con = dbContext.Database.GetDbConnection())
            {
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandText = sql;
                    var p0 = new SqlParameter("p0", query.ToUpper());
                    var p1 = new SqlParameter("p1", System.Data.SqlDbType.NVarChar);
                    p1.Value = "%" + query.ToUpper() + "%";
                    cmd.Parameters.Add(p0);
                    cmd.Parameters.Add(p1);
                    con.Open();
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var id = reader.GetInt64(reader.GetOrdinal("Id"));
                            var publicacionID = reader.GetInt64(reader.GetOrdinal("PublicacionId"));
                            var nombreArchivo = reader.GetString(reader.GetOrdinal("NombreArchivo"));
                            var nombreDocumento = reader.GetString(reader.GetOrdinal("NombreDocumento"));

                            var label = string.Format("{1} ({2})",
                                id, nombreDocumento, nombreArchivo);

                            suggestions.Add(new AutocompleteSuggestion { value = label, data = id.ToString() });
                        }
                    }
                }
            }
            return new Autocomplete
            {
                suggestions = suggestions.ToArray()
            };

        }

        #endregion acciones


        #region Proceso de Certificacion 


        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult DetallesCertificacion(long Id)
        {
            CertificacionViewModel DatosCP = CertifiacionViewModelFromId(Id);
            ViewBag.MostrarMenuLateral = false;
            ViewBag.RutaServer = getRutaServer();
            return View(DatosCP);
        }

        private CertificacionViewModel CertifiacionViewModelFromId(long Id)
        {

            Publicacion publicacion = (from p in dbContext.Publicaciones
                                       .Include(t => t.Responsable)
                                       .Include(t => t.Solicitud)
                                       where p.Id == Id
                                       select p).FirstOrDefault();


            UsuarioIntranet analista = (from s in dbContext.Solicitudes
                                        join u in dbContext.UsuariosIntranet
                                        on s.Analista equals u
                                        where s.Id == publicacion.SolicitudId
                                        select u).FirstOrDefault();

            ProcesoCertificacion certifiacionAnterior = (from pc in dbContext.Certificaciones
                                                         .Include(t => t.AnalistaEjecutor)
                                                         where pc.PublicacionId == Id
                                                         select pc).FirstOrDefault();


            CertificacionViewModel DatosCP = new CertificacionViewModel();


            DatosCP.Documentos = from a in dbContext.DocumentosEnPublicaciones
                                 join b in dbContext.Documentos on a.DocumentoId equals b.Id
                                 where a.PublicacionId == Id && b.Vigente == true && a.Referencia == false
                                 select new DocumentoViewModel()
                                 {
                                     Id = b.Id,
                                     GestorDocumentalId = b.GestorDocumentalId,
                                     Filename = b.NombreArchivo,
                                     Titulo = b.NombreDocumento,
                                     Visible = b.Vigente,
                                     Version = b.Version,
                                     Certificado = b.ProcesoCertificacionId != null ? true : false,
                                     Referencia = a.Referencia
                                 };

            DatosCP.PublicacionId = Id;
            DatosCP.AnalistaId = analista.Id;
            DatosCP.Analista = analista.NombreCompleto();


            DatosCP.ResponsableNuevoId = publicacion.Responsable.Id;
            DatosCP.ResponsableNuevo = publicacion.Responsable.NombreCompleto();

            DatosCP.UnidadNueva = publicacion.Unidad;
            DatosCP.UbicacionNueva = publicacion.Division + " → " + publicacion.Area + " → " + publicacion.Unidad;
            DatosCP.NombrePublicacion = publicacion.Solicitud.Titulo;
            DatosCP.FechaCertificacion = publicacion.FechaCertificacion;

            DatosCP.Codigo = publicacion.Codigo;
            DatosCP.NombreDocumento = publicacion.NombreDocumento;
            DatosCP.Tipo = publicacion.Tipo;

            if (certifiacionAnterior != null)
            {
                DatosCP.AnalistaEjecutor = certifiacionAnterior.AnalistaEjecutor.NombreCompleto();
                DatosCP.FechaProceso = certifiacionAnterior.FechaProceso;
                DatosCP.CambioResposable = certifiacionAnterior.ResponsableAnteriorId != certifiacionAnterior.ResponsableNuevoId;
                DatosCP.CambioUnidad = publicacion.Unidad != certifiacionAnterior.UnidadAnterior;
            }


            return DatosCP;
        }


        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult Certificar(long Id)
        {
            CertificacionViewModel cmv = CertifiacionViewModelFromId(Id);
            ViewBag.OrganicaInicial = JsonConvert.SerializeObject(dbContext.OrganicaInicial("0"));
            ViewBag.MostrarMenuLateral = false;
            ViewBag.RutaServer = getRutaServer();
            return View(cmv);
        }

        [Authorize(Roles = "AnalistaNYP")]
        public IActionResult RegistrarCertificacion(CertificacionViewModel model, ICollection<IFormFile> files)
        {
            NYPSessionData datosSesion = NYPSession.Load(dbContext);


            CertificacionViewModel certAnterior = CertifiacionViewModelFromId(model.PublicacionId);

            ProcesoCertificacion certificacion = (from pc in dbContext.Certificaciones
                                                      .Include(t => t.Publicacion)
                                                      .Include(t => t.AnalistaEjecutor)
                                                  where pc.Publicacion.Id == model.PublicacionId
                                                  select pc).FirstOrDefault();
            bool update = true;
            if (certificacion == null)
            {
                certificacion = new ProcesoCertificacion();
                update = false;
                certificacion.PublicacionId = model.PublicacionId;
            }
            certificacion.ResponsableAnteriorId = certAnterior.ResponsableNuevoId;
            // Registro de la certificacion..
            if (model.ResponsableNuevoId != 0)
                certificacion.ResponsableNuevoId = model.ResponsableNuevoId;
            else
                certificacion.ResponsableNuevoId = certAnterior.ResponsableNuevoId;

            certificacion.UnidadAnterior = (certAnterior.UbicacionNueva.Split('→')[2]).Trim();
            certificacion.AreaAnterior = (certAnterior.UbicacionNueva.Split('→')[1]).Trim();
            certificacion.GerenciaAnterior = (certAnterior.UbicacionNueva.Split('→')[0]).Trim();

            certificacion.AnalistaEjecutorId = datosSesion.RUT;

            certificacion.FechaProceso = DateTime.Now;
            certificacion.Comentarios = model.Comentarios;

            if (update)
            {
                dbContext.Certificaciones.Attach(certificacion);
                dbContext.Entry(certificacion).State = EntityState.Modified;
            }
            else
            {
                dbContext.Certificaciones.Add(certificacion);
            }

            dbContext.SaveChanges();

            // ACTUALIZACION DE LA PUBLICACION. 


            Publicacion publicacion = GetPublicacion(model.PublicacionId);
            //proceso para determinar si hay cambios de la unidad. 
            int auxUnidadId;
            if (int.TryParse(model.UnidadNuevaId.Substring(1), out auxUnidadId))
            {
                Unidad _nuevaUnidad = (from u in dbContext.Unidades
                                       where u.Id == auxUnidadId
                                       select u).FirstOrDefault();

                publicacion.Unidad = _nuevaUnidad.Nombre;

                Area _nuevaArea = (from a in dbContext.Areas
                                   where a.Id == _nuevaUnidad.AreaId
                                   select a).FirstOrDefault();
                publicacion.Area = _nuevaArea.Nombre;

                Gerencia _nuevaGerencia = (from g in dbContext.Gerencias
                                           where g.Id == _nuevaArea.GerenciaId
                                           select g).FirstOrDefault();

                publicacion.Division = _nuevaGerencia.Nombre;
            }

            if (model.ResponsableNuevoId != 0)
                publicacion.ResponsableId = model.ResponsableNuevoId;

            publicacion.FechaCertificacion = model.FechaCertificacion;

            dbContext.Publicaciones.Attach(publicacion);
            dbContext.Entry(publicacion).State = EntityState.Modified;
            dbContext.SaveChanges();

            var documentos = (from d in dbContext.Documentos
                  .Include(t => t.Publicacion)
                              where d.Publicacion.Id == model.PublicacionId
                              select d).ToList();


            //Guardar los archivos en Disco y en la tabla Documentos. 
            string msg;
            bool result;
            foreach (var f in files)
            {
                //Ubicar el archivo nuevo entre los archivos existentes. 
                result = ReemplazarDocumento(documentos, f, model.FechaCertificacion, out msg, false, certificacion.Id);
                if (!result)
                {
                    ModelState.AddModelError("ArchivoAdjunto", msg);
                    ViewBag.RutaServer = getRutaServer();
                    return View(model);
                }
            }

            ViewBag.RutaServer = getRutaServer();
            return RedirectToAction("DetallesCertificacion", new { Id = model.PublicacionId });
        }


        #endregion


        #region Bandeja

        [Authorize(Roles = "AnalistaNYP")]
        [ServiceFilter(typeof(OcultarMenuLateralFilter))]
        public IActionResult BandejaPublicacion(int? page)
        {
            var pageNumber = page ?? 1;
            var publicaciones = (from p in dbContext.Publicaciones.Include(t => t.Circular)
                                 where p.Estado == Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Activo)
                                 select p);//.ToPagedList(pageNumber, 8);
            var model = new BandejaPublicaciones()
            {
                Titulo = "Publicaciones activas",
                Action = "BandejaPublicacion",
                Controller = "Publicacion",
                Publicaciones = publicaciones
            };
            ViewBag.contadores = CalculoContadores();
            ViewBag.Preferencias = new nyp.Helpers.Preferencias(dbContext);
            ViewBag.RutaServer = getRutaServer();
            return View("Bandeja", model);
        }

        /*
        [Authorize(Roles = "AnalistaNYP")]
        [ServiceFilter(typeof(OcultarMenuLateralFilter))]
        public IActionResult BandejaBorradores(int? page)
        {
            var pageNumber = page ?? 1;
            var borradores = (from p in dbContext.Publicaciones
                              where p.Estado == Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Borrador)
                              select p);//.ToPagedList(pageNumber, 8);
            var model = new BandejaPublicaciones()
            {
                Titulo = "Borradores de Publicación",
                Action = "BandejaBorradores",
                Controller = "Publicacion",
                Publicaciones = borradores
            };

            return View("Bandeja", model);
        }
        */

        [Authorize(Roles = "AnalistaNYP")]
        [ServiceFilter(typeof(OcultarMenuLateralFilter))]
        public IActionResult BandejaInactivos(int? page)
        {
            var pageNumber = page ?? 1;
            var borradores = (from p in dbContext.Publicaciones.Include(t => t.Circular)
                              where p.Estado == Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Inactivo)
                              select p);//.ToPagedList(pageNumber, 8);
            var model = new BandejaPublicaciones()
            {
                Titulo = "Publicaciones dadas de baja",
                Action = "BandejaInactivos",
                Controller = "Publicacion",
                Publicaciones = borradores
            };
            ViewBag.contadores = CalculoContadores();
            ViewBag.Preferencias = new nyp.Helpers.Preferencias(dbContext);
            ViewBag.RutaServer = getRutaServer();
            return View("Bandeja", model);
        }

        [Authorize(Roles = "AnalistaNYP")]
        [ServiceFilter(typeof(OcultarMenuLateralFilter))]
        public IActionResult BandejaBorrador(int? page)
        {
            var pageNumber = page ?? 1;
            var borradores = (from p in dbContext.Publicaciones.Include(t => t.Circular)
                              where p.Estado == Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Borrador)
                              select p);//.ToPagedList(pageNumber, 8);
            var model = new BandejaPublicaciones()
            {
                Titulo = "Publicaciones dadas de baja",
                Action = "BandejaBorrador",
                Controller = "Publicacion",
                Publicaciones = borradores
            };
            ViewBag.contadores = CalculoContadores();
            ViewBag.Preferencias = new nyp.Helpers.Preferencias(dbContext);
            ViewBag.RutaServer = getRutaServer();
            return View("Bandeja", model);
        }


        [Authorize(Roles = "AnalistaNYP")]
        [ServiceFilter(typeof(OcultarMenuLateralFilter))]
        public IActionResult BandejaCertificacion(int? page)
        {
            var pageNumber = page ?? 1;
            var pubInCertificacion = (from p in dbContext.Publicaciones.Include(t => t.Circular)
                                      where p.Estado == Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Activo)
                                      && p.FechaCertificacion <= DateTime.Now.AddMonths(1)
                                      select new PublicacionesCertificacion
                                      {
                                          PublicacionId = p.Id,
                                          TituloDocumento = p.NombreDocumento,
                                          FechaPublicacion = p.FechaPublicacion,
                                          FechaCertificacion = p.FechaCertificacion,
                                          Circular = p.Circular

                                      });//.ToPagedList(pageNumber, 8);
            var model = new BandejaPublicaciones()
            {
                Titulo = "Publicaciones a Certificar ",
                Action = "BandejaCertificacion",
                Controller = "Publicacion",
                PublicacionesCertificacion = pubInCertificacion
            };
            ViewBag.contadores = CalculoContadores();
            ViewBag.Preferencias = new Preferencias(dbContext);
            ViewBag.RutaServer = getRutaServer();
            return View("Bandeja", model);
        }

        private List<int> CalculoContadores()
        {
            List<int> contadores = new List<int>();
            var prefs = new Preferencias(dbContext);

            var estados = new string[] {
                    Valores.EstadoSolicitudString(Valores.EstadoSolicitud.Nueva),
                    Valores.EstadoSolicitudString(Valores.EstadoSolicitud.EnProceso),
                    Valores.EstadoSolicitudString(Valores.EstadoSolicitud.OK),
                    Valores.EstadoSolicitudString(Valores.EstadoSolicitud.EsperaVB),
                    Valores.EstadoSolicitudString(Valores.EstadoSolicitud.VBRechazado),
                    Valores.EstadoSolicitudString(Valores.EstadoSolicitud.Borrador)
                };
            var todas = from s in dbContext.Solicitudes.Where(s => estados.Contains(s.Estado))
                        select s;


            contadores.Add(todas.Count());

            // solicitudes asignadas al analista. 
            var analista = GetUsuarioIntranet(session.DatosUsuario.RUT);
            var qry = todas.Where(t => t.Analista != null && t.Analista.Id == analista.Id);
            contadores.Add(qry.Count());

            //Por publicar
            estados = new string[] {
                    Valores.EstadoSolicitudString(Valores.EstadoSolicitud.Borrador)
                };
            qry = todas.Where(s => estados.Contains(s.Estado));
            contadores.Add(qry.Count());

            //Publicaciones a certificar
            var pubInCertificacion = (from p in dbContext.Publicaciones.Include(t => t.Circular)
                                      where p.Estado == Valores.EstadoPublicacionString(Valores.EstadoPublicacion.Activo)
                                      && p.FechaCertificacion <= nyp.Helpers.PrettyDate.SumarDiasHabiles(DateTime.Now, prefs.AlertaVerde)
                                      select p);
            contadores.Add(pubInCertificacion.Count());
            return contadores;
        }

        private UsuarioIntranet GetUsuarioIntranet(int id)
        {
            return (from u in dbContext.UsuariosIntranet
                    where u.Id == id
                    select u).FirstOrDefault();
        }

        #endregion


        #region private
        private void AgregarCambio(Solicitud solicitud, string nombreCampo, string valorAnterior, string valorNuevo)
        {
            if (solicitud.Historial == null)
            {
                solicitud.Historial = new List<Evento>();
            }

            solicitud.Historial.Add(new Evento()
            {
                Autor = Usuario,
                Campo = nombreCampo,
                Fecha = DateTime.Now,
                Titulo = "Modificación",
                ValorAnterior = valorAnterior,
                ValorNuevo = valorNuevo
            });
        }

        /*
        private void AddRow(Table table, int rowNumber, string caption, string value)
        {
            table.Rows[rowNumber].Cells[0].Paragraphs[0].Append(caption).Bold();
            table.Rows[rowNumber].Cells[1].Paragraphs[0].Append(value);
        }*/

        private List<CategoriasViewModel> ObtenerPathCategoriaViewModel(long id)
        {
            IList<Categoria> tmpColl = dbContext.ObtenerPathCategoria(id);
            return (from el in tmpColl
                    select new CategoriasViewModel()
                    {
                        id = el.Id,
                        Name = el.Nombre
                    }).Reverse().ToList();
        }

        private EditarPublicacionViewModel EditarPublicacionViewModelDesdePublicacion(Publicacion publicacion)
        {
            var ret = new EditarPublicacionViewModel()
            {
                Id = publicacion.Id,
                Estado = publicacion.Estado,
                CategoriasExistentes = new List<List<CategoriasViewModel>>()
            };

            ret.Categorias = (from c in dbContext.CategoriasEnPublicacion
                              where c.PublicacionId == publicacion.Id
                              select c.CategoriaId).ToList();

            foreach (var cat in ret.Categorias)
            {
                ret.CategoriasExistentes.Add(ObtenerPathCategoriaViewModel(cat));
            }
            return ret;
        }

        private static Publicacion GetPublicacion(long id)
        {
            return (from p in dbContext.Publicaciones
                           .Include(s => s.Solicitud).ThenInclude(s => s.Historial)
                           .Include(s => s.Circular)
                           .Include(d => d.DocumentosEnPublicacion).ThenInclude(d => d.Documento)
                    where p.Id == id
                    select p).FirstOrDefault();
        }


        private bool ReemplazarDocumento(List<Documento> documentosPublicacion, IFormFile archivoAdjunto, DateTime fechaCertificacion, out string mensaje, bool notificar, int CertificacionId)
        {
            Documento nuevoDocumento;


            //Guardar el archivo en Disco. 
            var contentDisposition = ContentDispositionHeaderValue.Parse(archivoAdjunto.ContentDisposition);
            var filename = contentDisposition.FileName.Trim('"');
            string[] auxFileName = filename.Split('\\');
            filename = auxFileName[auxFileName.Length - 1];
            var mime = GetMimeMapping(filename);
            if (mime == null)
            {
                // Tipo de archivo no permitido
                var extension = Path.GetExtension(filename);
                mensaje = string.Format("Tipo de archivo '{0}' no permitido", extension);
                return false;
            }

            var internalName = Guid.NewGuid().ToString("n");
            var physicalFilename = GetPhysicalFilename(internalName);
            archivoAdjunto.SaveAs(physicalFilename);






            //Trasnformar el archivo a Base64
            Byte[] bytes = System.IO.File.ReadAllBytes(GetPhysicalFilename(physicalFilename));
            String file = Convert.ToBase64String(bytes);
            String contenidoBase64 = "";
            //Insertar saltos de linea. 
            for (int i = 0; i < file.Length; i = i + 76)
            {
                if (i + 76 < file.Length)
                    contenidoBase64 += file.Substring(i, 76) + "\n";
                else
                    contenidoBase64 += file.Substring(i, file.Length - i);
            }




            //Registrar el archivo en la base de datos. 
            Documento auxDocumento = documentosPublicacion.Find(x => x.NombreArchivo == filename && x.Vigente == true);

            nuevoDocumento = new Documento()
            {
                Codigo = auxDocumento.Codigo != null ? auxDocumento.Codigo : "",
                FechaCertificacion = fechaCertificacion,
                FechaPublicacion = DateTime.Now,
                GestorDocumentalId = internalName,
                NombreDocumento = auxDocumento.NombreDocumento,
                NombreArchivo = filename,
                Publicacion = auxDocumento.Publicacion,
                Version = auxDocumento.Version + 1,
                Vigente = true,
                ProcesoCertificacionId = CertificacionId
            };

            auxDocumento.Vigente = false;


            //Guardar el archivo en el content

            var res = documentManager.Almacenar(new DatosPublicacion()
            {
                Id = auxDocumento.Id,
                Tipo = "",
                NombreFisico = auxDocumento.NombreDocumento,
                Descripcion = auxDocumento.NombreArchivo,
                CodigoDocumento = auxDocumento.Codigo != null ? auxDocumento.Codigo : "",
                Fecha = auxDocumento.FechaPublicacion
            }, physicalFilename, contenidoBase64);


            if (!res.Ok)
            {
                mensaje = res.Mensaje;
                return false;
            }



            //Commit sobre la base de datos. 
            dbContext.Documentos.Attach(auxDocumento);
            var entry = dbContext.Entry(auxDocumento);
            entry.State = EntityState.Modified;



            dbContext.Documentos.Add(nuevoDocumento);
            //RevertirEstadoAutorizadores(solicitud);
            dbContext.SaveChanges();



            dbContext.DocumentosEnPublicaciones.Add(new DocumentosEnPublicacion()
            {
                DocumentoId = nuevoDocumento.Id,
                PublicacionId = nuevoDocumento.Publicacion.Id
            });

            dbContext.SaveChanges();

            //Actualizar las estadisticas. 
            var estadisticas = (from e in dbContext.EstadisticasDocumentos
                                where e.DocumentoId == auxDocumento.Id
                                select e).ToArray();
            var estadisticas2 = (from e in dbContext.EstadisticasDocumentos
                                 where e.DocumentoId == auxDocumento.Id
                                 select e).ToArray();



            //Actualizar las referencias en otras publicaciones. 
            var referencias = (from r in dbContext.DocumentosEnPublicaciones
                               where r.DocumentoId == auxDocumento.Id && r.PublicacionId != nuevoDocumento.Publicacion.Id
                               select r).ToArray();
            var referencias2 = (from r in dbContext.DocumentosEnPublicaciones
                                where r.DocumentoId == auxDocumento.Id && r.PublicacionId != nuevoDocumento.Publicacion.Id
                                select r).ToArray();

            if (estadisticas != null)
            {
                dbContext.EstadisticasDocumentos.RemoveRange(estadisticas);
                dbContext.SaveChanges();

            }
            if (referencias != null)
            {
                dbContext.DocumentosEnPublicaciones.RemoveRange(referencias);
                dbContext.SaveChanges();
            }
            if (estadisticas2 != null)
            {
                List<EstadisticaDocumento> ed = new List<EstadisticaDocumento>();
                foreach (var e in estadisticas2)
                {
                    ed.Add(new EstadisticaDocumento
                    {
                        Documento = nuevoDocumento,
                        Fecha = e.Fecha
                    });
                }
                dbContext.EstadisticasDocumentos.AddRange(ed);
                dbContext.SaveChanges();
            }
            if (referencias2 != null)
            {
                foreach (var r in referencias2)
                {
                    r.Documento = nuevoDocumento;
                }
                dbContext.DocumentosEnPublicaciones.AddRange(referencias2);
                dbContext.SaveChanges();
            }

            mensaje = "Archivo guardado con éxito";
            return true;
        }

        private string GetPhysicalFilename(string fileName)
        {
            var prefs = new Preferencias(dbContext);
            string rutaArchivo = prefs.DirectorioTemporal;
            rutaArchivo = Path.Combine(rutaArchivo, "tmp-upload-zone", fileName);
            return rutaArchivo;
        }

        private bool ActualizarReferenciasEstatisticas(Documento auxDocumento, Documento nuevoDocumento)
        {
            //Actualizar las estadisticas. 
            var estadisticas = (from e in dbContext.EstadisticasDocumentos
                                where e.DocumentoId == auxDocumento.Id
                                select e).ToArray();
            var estadisticas2 = (from e in dbContext.EstadisticasDocumentos
                                 where e.DocumentoId == auxDocumento.Id
                                 select e).ToArray();

            //Actualizar las referencias en otras publicaciones. 
            var referencias = (from r in dbContext.DocumentosEnPublicaciones
                               where r.DocumentoId == auxDocumento.Id && r.PublicacionId != auxDocumento.Publicacion.Id
                               select r).ToArray();
            var referencias2 = (from r in dbContext.DocumentosEnPublicaciones
                                where r.DocumentoId == auxDocumento.Id && r.PublicacionId != auxDocumento.Publicacion.Id
                                select r).ToArray();

            if (estadisticas != null)
            {
                dbContext.EstadisticasDocumentos.RemoveRange(estadisticas);
                dbContext.SaveChanges();
            }
            if (referencias != null)
            {
                dbContext.DocumentosEnPublicaciones.RemoveRange(referencias);
                dbContext.SaveChanges();
            }
            if (estadisticas2 != null)
            {
                List<EstadisticaDocumento> ed = new List<EstadisticaDocumento>();
                foreach (var e in estadisticas2)
                {
                    ed.Add(new EstadisticaDocumento
                    {
                        Documento = nuevoDocumento,
                        Fecha = e.Fecha
                    });
                }
                dbContext.EstadisticasDocumentos.AddRange(ed);
                dbContext.SaveChanges();
            }
            if (referencias2 != null)
            {
                foreach (var r in referencias2)
                {
                    r.Documento = nuevoDocumento;
                }
                dbContext.DocumentosEnPublicaciones.AddRange(referencias2);
                dbContext.SaveChanges();
            }

            //Agregar la nueva version del documento en las publicaciones originales

            var publicacionesOrginales = (from r in dbContext.DocumentosEnPublicaciones.Include(t => t.Publicacion)
                                          where r.DocumentoId == auxDocumento.Id && r.PublicacionId == auxDocumento.Publicacion.Id
                                          select r).ToArray();
            if (publicacionesOrginales != null)
            {
                List<DocumentosEnPublicacion> nuevasReferencias = new List<DocumentosEnPublicacion>();
                foreach (var po in publicacionesOrginales)
                {
                    if (po.Publicacion.Estado == Valores.EstadoPublicacion.Activo.ToString())
                    {
                        nuevasReferencias.Add(new DocumentosEnPublicacion
                        {
                            PublicacionId = po.PublicacionId,
                            DocumentoId = nuevoDocumento.Id
                        });
                    }
                }
                dbContext.DocumentosEnPublicaciones.AddRange(nuevasReferencias);
                dbContext.SaveChanges();
            }
            return true;
        }

        #endregion


        private String getRutaServer()
        {
            //var prefs = new Preferencias(dbContext);
            //return prefs.RutaServer;
            return ""; 
        }

    }

    public class AutocompleteSuggestion
    {
        public string value { get; set; }
        public string data { get; set; }
    }

    public class Autocomplete
    {
        public AutocompleteSuggestion[] suggestions { get; set; }
    }
}
