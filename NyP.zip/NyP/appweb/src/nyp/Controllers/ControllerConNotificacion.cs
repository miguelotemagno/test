﻿using Microsoft.AspNet.Hosting;
using Microsoft.AspNet.Mvc;
using Microsoft.AspNet.Mvc.Rendering;
using Microsoft.AspNet.Mvc.ViewEngines;
using Microsoft.AspNet.Mvc.ViewFeatures;
using Microsoft.Data.Entity;
using Newtonsoft.Json;
using nyp.DataModels;
using nyp.GestorDocumental.Service;
using nyp.Helpers;
using nyp.Models;
using nyp.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace nyp.Controllers
{
    public class ControllerConNotificacion : ControllerNYP
    {
        private static IEmailSender emailSender = null;
        private UsuarioIntranet _usuario = null;
        protected static ISessionService session = null;
        protected static INYPContext dbContext = null;
        protected static IHostingEnvironment hostingEnvironment = null;
        protected static IGestorDocumental documentManager = null;
        protected IEmailSender EmailSender { get { return emailSender; } }
        protected UsuarioIntranet Usuario
        {
            get
            {
                if (_usuario == null)
                {
                    _usuario = (from u in dbContext.UsuariosIntranet
                                where u.Id == session.DatosUsuario.RUT
                                select u).FirstOrDefault();
                }
                return _usuario;
            }
        }

        public ControllerConNotificacion(
            IEmailSender mailSenderService,
            INYPContext context,
            IGestorDocumental gestorDocumental,
            IHostingEnvironment env,
            ISessionService sessionContext)
        {
            emailSender = mailSenderService;
            dbContext = context;
            documentManager = gestorDocumental;
            hostingEnvironment = env;
            session = sessionContext;
        }

        protected string RenderViewToString(string viewName, object model)
        {
            if (string.IsNullOrEmpty(viewName))
                viewName = ActionContext.ActionDescriptor.Name;

            ViewData.Model = model;

            using (StringWriter sw = new StringWriter())
            {
                var engine = Resolver.GetService(typeof(ICompositeViewEngine))
                    as ICompositeViewEngine;
                var viewResult = engine.FindView(ActionContext, viewName);

                var viewContext = new ViewContext(
                    ActionContext,
                    viewResult.View,
                    ViewData,
                    TempData,
                    sw,
                    new HtmlHelperOptions() //Added this parameter in
                );

                //Everything is async now!
                var t = viewResult.View.RenderAsync(viewContext);
               // t.Wait();

                return sw.GetStringBuilder().ToString();
            }
        }

        protected async Task<ResultadoEnvioNotificacionViewModel> NotificarNuevaPublicacion(Publicacion publicacion, int listaDistribucionId, List<string> usuariosNotificados = null)
        {
            var listaDistribucion = (from l in dbContext.ListasDistribucion
                         .Include(u => u.UsuariosEnListaDistribucion).ThenInclude(u => u.UsuarioIntranet)
                                     where l.Id == listaDistribucionId
                                     select l).FirstOrDefault();
            if (listaDistribucion == null)
            {
                return null;
            }

            if (usuariosNotificados == null) usuariosNotificados = new List<string>();

            var notificacion = new NotificacionPublicacionViewModel
            {
                Publicacion = publicacion,
                ListaDistribucion = listaDistribucion
            };

            var message = RenderViewToString("~/Views/Templates/NuevaPublicacion", notificacion);

            var autorizadores = (from a in listaDistribucion.UsuariosEnListaDistribucion
                                select new Destinatario
                                {
                                    Email = a.UsuarioIntranet.Email,
                                    Nombre = a.UsuarioIntranet.Nombres + " " + a.UsuarioIntranet.ApellidoPaterno
                                }).ToList();

            // Añadir usuarios a copiar
            foreach(var email in usuariosNotificados)
            {
                // Evitar duplicar destinatarios
                if(!autorizadores.Exists(x=>x.Email == email))
                {
                    autorizadores.Add(new Destinatario { Email = email, Nombre = email });
                }
            }

            var adjuntos = new List<IAdjunto>();
            try
            {
                // Agregar circular a adjuntos
                var filename = Path.Combine(Path.GetTempPath(), string.Format("Circular-{0}.docx", publicacion.Circular.Id));
                var wu = new WordUtils(hostingEnvironment, Url);
                wu.GetCircularWordAsFile(publicacion, filename);
                adjuntos.Add(new Adjunto { Nombre = string.Format("Circular Nº {0}", publicacion.Circular.Id), Path = filename });

                // Agregar resto de adjuntos
                foreach (var d in publicacion.DocumentosEnPublicacion)
                {
                    var doc = documentManager.GetDocumento(d.Documento.GestorDocumentalId);
                    // Guardar en zona intermedia
                    var path = Path.Combine(Path.GetTempPath(), doc.Nombre);
                    System.IO.File.WriteAllBytes(path, doc.Contenidos);
                    adjuntos.Add(new Adjunto { Nombre = doc.Nombre, Path = path });
                }
                await EmailSender.SendEmailToList(autorizadores, "Nueva Publicación en el Portal de Normas y Procedimientos",
                    message, adjuntos);
            }
            finally
            {
                foreach (var adjunto in adjuntos)
                {
                    try
                    {
                        System.IO.File.Delete(adjunto.Path);
                    }
                    catch(IOException e)
                    {

                    }
                }
            }

            publicacion.Solicitud.Historial.Add(new Evento
            {
                Autor = Usuario,
                Fecha = DateTime.Now,
                Titulo = "Notificación de Publicación",
                ValorAnterior = "Notificación de Publicación en Portal de Normas y Procedimientos",
                ValorNuevo = "Lista de Distribución: " + listaDistribucion.Nombre
            });

            dbContext.SaveChanges();
            return new ResultadoEnvioNotificacionViewModel
            {
                ListaDistribucion = listaDistribucion,
                Notificacion = notificacion
            };
        }

        protected void ConfirmacionVisual(string titulo, string texto)
        {
            TempData["MostrarConfirmacion"] = JsonConvert.SerializeObject(
                new Confirmacion
                {
                    Titulo = titulo,
                    Texto = texto
                });
        }
    }
}
