﻿using Microsoft.AspNet.Mvc;
using System;
using System.Collections.Generic;
using System.IO;

namespace nyp.Controllers
{
    public class ControllerNYP : Controller
    {
        public string GetMimeMapping(string fileName)
        {
            var mimeMappings = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { ".doc", "application/msword" },
                { ".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document" },
                //{ ".txt", "text/plain" },
                { ".pdf", "application/pdf" },
                { ".pps", "application/vnd.ms-powerpoint" },
                { ".ppsx", "application/vnd.openxmlformats-officedocument.presentationml.slideshow" },
                { ".ppt", "application/vnd.ms-powerpoint" },
                { ".pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation" },
                { ".rtf", "application/rtf" },
                { ".vsd", "application/vnd.visio" },
                { ".vss", "application/vnd.visio" },
                { ".vst", "application/vnd.visio" },
                { ".vsto", "application/x-ms-vsto" },
                { ".vsw", "application/vnd.visio" },
                { ".vsx", "application/vnd.visio" },
                { ".vtx", "application/vnd.visio" },
                { ".msg", "application/vnd.ms-outlook" },
                { ".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" },
                { ".xls", "application/vnd.ms-excel" },
                { ".jpg", "image/jpeg" }
            };
            string extension = Path.GetExtension(fileName);
            if (extension == null)
            {
                return null;
            }
            string result;
            if (mimeMappings.TryGetValue(extension, out result))
            {
                return result;
            }
            return null;
        }
    }
}