﻿using Microsoft.AspNet.Mvc;
using nyp.Models;
using nyp.Session;
using System.Security.Claims;
using Microsoft.AspNet.Authentication.Cookies;
using Microsoft.AspNet.Authorization;
using System.Linq;
using System;
using System.Collections.Generic;
using nyp.DataModels;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using nyp.Filters;
using nyp.Extensions;
using Newtonsoft.Json.Linq;
using nyp.Helpers;

namespace nyp.Controllers
{
    class Rut
    {
        public static bool validarRut(string rut, out int parteNumerica)
        {
            try
            {
                rut = rut.Trim();
                rut = rut.ToUpper();
                rut = rut.Replace(".", "");
                rut = rut.Replace("-", "");
                int rutAux = int.Parse(rut.Substring(0, rut.Length - 1));
                char dv = char.Parse(rut.Substring(rut.Length - 1, 1));
                int m = 0, s = 1;
                for (; rutAux != 0; rutAux /= 10)
                {
                    s = (s + rutAux % 10 * (9 - m++ % 6)) % 11;
                }
                if (dv == (char)(s != 0 ? s + 47 : 75))
                {
                    parteNumerica = rutAux;
                    return true;
                }
            }
            catch (Exception)
            {
            }
            parteNumerica = -1;
            return false;
        }

        public static List<string> splitWords(string text)
        {
            var matches = Regex.Matches(text, @"\w+[^\s]*\w+|\w");
            var result = new List<string>();
            foreach (Match match in matches)
            {
                result.Add(match.Value);
            }
            return result;
        }
    }



    [Authorize]
    [ServiceFilter(typeof(OcultarMenuLateralFilter))]
    public class IntranetAuthController : Controller
    {
        private static NYPContext dbContext;
        public IntranetAuthController(NYPContext context)
        {
            dbContext = context;
        }

        [AllowAnonymous]
        public IActionResult Index()
        {
            ViewBag.RutaServer = getRutaServer();
            return View();
        }

        [AllowAnonymous]
        public async Task<IActionResult> Login(IntranetAuthViewModel model)
        {
            if (ModelState.IsValid)
            {
                
                var user = (from u in dbContext.UsuariosIntranet where u.Id == model.RUT select u).FirstOrDefault();
                if (user != null)
                {
                    List<Restriccion> listaBloqueo;
                    listaBloqueo = calcularBloqueosPublicos(user);
                    calcularBloqueosPrivados(listaBloqueo, user);
                    NYPSessionData session = new NYPSessionData()
                    {
                        RUT = user.Id,
                        Nombre = user.Nombres + " " + user.ApellidoPaterno,
                        Cargo = user.Cargo,
                        Email = user.Email,
                        AnalistaNYP = user.AnalistaNYP,
                        PublicacionesBloqueadas = listaBloqueo
                    };
                    NYPSession.Save(session, HttpContext.Session);

                    var identity = new ClaimsIdentity(
                        new[]
                        {
                            new Claim(ClaimTypes.Name, session.Nombre),
                            new Claim(ClaimTypes.Email, session.Email ?? ""),
                            new Claim(ClaimTypes.SerialNumber, session.RUT.ToString())
                        },
                        CookieAuthenticationDefaults.AuthenticationScheme
                    );

                    if (session.AnalistaNYP)
                    {
                        identity.AddClaim(new Claim(ClaimTypes.Role, "AnalistaNYP"));
                    }
                    var claim = new ClaimsPrincipal(identity);

                    await HttpContext.Authentication.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
                        claim);
                    ViewBag.RutaServer = getRutaServer();
                    if (session.AnalistaNYP)
                    {
                        return RedirectToAction("Asignadas", "Solicitud");
                    }
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    return RedirectToAction("LoginError", "IntranetAuth");
                }
            }
            ViewBag.RutaServer = getRutaServer();
            return View();
        }

        [AllowAnonymous]
        public ActionResult LoginError()
        {
            return View();
        }

        [Produces("application/json")]
        public List<ApplicationUserJSONViewModel> SearchUsers(string q, int page = 0)
        {
            int n = 0;


            if (q == null || q.Length < 3)
            {
                return null;
            }

            var qry = from u in dbContext.UsuariosIntranet
                      select u;

            if (Int32.TryParse(q, out n))
            {
                qry = qry.Where(x => x.Id == n);
            }
            else
            {
                if (Rut.validarRut(q, out n))
                {
                    qry = qry.Where(x => x.Id == n);
                }
                else
                {
                    var tokens = q.Split(' ');
                    foreach (var t in tokens)
                    {
                        qry = qry.Where(x => (x.Nombres).ToLower().Contains(t) || (x.ApellidoPaterno).ToLower().Contains(t));
                    }

                }
            }

            var res = from u in qry
                      select new ApplicationUserJSONViewModel()
                      {
                          id = u.Id,
                          nombre = string.Format("{0}, {1}", u.ApellidoPaterno, u.Nombres),
                          cargo = u.Cargo
                      };
            return res.ToList();
        }

        [Produces("application/json")]
        public List<ApplicationOpenUserJSONViewModel> SearchUsersWithEmail(string q, int page = 0)
        {
            int n = 0;

            if (q == null || q.Length < 3)
            {
                return null;
            }

            var qry = from u in dbContext.UsuariosIntranet
                      select u;

            if (Int32.TryParse(q, out n))
            {
                qry = qry.Where(x => x.Id == n);
            }
            else
            {
                if (Rut.validarRut(q, out n))
                {
                    qry = qry.Where(x => x.Id == n);
                }
                else
                {
                    var tokens = q.Split(' ');
                    foreach (var t in tokens)
                    {
                        qry = qry.Where(x => (x.Nombres).ToLower().Contains(t) || (x.ApellidoPaterno).ToLower().Contains(t));
                    }

                }
            }

            var tmp = from u in qry
                      select new ApplicationOpenUserJSONViewModel()
                      {
                          id = u.Email,
                          nombre = string.Format("{0}, {1}", u.ApellidoPaterno, u.Nombres),
                          cargo = u.Cargo,
                          email = u.Email
                      };

            var res = new List<ApplicationOpenUserJSONViewModel>();

            // Solo devolver usuarios con email valido
            foreach(var e in tmp)
            {
                if (e.email != null && e.email.IsValidEmail())
                {
                    res.Add(e);
                }
            }

            return res.ToList();
        }

        private static List<Restriccion> calcularBloqueosPublicos(UsuarioIntranet user)
        {
            List<Restriccion> listaR = new List<Restriccion>();
            if (!user.AnalistaNYP) {

                var bloqueoGerencia = (from p in dbContext.Publicaciones
                                       join b in dbContext.Restricciones
                                       on p.Id equals b.PublicacionId
                                       join g in dbContext.Gerencias
                                       on b.GerenciaId equals g.Id
                                       join a in dbContext.Areas on g.Id equals a.GerenciaId
                                       join ud in dbContext.Unidades on a.Id equals ud.AreaId
                                       where ud.Id == user.UnidadId &&
                                       p.NivelAcceso == "Publico" && p.Estado == Valores.EstadoPublicacion.Activo.ToString()
                                       select b);

                if (!bloqueoGerencia.Any()) return listaR;


                int areaUsuario = (from u in dbContext.UsuariosIntranet
                                   join uu in dbContext.Unidades on u.UnidadId equals uu.Id
                                   join au in dbContext.Areas on uu.AreaId equals au.Id
                                   where u.Id == user.Id
                                   select au.Id).FirstOrDefault();

                var bloqueoArea = (from b2 in bloqueoGerencia
                                   where b2.AreaId == areaUsuario || b2.AreaId == null
                                   select b2);

                if (!bloqueoArea.Any()) return listaR;

                var bloqueoUnidad = (from b3 in bloqueoArea
                                     where b3.UnidadId == user.UnidadId || b3.UnidadId == null
                                     select b3);

                if (!bloqueoUnidad.Any()) return listaR;


                foreach (Restriccion rest in bloqueoUnidad)
                {
                    var usuario = (from ue in dbContext.ExclusionesUsuario
                                   where ue.RestriccionRestriccionId == rest.RestriccionId && ue.UsuarioIntranetId == user.Id
                                   select ue).FirstOrDefault();
                    if (usuario == null)
                    {
                        listaR.Add(rest);

                    }
                }
            }
            return listaR;
        }

        private static void calcularBloqueosPrivados(List<Restriccion> lista, UsuarioIntranet usuario)
        {
            List<Restriccion> listEval = new List<Restriccion>();
            if (!usuario.AnalistaNYP)
            {
                var publicaciones = from p in dbContext.Publicaciones
                                    where p.NivelAcceso == "Privado" && p.Estado == Valores.EstadoPublicacion.Activo.ToString()
                                    select p;

                //verifica las publicaciones, si no tienen detalles de restriccion para la gerencia 
                //del usuario entonces agregar la publicacion. 
                var gerenciaUsuario = (from u in dbContext.Unidades
                                       join a in dbContext.Areas on u.AreaId equals a.Id
                                       join g in dbContext.Gerencias on a.GerenciaId equals g.Id
                                       where u.Id == usuario.UnidadId
                                       select g).FirstOrDefault();

                foreach (var pub in publicaciones)
                {
                    var permisoGerencia = (from r in dbContext.Restricciones
                                           where r.PublicacionId == pub.Id && r.GerenciaId == gerenciaUsuario.Id
                                           select r).FirstOrDefault();

                    if (permisoGerencia == null)
                    {
                        lista.Add(new Restriccion
                        {
                            PublicacionId = pub.Id
                        });
                    }
                    else
                    {
                        listEval.Add(permisoGerencia);
                    }

                }
                //ya tengo bloqueo de las publicaciones privadas que no tienen que ver con el usuario actual. 
                //filtradas por la gerencia. 

                if (listEval.Any())
                {
                    var areaUsuario = (from u in dbContext.Unidades
                                       join a in dbContext.Areas on u.AreaId equals a.Id
                                       where u.Id == usuario.UnidadId
                                       select a).FirstOrDefault();

                    var permisosArea = from r in listEval
                                       where r.AreaId == areaUsuario.Id && r.AreaId != null
                                       select r;

                    var restriccionesArea = from r in listEval
                                            where r.AreaId != areaUsuario.Id && r.AreaId != null
                                            select r;
                    lista.AddRange(restriccionesArea.ToList());
                    listEval = permisosArea.ToList();
                }
                //ya tengo las restricciones por area

                if (listEval.Any())
                {
                    var permisoUnidad = from r in listEval
                                        where r.UnidadId == usuario.UnidadId && r.UnidadId != null
                                        select r;
                    var restriccionesUnidad = from r in listEval
                                              where r.UnidadId != usuario.UnidadId && r.UnidadId != null
                                              select r;
                    lista.AddRange(restriccionesUnidad);
                    listEval = permisoUnidad.ToList();
                }

                //ya estan listas las restricciones por unidad

                if (listEval.Any())
                {
                    var restriccionUsuario = from r in listEval
                                             join eu in dbContext.ExclusionesUsuario
                                             on r.RestriccionId equals eu.RestriccionRestriccionId
                                             where eu.UsuarioIntranetId == usuario.Id
                                             select r;

                    lista.AddRange(restriccionUsuario);
                }
            }
        }


        public static List<Restriccion> CalcularBloqueos(int rut)
        {
            var user = (from u in dbContext.UsuariosIntranet where u.Id == rut select u).FirstOrDefault();
            List<Restriccion> lista = calcularBloqueosPublicos(user);
            calcularBloqueosPrivados(lista, user);
            return lista;
        } 

        private String getRutaServer()
        {
            //var prefs = new Preferencias(dbContext);
            return  "";//prefs.RutaServer; 
        }
    }
}

