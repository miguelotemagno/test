﻿using Microsoft.AspNet.Authentication.Cookies;
using Microsoft.AspNet.Builder;
using Microsoft.AspNet.Hosting;
using Microsoft.AspNet.Http;
using Microsoft.Data.Entity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.PlatformAbstractions;
using nyp.DataModels;
using nyp.Filters;
using nyp.GestorDocumental.IBMContentManager;
using nyp.GestorDocumental.NullContentManager;
using nyp.GestorDocumental.WSContent;
using nyp.GestorDocumental.Service;
using nyp.Middleware;
using nyp.Services;
using nyp.Session;
using System.Globalization;


namespace nyp
{

    public class Startup
    {
        public Startup(IHostingEnvironment env, IApplicationEnvironment appEnv)
        {
            // Setup configuration sources.

            var builder = new ConfigurationBuilder()
                .SetBasePath(appEnv.ApplicationBasePath)
                .AddJsonFile("config.json")
                .AddJsonFile($"config.{env.EnvironmentName}.json", optional: true);

            if (env.IsDevelopment())
            {
                // This reads the configuration keys from the secret store.
                // For more details on using the user secret store see http://go.microsoft.com/fwlink/?LinkID=532709
                // builder.AddUserSecrets();

                // This will push telemetry data through Application Insights pipeline faster, allowing you to view results immediately.
                // builder.AddApplicationInsightsSettings(developerMode: true);

            }
            builder.AddEnvironmentVariables();
            Configuration = builder.Build();
        }

        public IConfiguration Configuration { get; set; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // Add Entity Framework services to the services container.
            services
                .AddEntityFramework()
                .AddSqlServer()
                .AddDbContext<NYPContext>(options =>
                    options.UseSqlServer(Configuration["Data:NYP:ConnectionString"])
                                    .MigrationsAssembly("nyp")
                    );

            // dbContext disponible en servicios
            services.AddScoped<INYPContext>(provider => provider.GetService<NYPContext>());

            // Add MVC services to the services container.
            services.AddAuthentication();
            services.AddMvc();
            services.AddCaching();
            services.AddSession();

            // Register application services.
            string servicioMensajeriaActivo = Configuration["Mensajeria:Activo"];
            if (servicioMensajeriaActivo == "Smtp")
            {
                services.Configure<SmtpOptions>(Configuration.GetSection("Mensajeria:Smtp"));
                // Registrar servicio
                services.AddTransient<IEmailSender, SmtpMessageServices>();
            }
            else
            {
                services.Configure<SendgridOptions>(Configuration.GetSection("Mensajeria:Sendgrid"));
                services.AddTransient<IEmailSender, SendgridMessageServices>();
            }

            // services.AddTransient<ISmsSender, SendgridMessageSender>();

            services.AddScoped<OcultarMenuLateralFilter>();

            // Información extra en servicio - Identificación
            services.AddTransient<ISessionService, SessionServiceLocalImplementation>();

            // Servicio de gestión documental

            // Esta configuración puede ser reemplazada por otro manejador de contenido, por ejemplo, APIs internas
            // del banco. Para cumplir basta con implementar la interfaz IGestorDocumental y cambiar la configuración
            // en esta parte.

            // Configuración obtenida desde config.json
            string gestorDocumentalActivo = Configuration["GestorDocumental:Activo"];
            if (gestorDocumentalActivo == "IBMContentManager")
            {
                services.Configure<IBMContentManagerWebServiceOptions>(Configuration.GetSection("GestorDocumental:IBMContentManager"));
                // Registrar servicio
                services.AddTransient<IGestorDocumental, IBMContentManagerWebService>();
            }
            else if (gestorDocumentalActivo == "WSContent")
            {
               // services.Configure<WSBancoOptions>(Configuration.GetSection("GestorDocumental:WSContent"));
                services.AddTransient<IGestorDocumental, WSImplementation>();
            }
            else
            {
                services.AddTransient<IGestorDocumental, NullContentManagerService>();
            }
        }

        // Configure is called after ConfigureServices is called.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            // Estoy hablando español, soy alérgico a los crustáceos
            CultureInfo.DefaultThreadCurrentCulture = CultureInfo.GetCultureInfo("es-CL");
            CultureInfo.DefaultThreadCurrentUICulture = CultureInfo.GetCultureInfo("es-CL");
            app.UseMiddleware<NYPRequestLocalizationMiddleware>();

            // loggerFactory.MinimumLevel = LogLevel.Information;
            // loggerFactory.AddDebug(LogLevel.Verbose);
            loggerFactory.AddConsole();


            // Configure the HTTP request pipeline.

            // Add the following to the request pipeline only in development environment.
            // if (env.IsDevelopment())
            // {
            app.UseBrowserLink();
            app.UseDeveloperExceptionPage();
            app.UseDatabaseErrorPage(options => { options.EnableAll(); });
            // }
            // else
            // {
            // Add Error handling middleware which catches all application specific errors and
            // sends the request to the following path or controller action.
            //    app.UseExceptionHandler("/Home/Error");
            //}

            // Track data about exceptions from the application. Should be configured after all error handling middleware in the request pipeline.
            // app.UseApplicationInsightsExceptionTelemetry();

            // Add static files to the request pipeline.
            app.UseStaticFiles();

            // Cookies
            app.UseCookieAuthentication(options =>
            {
                options.AuthenticationScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                options.AutomaticAuthenticate = true;
                options.AutomaticChallenge = true;
                options.SessionStore = new MemoryCacheSessionStore();
                options.LoginPath = new PathString("/IntranetAuth/Index");
            });

            // Agregar sesiones
            app.UseSession();

            var httpContextAccessor = app.ApplicationServices.GetRequiredService<IHttpContextAccessor>();

            Extensions.Extensions.Configure(httpContextAccessor);


            // Add MVC to the request pipeline.
            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
