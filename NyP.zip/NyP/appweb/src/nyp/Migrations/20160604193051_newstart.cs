using System;
using System.Collections.Generic;
using Microsoft.Data.Entity.Migrations;
using Microsoft.Data.Entity.Metadata;

namespace nyp.Migrations
{
    public partial class newstart : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Archivo",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CodigoDocumento = table.Column<string>(nullable: false),
                    NombreArchivoOriginal = table.Column<string>(nullable: false),
                    NombreFisico = table.Column<string>(nullable: false),
                    Tipo = table.Column<string>(nullable: false),
                    TituloDocumento = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Archivo", x => x.Id);
                });
            migrationBuilder.CreateTable(
                name: "ArchivosEnSolicitud",
                columns: table => new
                {
                    ArchivoId = table.Column<long>(nullable: false),
                    SolicitudId = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ArchivosEnSolicitud", x => new { x.ArchivoId, x.SolicitudId });
                });
            migrationBuilder.CreateTable(
                name: "Categoria",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CategoriaId = table.Column<long>(nullable: true),
                    Descripcion = table.Column<string>(nullable: true),
                    Nombre = table.Column<string>(nullable: true),
                    Orden = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categoria", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Categoria_Categoria_CategoriaId",
                        column: x => x.CategoriaId,
                        principalTable: "Categoria",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });
            migrationBuilder.CreateTable(
                name: "Circular",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Consultas = table.Column<string>(nullable: true),
                    Destino = table.Column<string>(nullable: true),
                    FinVigencia = table.Column<DateTime>(nullable: false),
                    FuncionamientoActual = table.Column<string>(nullable: true),
                    FuncionamientoNuevo = table.Column<string>(nullable: true),
                    InicioVigencia = table.Column<DateTime>(nullable: false),
                    Materia = table.Column<string>(nullable: true),
                    Objetivo = table.Column<string>(nullable: true),
                    Responsable = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Circular", x => x.Id);
                });
            migrationBuilder.CreateTable(
                name: "CodigoGlosa",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CodigoDocumento = table.Column<string>(nullable: true),
                    NombreDocumento = table.Column<string>(nullable: true),
                    Vigente = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CodigoGlosa", x => x.Id);
                });
            migrationBuilder.CreateTable(
                name: "DocumentosMasVisitados",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Cantidad = table.Column<int>(nullable: false),
                    GestorDocumentalId = table.Column<string>(nullable: true),
                    NombreArchivo = table.Column<string>(nullable: true),
                    NombreDocumento = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DocumentosMasVisitados", x => x.Id);
                });
            migrationBuilder.CreateTable(
                name: "Gerencia",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false),
                    FechaCreacion = table.Column<DateTime>(nullable: false, defaultValueSql: "getdate()"),
                    FechaEliminacion = table.Column<DateTime>(nullable: true),
                    Nombre = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Gerencia", x => x.Id);
                });
            migrationBuilder.CreateTable(
                name: "ListaDistribucion",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Nombre = table.Column<string>(nullable: true),
                    Notas = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ListaDistribucion", x => x.Id);
                });
            migrationBuilder.CreateTable(
                name: "Noticia",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Autor = table.Column<string>(nullable: true),
                    Cuerpo = table.Column<string>(nullable: true),
                    Fecha = table.Column<DateTime>(nullable: false),
                    Titulo = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Noticia", x => x.Id);
                });
            migrationBuilder.CreateTable(
                name: "PropiedadConfiguracion",
                columns: table => new
                {
                    Id = table.Column<string>(nullable: false),
                    Valor = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PropiedadConfiguracion", x => x.Id);
                });
            migrationBuilder.CreateTable(
                name: "PublicacionesMasVisitadas",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Cantidad = table.Column<int>(nullable: false),
                    Codigo = table.Column<string>(nullable: true),
                    FechaPublicacion = table.Column<DateTime>(nullable: false),
                    NombreDocumento = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PublicacionesMasVisitadas", x => x.Id);
                });
            migrationBuilder.CreateTable(
                name: "ReporteCertificacionItem",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AnalistaEjecutor = table.Column<string>(nullable: true),
                    Area = table.Column<string>(nullable: true),
                    AreaAnterior = table.Column<string>(nullable: true),
                    Codigo = table.Column<string>(nullable: true),
                    Comentarios = table.Column<string>(nullable: true),
                    FechaCertificacion = table.Column<string>(nullable: true),
                    FechaCreacion = table.Column<string>(nullable: true),
                    FechaProceso = table.Column<string>(nullable: true),
                    FechaPublicacion = table.Column<string>(nullable: true),
                    Gerencia = table.Column<string>(nullable: true),
                    GerenciaAnterior = table.Column<string>(nullable: true),
                    NombreDocumento = table.Column<string>(nullable: true),
                    ResponsableActual = table.Column<string>(nullable: true),
                    ResponsableAnterior = table.Column<string>(nullable: true),
                    Tipo = table.Column<string>(nullable: true),
                    Unidad = table.Column<string>(nullable: true),
                    UnidadAnterior = table.Column<string>(nullable: true),
                    Version = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ReporteCertificacionItem", x => x.Id);
                });
            migrationBuilder.CreateTable(
                name: "ReportePublicacionItem",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Analista = table.Column<string>(nullable: true),
                    Area = table.Column<string>(nullable: true),
                    AreasImpactadas = table.Column<string>(nullable: true),
                    CategoriasEnPublicacion = table.Column<string>(nullable: true),
                    Circular = table.Column<int>(nullable: true),
                    Codigo = table.Column<string>(nullable: true),
                    Consultas = table.Column<string>(nullable: true),
                    DocumentosEnPublicacion = table.Column<string>(nullable: true),
                    Estado = table.Column<string>(nullable: true),
                    FechaInicioVigencia = table.Column<string>(nullable: true),
                    FechaPublicacion = table.Column<string>(nullable: true),
                    FinVigencia = table.Column<string>(nullable: true),
                    FuncionamientoAnterior = table.Column<string>(nullable: true),
                    FuncionamientoNuevo = table.Column<string>(nullable: true),
                    Gerencia = table.Column<string>(nullable: true),
                    Impacto = table.Column<string>(nullable: true),
                    Intervinientes = table.Column<string>(nullable: true),
                    Materia = table.Column<string>(nullable: true),
                    NombreDocumento = table.Column<string>(nullable: true),
                    Responsable = table.Column<string>(nullable: true),
                    Restricciones = table.Column<string>(nullable: true),
                    Solicitud = table.Column<long>(nullable: false),
                    Tipo = table.Column<string>(nullable: true),
                    Unidad = table.Column<string>(nullable: true),
                    VersionDocumento = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ReportePublicacionItem", x => x.Id);
                });
            migrationBuilder.CreateTable(
                name: "ReporteSolicitudItem",
                columns: table => new
                {
                    Solicitud = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Analista = table.Column<string>(nullable: true),
                    Area = table.Column<string>(nullable: true),
                    CodigoDocumento = table.Column<string>(nullable: true),
                    Destino = table.Column<string>(nullable: true),
                    Estado = table.Column<string>(nullable: true),
                    FechaAceptacionVB = table.Column<DateTime>(nullable: true),
                    FechaBorrador = table.Column<DateTime>(nullable: true),
                    FechaSolicitud = table.Column<DateTime>(nullable: true),
                    FechaSolicitudVB = table.Column<DateTime>(nullable: true),
                    FechaSolicitudVB2 = table.Column<DateTime>(nullable: true),
                    FechaSolicitudVB3 = table.Column<DateTime>(nullable: true),
                    Gerencia = table.Column<string>(nullable: true),
                    Materia = table.Column<string>(nullable: true),
                    NombreDocumento = table.Column<string>(nullable: true),
                    Solicitante = table.Column<string>(nullable: true),
                    Tipo = table.Column<string>(nullable: true),
                    Unidad = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ReporteSolicitudItem", x => x.Solicitud);
                });
            migrationBuilder.CreateTable(
                name: "Seccion",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Cuerpo = table.Column<string>(nullable: true),
                    Titulo = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Seccion", x => x.Id);
                });
            migrationBuilder.CreateTable(
                name: "Area",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false),
                    FechaCreacion = table.Column<DateTime>(nullable: false, defaultValueSql: "getdate()"),
                    FechaEliminacion = table.Column<DateTime>(nullable: true),
                    GerenciaId = table.Column<int>(nullable: true),
                    Nombre = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Area", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Area_Gerencia_GerenciaId",
                        column: x => x.GerenciaId,
                        principalTable: "Gerencia",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });
            migrationBuilder.CreateTable(
                name: "Unidad",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false),
                    AreaId = table.Column<int>(nullable: true),
                    FechaCreacion = table.Column<DateTime>(nullable: false, defaultValueSql: "getdate()"),
                    FechaEliminacion = table.Column<DateTime>(nullable: true),
                    Nombre = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Unidad", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Unidad_Area_AreaId",
                        column: x => x.AreaId,
                        principalTable: "Area",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });
            migrationBuilder.CreateTable(
                name: "UsuarioIntranet",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false),
                    Activo = table.Column<bool>(nullable: false),
                    AnalistaNYP = table.Column<bool>(nullable: false),
                    ApellidoMaterno = table.Column<string>(nullable: true),
                    ApellidoPaterno = table.Column<string>(nullable: true),
                    Cargo = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    Nombres = table.Column<string>(nullable: true),
                    UnidadId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UsuarioIntranet", x => x.Id);
                    table.ForeignKey(
                        name: "FK_UsuarioIntranet_Unidad_UnidadId",
                        column: x => x.UnidadId,
                        principalTable: "Unidad",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });
            migrationBuilder.CreateTable(
                name: "EventoConfiguracion",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AutorId = table.Column<int>(nullable: true),
                    Descripcion = table.Column<string>(nullable: true),
                    Fecha = table.Column<DateTime>(nullable: false),
                    ListaDistribucionId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EventoConfiguracion", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EventoConfiguracion_UsuarioIntranet_AutorId",
                        column: x => x.AutorId,
                        principalTable: "UsuarioIntranet",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_EventoConfiguracion_ListaDistribucion_ListaDistribucionId",
                        column: x => x.ListaDistribucionId,
                        principalTable: "ListaDistribucion",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });
            migrationBuilder.CreateTable(
                name: "PaginaContenidos",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AutorId = table.Column<int>(nullable: true),
                    Contenido = table.Column<string>(nullable: true),
                    FechaPublicacion = table.Column<DateTime>(nullable: false),
                    Titulo = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PaginaContenidos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PaginaContenidos_UsuarioIntranet_AutorId",
                        column: x => x.AutorId,
                        principalTable: "UsuarioIntranet",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });
            migrationBuilder.CreateTable(
                name: "Solicitud",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AnalistaId = table.Column<int>(nullable: true),
                    CodigoDocumento = table.Column<string>(nullable: true),
                    Consultas = table.Column<string>(nullable: true),
                    Destino = table.Column<string>(nullable: true),
                    Estado = table.Column<string>(nullable: true),
                    FechaBorrador = table.Column<DateTime>(nullable: false),
                    FechaIngreso = table.Column<DateTime>(nullable: true),
                    FechaInicioVigencia = table.Column<DateTime>(nullable: true),
                    FechaOK = table.Column<DateTime>(nullable: false),
                    FechaSolicitud = table.Column<DateTime>(nullable: true),
                    FechaSolicitudVB = table.Column<DateTime>(nullable: true),
                    FechaSolicitudVB2 = table.Column<DateTime>(nullable: true),
                    FechaSolicitudVB3 = table.Column<DateTime>(nullable: true),
                    FuncionamientoActual = table.Column<string>(nullable: true),
                    FuncionamientoNuevo = table.Column<string>(nullable: true),
                    Impacto = table.Column<string>(nullable: true),
                    Materia = table.Column<string>(nullable: true),
                    Objetivo = table.Column<string>(nullable: true),
                    SolicitanteId = table.Column<int>(nullable: true),
                    Tipo = table.Column<string>(nullable: true),
                    Titulo = table.Column<string>(nullable: true),
                    UnidadId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Solicitud", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Solicitud_UsuarioIntranet_AnalistaId",
                        column: x => x.AnalistaId,
                        principalTable: "UsuarioIntranet",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Solicitud_UsuarioIntranet_SolicitanteId",
                        column: x => x.SolicitanteId,
                        principalTable: "UsuarioIntranet",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Solicitud_Unidad_UnidadId",
                        column: x => x.UnidadId,
                        principalTable: "Unidad",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });
            migrationBuilder.CreateTable(
                name: "UsuarioConsulta",
                columns: table => new
                {
                    UsuarioIntranetId = table.Column<int>(nullable: false),
                    CircularId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UsuarioConsulta", x => new { x.UsuarioIntranetId, x.CircularId });
                    table.ForeignKey(
                        name: "FK_UsuarioConsulta_Circular_CircularId",
                        column: x => x.CircularId,
                        principalTable: "Circular",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_UsuarioConsulta_UsuarioIntranet_UsuarioIntranetId",
                        column: x => x.UsuarioIntranetId,
                        principalTable: "UsuarioIntranet",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });
            migrationBuilder.CreateTable(
                name: "UsuariosEnListaDistribucion",
                columns: table => new
                {
                    ListaDistribucionId = table.Column<int>(nullable: false),
                    UsuarioIntranetId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UsuariosEnListaDistribucion", x => new { x.ListaDistribucionId, x.UsuarioIntranetId });
                    table.ForeignKey(
                        name: "FK_UsuariosEnListaDistribucion_ListaDistribucion_ListaDistribucionId",
                        column: x => x.ListaDistribucionId,
                        principalTable: "ListaDistribucion",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_UsuariosEnListaDistribucion_UsuarioIntranet_UsuarioIntranetId",
                        column: x => x.UsuarioIntranetId,
                        principalTable: "UsuarioIntranet",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });
            migrationBuilder.CreateTable(
                name: "AutorizacionSolicitud",
                columns: table => new
                {
                    UsuarioIntranetId = table.Column<int>(nullable: false),
                    SolicitudId = table.Column<long>(nullable: false),
                    Estado = table.Column<string>(nullable: true),
                    FechaModificacion = table.Column<DateTime>(nullable: false),
                    Observaciones = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AutorizacionSolicitud", x => new { x.UsuarioIntranetId, x.SolicitudId });
                    table.ForeignKey(
                        name: "FK_AutorizacionSolicitud_Solicitud_SolicitudId",
                        column: x => x.SolicitudId,
                        principalTable: "Solicitud",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AutorizacionSolicitud_UsuarioIntranet_UsuarioIntranetId",
                        column: x => x.UsuarioIntranetId,
                        principalTable: "UsuarioIntranet",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });
            migrationBuilder.CreateTable(
                name: "Evento",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AutorId = table.Column<int>(nullable: true),
                    Campo = table.Column<string>(nullable: true),
                    Fecha = table.Column<DateTime>(nullable: false),
                    SolicitudId = table.Column<long>(nullable: true),
                    Titulo = table.Column<string>(nullable: true),
                    ValorAnterior = table.Column<string>(nullable: true),
                    ValorNuevo = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Evento", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Evento_UsuarioIntranet_AutorId",
                        column: x => x.AutorId,
                        principalTable: "UsuarioIntranet",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Evento_Solicitud_SolicitudId",
                        column: x => x.SolicitudId,
                        principalTable: "Solicitud",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });
            migrationBuilder.CreateTable(
                name: "Nota",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AutorId = table.Column<int>(nullable: false),
                    Fecha = table.Column<DateTime>(nullable: false),
                    Privada = table.Column<bool>(nullable: false),
                    SolicitudId = table.Column<long>(nullable: false),
                    Texto = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Nota", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Nota_UsuarioIntranet_AutorId",
                        column: x => x.AutorId,
                        principalTable: "UsuarioIntranet",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Nota_Solicitud_SolicitudId",
                        column: x => x.SolicitudId,
                        principalTable: "Solicitud",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });
            migrationBuilder.CreateTable(
                name: "Publicacion",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Area = table.Column<string>(nullable: true),
                    AreasImpactadas = table.Column<string>(nullable: true),
                    CircularId = table.Column<int>(nullable: true),
                    Codigo = table.Column<string>(nullable: true),
                    Consultas = table.Column<string>(nullable: true),
                    Division = table.Column<string>(nullable: true),
                    Estado = table.Column<string>(nullable: true),
                    FechaCertificacion = table.Column<DateTime>(nullable: false),
                    FechaPublicacion = table.Column<DateTime>(nullable: false),
                    FinVigencia = table.Column<DateTime>(nullable: false),
                    FuncionamientoAnterior = table.Column<string>(nullable: true),
                    FuncionamientoNuevo = table.Column<string>(nullable: true),
                    Impacto = table.Column<string>(nullable: true),
                    InicioVigencia = table.Column<DateTime>(nullable: false),
                    Intervinientes = table.Column<string>(nullable: true),
                    Motivo = table.Column<string>(nullable: true),
                    NombreDocumento = table.Column<string>(nullable: true),
                    ResponsableId = table.Column<int>(nullable: true),
                    SolicitudId = table.Column<long>(nullable: false),
                    Tipo = table.Column<string>(nullable: true),
                    Unidad = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Publicacion", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Publicacion_Circular_CircularId",
                        column: x => x.CircularId,
                        principalTable: "Circular",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Publicacion_UsuarioIntranet_ResponsableId",
                        column: x => x.ResponsableId,
                        principalTable: "UsuarioIntranet",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Publicacion_Solicitud_SolicitudId",
                        column: x => x.SolicitudId,
                        principalTable: "Solicitud",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });
            migrationBuilder.CreateTable(
                name: "CambioEnPublicacion",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Anterior = table.Column<string>(nullable: true),
                    CircularId = table.Column<int>(nullable: true),
                    Nuevo = table.Column<string>(nullable: true),
                    PublicacionId = table.Column<long>(nullable: true),
                    SolicitudId = table.Column<long>(nullable: true),
                    Titulo = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CambioEnPublicacion", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CambioEnPublicacion_Circular_CircularId",
                        column: x => x.CircularId,
                        principalTable: "Circular",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CambioEnPublicacion_Publicacion_PublicacionId",
                        column: x => x.PublicacionId,
                        principalTable: "Publicacion",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CambioEnPublicacion_Solicitud_SolicitudId",
                        column: x => x.SolicitudId,
                        principalTable: "Solicitud",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });
            migrationBuilder.CreateTable(
                name: "CategoriasEnPublicacion",
                columns: table => new
                {
                    CategoriaId = table.Column<long>(nullable: false),
                    PublicacionId = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CategoriasEnPublicacion", x => new { x.CategoriaId, x.PublicacionId });
                    table.ForeignKey(
                        name: "FK_CategoriasEnPublicacion_Categoria_CategoriaId",
                        column: x => x.CategoriaId,
                        principalTable: "Categoria",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_CategoriasEnPublicacion_Publicacion_PublicacionId",
                        column: x => x.PublicacionId,
                        principalTable: "Publicacion",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });
            migrationBuilder.CreateTable(
                name: "EstadisticaPublicacion",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Fecha = table.Column<DateTime>(nullable: false),
                    PublicacionId = table.Column<long>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EstadisticaPublicacion", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EstadisticaPublicacion_Publicacion_PublicacionId",
                        column: x => x.PublicacionId,
                        principalTable: "Publicacion",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });
            migrationBuilder.CreateTable(
                name: "ProcesoCertificacion",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AnalistaEjecutorId = table.Column<int>(nullable: false),
                    AreaAnterior = table.Column<string>(nullable: true),
                    Comentarios = table.Column<string>(nullable: true),
                    FechaProceso = table.Column<DateTime>(nullable: false),
                    GerenciaAnterior = table.Column<string>(nullable: true),
                    PublicacionId = table.Column<long>(nullable: false),
                    ResponsableAnteriorId = table.Column<int>(nullable: false),
                    ResponsableNuevoId = table.Column<int>(nullable: false),
                    UnidadAnterior = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProcesoCertificacion", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProcesoCertificacion_UsuarioIntranet_AnalistaEjecutorId",
                        column: x => x.AnalistaEjecutorId,
                        principalTable: "UsuarioIntranet",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProcesoCertificacion_Publicacion_PublicacionId",
                        column: x => x.PublicacionId,
                        principalTable: "Publicacion",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });
            migrationBuilder.CreateTable(
                name: "Restriccion",
                columns: table => new
                {
                    RestriccionId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AreaId = table.Column<int>(nullable: true),
                    DescRegla = table.Column<string>(nullable: true),
                    GerenciaId = table.Column<int>(nullable: false),
                    PublicacionId = table.Column<long>(nullable: true),
                    SolicitudId = table.Column<long>(nullable: false),
                    UnidadId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Restriccion", x => x.RestriccionId);
                    table.ForeignKey(
                        name: "FK_Restriccion_Area_AreaId",
                        column: x => x.AreaId,
                        principalTable: "Area",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Restriccion_Gerencia_GerenciaId",
                        column: x => x.GerenciaId,
                        principalTable: "Gerencia",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Restriccion_Publicacion_PublicacionId",
                        column: x => x.PublicacionId,
                        principalTable: "Publicacion",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Restriccion_Solicitud_SolicitudId",
                        column: x => x.SolicitudId,
                        principalTable: "Solicitud",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Restriccion_Unidad_UnidadId",
                        column: x => x.UnidadId,
                        principalTable: "Unidad",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });
            migrationBuilder.CreateTable(
                name: "Documento",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Codigo = table.Column<string>(nullable: true),
                    FechaCertificacion = table.Column<DateTime>(nullable: false),
                    FechaPublicacion = table.Column<DateTime>(nullable: false),
                    GestorDocumentalId = table.Column<string>(nullable: true),
                    NombreArchivo = table.Column<string>(nullable: false),
                    NombreDocumento = table.Column<string>(nullable: false),
                    ProcesoCertificacionId = table.Column<int>(nullable: true),
                    PublicacionId = table.Column<long>(nullable: false),
                    Version = table.Column<int>(nullable: false, defaultValue: 0),
                    Vigente = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Documento", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Documento_ProcesoCertificacion_ProcesoCertificacionId",
                        column: x => x.ProcesoCertificacionId,
                        principalTable: "ProcesoCertificacion",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Documento_Publicacion_PublicacionId",
                        column: x => x.PublicacionId,
                        principalTable: "Publicacion",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });
            migrationBuilder.CreateTable(
                name: "ExclusionUsuario",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    RestriccionRestriccionId = table.Column<int>(nullable: false),
                    UsuarioIntranetId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ExclusionUsuario", x => x.ID);
                    table.ForeignKey(
                        name: "FK_ExclusionUsuario_Restriccion_RestriccionRestriccionId",
                        column: x => x.RestriccionRestriccionId,
                        principalTable: "Restriccion",
                        principalColumn: "RestriccionId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ExclusionUsuario_UsuarioIntranet_UsuarioIntranetId",
                        column: x => x.UsuarioIntranetId,
                        principalTable: "UsuarioIntranet",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });
            migrationBuilder.CreateTable(
                name: "DocumentosEnPublicacion",
                columns: table => new
                {
                    DocumentoId = table.Column<long>(nullable: false),
                    PublicacionId = table.Column<long>(nullable: false),
                    Referencia = table.Column<bool>(nullable: false),
                    ReferenciaId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DocumentosEnPublicacion", x => new { x.DocumentoId, x.PublicacionId });
                    table.ForeignKey(
                        name: "FK_DocumentosEnPublicacion_Documento_DocumentoId",
                        column: x => x.DocumentoId,
                        principalTable: "Documento",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DocumentosEnPublicacion_Publicacion_PublicacionId",
                        column: x => x.PublicacionId,
                        principalTable: "Publicacion",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });
            migrationBuilder.CreateTable(
                name: "DocumentosExistentesEnSolicitud",
                columns: table => new
                {
                    DocumentoId = table.Column<long>(nullable: false),
                    SolicitudId = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DocumentosExistentesEnSolicitud", x => new { x.DocumentoId, x.SolicitudId });
                    table.ForeignKey(
                        name: "FK_DocumentosExistentesEnSolicitud_Documento_DocumentoId",
                        column: x => x.DocumentoId,
                        principalTable: "Documento",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });
            migrationBuilder.CreateTable(
                name: "EstadisticaDocumento",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    DocumentoId = table.Column<long>(nullable: false),
                    Fecha = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EstadisticaDocumento", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EstadisticaDocumento_Documento_DocumentoId",
                        column: x => x.DocumentoId,
                        principalTable: "Documento",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });
            migrationBuilder.CreateTable(
                name: "EventoDocumento",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AutorId = table.Column<int>(nullable: true),
                    Descripcion = table.Column<string>(nullable: true),
                    DocumentoId = table.Column<long>(nullable: true),
                    Fecha = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EventoDocumento", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EventoDocumento_UsuarioIntranet_AutorId",
                        column: x => x.AutorId,
                        principalTable: "UsuarioIntranet",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_EventoDocumento_Documento_DocumentoId",
                        column: x => x.DocumentoId,
                        principalTable: "Documento",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable("Archivo");
            migrationBuilder.DropTable("ArchivosEnSolicitud");
            migrationBuilder.DropTable("AutorizacionSolicitud");
            migrationBuilder.DropTable("CambioEnPublicacion");
            migrationBuilder.DropTable("CategoriasEnPublicacion");
            migrationBuilder.DropTable("CodigoGlosa");
            migrationBuilder.DropTable("DocumentosEnPublicacion");
            migrationBuilder.DropTable("DocumentosExistentesEnSolicitud");
            migrationBuilder.DropTable("DocumentosMasVisitados");
            migrationBuilder.DropTable("EstadisticaDocumento");
            migrationBuilder.DropTable("EstadisticaPublicacion");
            migrationBuilder.DropTable("Evento");
            migrationBuilder.DropTable("EventoConfiguracion");
            migrationBuilder.DropTable("EventoDocumento");
            migrationBuilder.DropTable("ExclusionUsuario");
            migrationBuilder.DropTable("Nota");
            migrationBuilder.DropTable("Noticia");
            migrationBuilder.DropTable("PaginaContenidos");
            migrationBuilder.DropTable("PropiedadConfiguracion");
            migrationBuilder.DropTable("PublicacionesMasVisitadas");
            migrationBuilder.DropTable("ReporteCertificacionItem");
            migrationBuilder.DropTable("ReportePublicacionItem");
            migrationBuilder.DropTable("ReporteSolicitudItem");
            migrationBuilder.DropTable("Seccion");
            migrationBuilder.DropTable("UsuarioConsulta");
            migrationBuilder.DropTable("UsuariosEnListaDistribucion");
            migrationBuilder.DropTable("Categoria");
            migrationBuilder.DropTable("Documento");
            migrationBuilder.DropTable("Restriccion");
            migrationBuilder.DropTable("ListaDistribucion");
            migrationBuilder.DropTable("ProcesoCertificacion");
            migrationBuilder.DropTable("Publicacion");
            migrationBuilder.DropTable("Circular");
            migrationBuilder.DropTable("Solicitud");
            migrationBuilder.DropTable("UsuarioIntranet");
            migrationBuilder.DropTable("Unidad");
            migrationBuilder.DropTable("Area");
            migrationBuilder.DropTable("Gerencia");
        }
    }
}
