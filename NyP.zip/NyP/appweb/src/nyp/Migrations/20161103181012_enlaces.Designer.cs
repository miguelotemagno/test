using System;
using Microsoft.Data.Entity;
using Microsoft.Data.Entity.Infrastructure;
using Microsoft.Data.Entity.Metadata;
using Microsoft.Data.Entity.Migrations;
using nyp.DataModels;

namespace nyp.Migrations
{
    [DbContext(typeof(NYPContext))]
    [Migration("20161103181012_enlaces")]
    partial class enlaces
    {
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("ProductVersion", "7.0.0-rc1-16348")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("nyp.DataModels.Archivo", b =>
                {
                    b.Property<long>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("CodigoDocumento")
                        .IsRequired();

                    b.Property<string>("NombreArchivoOriginal")
                        .IsRequired();

                    b.Property<string>("NombreFisico")
                        .IsRequired();

                    b.Property<string>("Tipo")
                        .IsRequired();

                    b.Property<string>("TituloDocumento")
                        .IsRequired();

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.ArchivosEnSolicitud", b =>
                {
                    b.Property<long>("ArchivoId");

                    b.Property<long>("SolicitudId");

                    b.HasKey("ArchivoId", "SolicitudId");
                });

            modelBuilder.Entity("nyp.DataModels.Area", b =>
                {
                    b.Property<int>("Id");

                    b.Property<DateTime>("FechaCreacion")
                        .ValueGeneratedOnAdd()
                        .HasAnnotation("Relational:GeneratedValueSql", "getdate()");

                    b.Property<DateTime?>("FechaEliminacion");

                    b.Property<int?>("GerenciaId");

                    b.Property<string>("Nombre");

                    b.Property<bool>("Revision");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.AutorizacionSolicitud", b =>
                {
                    b.Property<int>("UsuarioIntranetId");

                    b.Property<long>("SolicitudId");

                    b.Property<string>("Estado");

                    b.Property<DateTime>("FechaModificacion");

                    b.Property<string>("Observaciones");

                    b.HasKey("UsuarioIntranetId", "SolicitudId");
                });

            modelBuilder.Entity("nyp.DataModels.CambioEnPublicacion", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Anterior");

                    b.Property<int?>("CircularId");

                    b.Property<string>("Nuevo");

                    b.Property<long?>("PublicacionId");

                    b.Property<long?>("SolicitudId");

                    b.Property<string>("Titulo");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.Categoria", b =>
                {
                    b.Property<long>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<long?>("CategoriaId");

                    b.Property<string>("Descripcion");

                    b.Property<string>("Nombre");

                    b.Property<int>("Orden");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.CategoriasEnPublicacion", b =>
                {
                    b.Property<long>("CategoriaId");

                    b.Property<long>("PublicacionId");

                    b.HasKey("CategoriaId", "PublicacionId");
                });

            modelBuilder.Entity("nyp.DataModels.Circular", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Consultas");

                    b.Property<string>("Destino");

                    b.Property<DateTime>("FinVigencia");

                    b.Property<string>("FuncionamientoActual");

                    b.Property<string>("FuncionamientoNuevo");

                    b.Property<DateTime>("InicioVigencia");

                    b.Property<string>("Materia");

                    b.Property<string>("Objetivo");

                    b.Property<string>("Responsable");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.CodigoGlosa", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("CodigoDocumento");

                    b.Property<string>("NombreDocumento");

                    b.Property<bool>("Vigente");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.Documento", b =>
                {
                    b.Property<long>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Codigo");

                    b.Property<DateTime>("FechaCertificacion");

                    b.Property<DateTime>("FechaPublicacion");

                    b.Property<string>("GestorDocumentalId");

                    b.Property<string>("NombreArchivo")
                        .IsRequired();

                    b.Property<string>("NombreDocumento")
                        .IsRequired();

                    b.Property<int?>("ProcesoCertificacionId");

                    b.Property<long?>("PublicacionId")
                        .IsRequired();

                    b.Property<int>("Version")
                        .HasAnnotation("Relational:DefaultValue", "0")
                        .HasAnnotation("Relational:DefaultValueType", "System.Int32");

                    b.Property<bool>("Vigente");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.DocumentosEnPublicacion", b =>
                {
                    b.Property<long>("DocumentoId");

                    b.Property<long>("PublicacionId");

                    b.Property<bool>("Referencia");

                    b.Property<int?>("ReferenciaId");

                    b.HasKey("DocumentoId", "PublicacionId");
                });

            modelBuilder.Entity("nyp.DataModels.DocumentosExistentesEnSolicitud", b =>
                {
                    b.Property<long>("DocumentoId");

                    b.Property<long>("SolicitudId");

                    b.HasKey("DocumentoId", "SolicitudId");
                });

            modelBuilder.Entity("nyp.DataModels.DocumentosMasVisitados", b =>
                {
                    b.Property<long>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("Cantidad");

                    b.Property<string>("GestorDocumentalId");

                    b.Property<string>("NombreArchivo");

                    b.Property<string>("NombreDocumento");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.EnlacesCategoria", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<long?>("CategoriaId");

                    b.Property<string>("Hipervinculo");

                    b.Property<string>("Titulo");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.EstadisticaDocumento", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<long>("DocumentoId");

                    b.Property<DateTime>("Fecha");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.EstadisticaPublicacion", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<DateTime>("Fecha");

                    b.Property<long?>("PublicacionId");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.Evento", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<int?>("AutorId");

                    b.Property<string>("Campo");

                    b.Property<DateTime>("Fecha");

                    b.Property<long?>("SolicitudId");

                    b.Property<string>("Titulo");

                    b.Property<string>("ValorAnterior");

                    b.Property<string>("ValorNuevo");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.EventoConfiguracion", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<int?>("AutorId");

                    b.Property<string>("Descripcion");

                    b.Property<DateTime>("Fecha");

                    b.Property<int?>("ListaDistribucionId");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.EventoDocumento", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<int?>("AutorId");

                    b.Property<string>("Descripcion");

                    b.Property<long?>("DocumentoId");

                    b.Property<DateTime>("Fecha");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.ExclusionUsuario", b =>
                {
                    b.Property<int>("ID")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("RestriccionRestriccionId");

                    b.Property<int>("UsuarioIntranetId");

                    b.HasKey("ID");
                });

            modelBuilder.Entity("nyp.DataModels.Gerencia", b =>
                {
                    b.Property<int>("Id");

                    b.Property<DateTime>("FechaCreacion")
                        .ValueGeneratedOnAdd()
                        .HasAnnotation("Relational:GeneratedValueSql", "getdate()");

                    b.Property<DateTime?>("FechaEliminacion");

                    b.Property<string>("Nombre");

                    b.Property<bool>("Revision");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.ListaDistribucion", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Nombre");

                    b.Property<string>("Notas");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.Nota", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("AutorId");

                    b.Property<DateTime>("Fecha");

                    b.Property<bool>("Privada");

                    b.Property<long>("SolicitudId");

                    b.Property<string>("Texto");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.Noticia", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Autor");

                    b.Property<string>("Cuerpo");

                    b.Property<DateTime>("Fecha");

                    b.Property<string>("Titulo");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.PaginaContenidos", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<int?>("AutorId");

                    b.Property<string>("Contenido");

                    b.Property<DateTime>("FechaPublicacion");

                    b.Property<string>("Titulo");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.ProcesoCertificacion", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("AnalistaEjecutorId");

                    b.Property<string>("AreaAnterior");

                    b.Property<string>("Comentarios");

                    b.Property<DateTime>("FechaProceso");

                    b.Property<string>("GerenciaAnterior");

                    b.Property<long>("PublicacionId");

                    b.Property<int>("ResponsableAnteriorId");

                    b.Property<int>("ResponsableNuevoId");

                    b.Property<string>("UnidadAnterior");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.PropiedadConfiguracion", b =>
                {
                    b.Property<string>("Id");

                    b.Property<string>("Valor");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.Publicacion", b =>
                {
                    b.Property<long>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Area");

                    b.Property<string>("AreasImpactadas");

                    b.Property<int?>("CircularId");

                    b.Property<string>("Codigo");

                    b.Property<string>("Consultas");

                    b.Property<string>("Division");

                    b.Property<string>("Estado");

                    b.Property<DateTime>("FechaCertificacion");

                    b.Property<DateTime>("FechaPublicacion");

                    b.Property<DateTime>("FinVigencia");

                    b.Property<string>("FuncionamientoAnterior");

                    b.Property<string>("FuncionamientoNuevo");

                    b.Property<string>("Impacto");

                    b.Property<DateTime>("InicioVigencia");

                    b.Property<string>("Intervinientes");

                    b.Property<string>("Motivo");

                    b.Property<string>("NivelAcceso");

                    b.Property<string>("NombreDocumento");

                    b.Property<int?>("ResponsableId");

                    b.Property<long>("SolicitudId");

                    b.Property<string>("Tipo");

                    b.Property<string>("Unidad");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.PublicacionesMasVisitadas", b =>
                {
                    b.Property<long>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("Cantidad");

                    b.Property<string>("Codigo");

                    b.Property<DateTime>("FechaPublicacion");

                    b.Property<string>("NombreDocumento");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.ReporteCertificacionItem", b =>
                {
                    b.Property<long>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("AnalistaEjecutor");

                    b.Property<string>("Area");

                    b.Property<string>("AreaAnterior");

                    b.Property<string>("Codigo");

                    b.Property<string>("Comentarios");

                    b.Property<string>("FechaCertificacion");

                    b.Property<string>("FechaCreacion");

                    b.Property<string>("FechaProceso");

                    b.Property<string>("FechaPublicacion");

                    b.Property<string>("Gerencia");

                    b.Property<string>("GerenciaAnterior");

                    b.Property<string>("NombreDocumento");

                    b.Property<string>("ResponsableActual");

                    b.Property<string>("ResponsableAnterior");

                    b.Property<string>("Tipo");

                    b.Property<string>("Unidad");

                    b.Property<string>("UnidadAnterior");

                    b.Property<int>("Version");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.ReportePublicacionItem", b =>
                {
                    b.Property<long>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Analista");

                    b.Property<string>("Area");

                    b.Property<string>("AreasImpactadas");

                    b.Property<string>("CategoriasEnPublicacion");

                    b.Property<int?>("Circular");

                    b.Property<string>("Codigo");

                    b.Property<string>("Consultas");

                    b.Property<string>("DocumentosEnPublicacion");

                    b.Property<string>("Estado");

                    b.Property<string>("FechaInicioVigencia");

                    b.Property<string>("FechaPublicacion");

                    b.Property<string>("FinVigencia");

                    b.Property<string>("FuncionamientoAnterior");

                    b.Property<string>("FuncionamientoNuevo");

                    b.Property<string>("Gerencia");

                    b.Property<string>("Impacto");

                    b.Property<string>("Intervinientes");

                    b.Property<string>("Materia");

                    b.Property<string>("NombreDocumento");

                    b.Property<string>("Responsable");

                    b.Property<string>("Restricciones");

                    b.Property<long>("Solicitud");

                    b.Property<string>("Tipo");

                    b.Property<string>("Unidad");

                    b.Property<int>("VersionDocumento");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.ReporteSolicitudItem", b =>
                {
                    b.Property<long>("Solicitud")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Analista");

                    b.Property<string>("Area");

                    b.Property<string>("CodigoDocumento");

                    b.Property<string>("Destino");

                    b.Property<string>("Estado");

                    b.Property<DateTime?>("FechaAceptacionVB");

                    b.Property<DateTime?>("FechaBorrador");

                    b.Property<DateTime?>("FechaSolicitud");

                    b.Property<DateTime?>("FechaSolicitudVB");

                    b.Property<DateTime?>("FechaSolicitudVB2");

                    b.Property<DateTime?>("FechaSolicitudVB3");

                    b.Property<string>("Gerencia");

                    b.Property<string>("Materia");

                    b.Property<string>("NombreDocumento");

                    b.Property<string>("Solicitante");

                    b.Property<string>("Tipo");

                    b.Property<string>("Unidad");

                    b.HasKey("Solicitud");
                });

            modelBuilder.Entity("nyp.DataModels.Restriccion", b =>
                {
                    b.Property<int>("RestriccionId")
                        .ValueGeneratedOnAdd();

                    b.Property<int?>("AreaId");

                    b.Property<string>("DescRegla");

                    b.Property<int>("GerenciaId");

                    b.Property<long?>("PublicacionId");

                    b.Property<long>("SolicitudId");

                    b.Property<int?>("UnidadId");

                    b.HasKey("RestriccionId");
                });

            modelBuilder.Entity("nyp.DataModels.Seccion", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Cuerpo");

                    b.Property<string>("Titulo");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.Solicitud", b =>
                {
                    b.Property<long>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<int?>("AnalistaId");

                    b.Property<string>("CodigoDocumento");

                    b.Property<string>("Consultas");

                    b.Property<string>("Destino");

                    b.Property<string>("Estado");

                    b.Property<DateTime>("FechaBorrador");

                    b.Property<DateTime?>("FechaIngreso");

                    b.Property<DateTime?>("FechaInicioVigencia");

                    b.Property<DateTime>("FechaOK");

                    b.Property<DateTime?>("FechaSolicitud");

                    b.Property<DateTime?>("FechaSolicitudVB");

                    b.Property<DateTime?>("FechaSolicitudVB2");

                    b.Property<DateTime?>("FechaSolicitudVB3");

                    b.Property<string>("FuncionamientoActual")
                        .HasAnnotation("MaxLength", 1024);

                    b.Property<string>("FuncionamientoNuevo")
                        .HasAnnotation("MaxLength", 1024);

                    b.Property<string>("Impacto")
                        .HasAnnotation("MaxLength", 300);

                    b.Property<string>("Materia");

                    b.Property<string>("Motivo");

                    b.Property<string>("Objetivo");

                    b.Property<int?>("SolicitanteId");

                    b.Property<string>("Tipo");

                    b.Property<string>("Titulo");

                    b.Property<int?>("UnidadId");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.Unidad", b =>
                {
                    b.Property<int>("Id");

                    b.Property<int?>("AreaId");

                    b.Property<DateTime>("FechaCreacion")
                        .ValueGeneratedOnAdd()
                        .HasAnnotation("Relational:GeneratedValueSql", "getdate()");

                    b.Property<DateTime?>("FechaEliminacion");

                    b.Property<string>("Nombre");

                    b.Property<bool>("Revision");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.UsuarioConsulta", b =>
                {
                    b.Property<int>("UsuarioIntranetId");

                    b.Property<int>("CircularId");

                    b.HasKey("UsuarioIntranetId", "CircularId");
                });

            modelBuilder.Entity("nyp.DataModels.UsuarioIntranet", b =>
                {
                    b.Property<int>("Id");

                    b.Property<bool>("Activo");

                    b.Property<bool>("AnalistaNYP");

                    b.Property<string>("ApellidoMaterno");

                    b.Property<string>("ApellidoPaterno");

                    b.Property<string>("Cargo");

                    b.Property<string>("Email");

                    b.Property<string>("Nombres");

                    b.Property<bool>("Revision");

                    b.Property<int>("UnidadId");

                    b.HasKey("Id");
                });

            modelBuilder.Entity("nyp.DataModels.UsuariosEnListaDistribucion", b =>
                {
                    b.Property<int>("ListaDistribucionId");

                    b.Property<int>("UsuarioIntranetId");

                    b.HasKey("ListaDistribucionId", "UsuarioIntranetId");
                });

            modelBuilder.Entity("nyp.DataModels.Area", b =>
                {
                    b.HasOne("nyp.DataModels.Gerencia")
                        .WithMany()
                        .HasForeignKey("GerenciaId");
                });

            modelBuilder.Entity("nyp.DataModels.AutorizacionSolicitud", b =>
                {
                    b.HasOne("nyp.DataModels.Solicitud")
                        .WithMany()
                        .HasForeignKey("SolicitudId");

                    b.HasOne("nyp.DataModels.UsuarioIntranet")
                        .WithMany()
                        .HasForeignKey("UsuarioIntranetId");
                });

            modelBuilder.Entity("nyp.DataModels.CambioEnPublicacion", b =>
                {
                    b.HasOne("nyp.DataModels.Circular")
                        .WithMany()
                        .HasForeignKey("CircularId");

                    b.HasOne("nyp.DataModels.Publicacion")
                        .WithMany()
                        .HasForeignKey("PublicacionId");

                    b.HasOne("nyp.DataModels.Solicitud")
                        .WithMany()
                        .HasForeignKey("SolicitudId");
                });

            modelBuilder.Entity("nyp.DataModels.Categoria", b =>
                {
                    b.HasOne("nyp.DataModels.Categoria")
                        .WithMany()
                        .HasForeignKey("CategoriaId");
                });

            modelBuilder.Entity("nyp.DataModels.CategoriasEnPublicacion", b =>
                {
                    b.HasOne("nyp.DataModels.Categoria")
                        .WithMany()
                        .HasForeignKey("CategoriaId");

                    b.HasOne("nyp.DataModels.Publicacion")
                        .WithMany()
                        .HasForeignKey("PublicacionId");
                });

            modelBuilder.Entity("nyp.DataModels.Documento", b =>
                {
                    b.HasOne("nyp.DataModels.ProcesoCertificacion")
                        .WithMany()
                        .HasForeignKey("ProcesoCertificacionId");

                    b.HasOne("nyp.DataModels.Publicacion")
                        .WithMany()
                        .HasForeignKey("PublicacionId");
                });

            modelBuilder.Entity("nyp.DataModels.DocumentosEnPublicacion", b =>
                {
                    b.HasOne("nyp.DataModels.Documento")
                        .WithMany()
                        .HasForeignKey("DocumentoId");

                    b.HasOne("nyp.DataModels.Publicacion")
                        .WithMany()
                        .HasForeignKey("PublicacionId");
                });

            modelBuilder.Entity("nyp.DataModels.DocumentosExistentesEnSolicitud", b =>
                {
                    b.HasOne("nyp.DataModels.Documento")
                        .WithMany()
                        .HasForeignKey("DocumentoId");
                });

            modelBuilder.Entity("nyp.DataModels.EnlacesCategoria", b =>
                {
                    b.HasOne("nyp.DataModels.Categoria")
                        .WithMany()
                        .HasForeignKey("CategoriaId");
                });

            modelBuilder.Entity("nyp.DataModels.EstadisticaDocumento", b =>
                {
                    b.HasOne("nyp.DataModels.Documento")
                        .WithMany()
                        .HasForeignKey("DocumentoId");
                });

            modelBuilder.Entity("nyp.DataModels.EstadisticaPublicacion", b =>
                {
                    b.HasOne("nyp.DataModels.Publicacion")
                        .WithMany()
                        .HasForeignKey("PublicacionId");
                });

            modelBuilder.Entity("nyp.DataModels.Evento", b =>
                {
                    b.HasOne("nyp.DataModels.UsuarioIntranet")
                        .WithMany()
                        .HasForeignKey("AutorId");

                    b.HasOne("nyp.DataModels.Solicitud")
                        .WithMany()
                        .HasForeignKey("SolicitudId");
                });

            modelBuilder.Entity("nyp.DataModels.EventoConfiguracion", b =>
                {
                    b.HasOne("nyp.DataModels.UsuarioIntranet")
                        .WithMany()
                        .HasForeignKey("AutorId");

                    b.HasOne("nyp.DataModels.ListaDistribucion")
                        .WithMany()
                        .HasForeignKey("ListaDistribucionId");
                });

            modelBuilder.Entity("nyp.DataModels.EventoDocumento", b =>
                {
                    b.HasOne("nyp.DataModels.UsuarioIntranet")
                        .WithMany()
                        .HasForeignKey("AutorId");

                    b.HasOne("nyp.DataModels.Documento")
                        .WithMany()
                        .HasForeignKey("DocumentoId");
                });

            modelBuilder.Entity("nyp.DataModels.ExclusionUsuario", b =>
                {
                    b.HasOne("nyp.DataModels.Restriccion")
                        .WithMany()
                        .HasForeignKey("RestriccionRestriccionId");

                    b.HasOne("nyp.DataModels.UsuarioIntranet")
                        .WithMany()
                        .HasForeignKey("UsuarioIntranetId");
                });

            modelBuilder.Entity("nyp.DataModels.Nota", b =>
                {
                    b.HasOne("nyp.DataModels.UsuarioIntranet")
                        .WithMany()
                        .HasForeignKey("AutorId");

                    b.HasOne("nyp.DataModels.Solicitud")
                        .WithMany()
                        .HasForeignKey("SolicitudId");
                });

            modelBuilder.Entity("nyp.DataModels.PaginaContenidos", b =>
                {
                    b.HasOne("nyp.DataModels.UsuarioIntranet")
                        .WithMany()
                        .HasForeignKey("AutorId");
                });

            modelBuilder.Entity("nyp.DataModels.ProcesoCertificacion", b =>
                {
                    b.HasOne("nyp.DataModels.UsuarioIntranet")
                        .WithMany()
                        .HasForeignKey("AnalistaEjecutorId");

                    b.HasOne("nyp.DataModels.Publicacion")
                        .WithMany()
                        .HasForeignKey("PublicacionId");
                });

            modelBuilder.Entity("nyp.DataModels.Publicacion", b =>
                {
                    b.HasOne("nyp.DataModels.Circular")
                        .WithMany()
                        .HasForeignKey("CircularId");

                    b.HasOne("nyp.DataModels.UsuarioIntranet")
                        .WithMany()
                        .HasForeignKey("ResponsableId");

                    b.HasOne("nyp.DataModels.Solicitud")
                        .WithMany()
                        .HasForeignKey("SolicitudId");
                });

            modelBuilder.Entity("nyp.DataModels.Restriccion", b =>
                {
                    b.HasOne("nyp.DataModels.Area")
                        .WithMany()
                        .HasForeignKey("AreaId");

                    b.HasOne("nyp.DataModels.Gerencia")
                        .WithMany()
                        .HasForeignKey("GerenciaId");

                    b.HasOne("nyp.DataModels.Publicacion")
                        .WithMany()
                        .HasForeignKey("PublicacionId");

                    b.HasOne("nyp.DataModels.Solicitud")
                        .WithMany()
                        .HasForeignKey("SolicitudId");

                    b.HasOne("nyp.DataModels.Unidad")
                        .WithMany()
                        .HasForeignKey("UnidadId");
                });

            modelBuilder.Entity("nyp.DataModels.Solicitud", b =>
                {
                    b.HasOne("nyp.DataModels.UsuarioIntranet")
                        .WithMany()
                        .HasForeignKey("AnalistaId");

                    b.HasOne("nyp.DataModels.UsuarioIntranet")
                        .WithMany()
                        .HasForeignKey("SolicitanteId");

                    b.HasOne("nyp.DataModels.Unidad")
                        .WithMany()
                        .HasForeignKey("UnidadId");
                });

            modelBuilder.Entity("nyp.DataModels.Unidad", b =>
                {
                    b.HasOne("nyp.DataModels.Area")
                        .WithMany()
                        .HasForeignKey("AreaId");
                });

            modelBuilder.Entity("nyp.DataModels.UsuarioConsulta", b =>
                {
                    b.HasOne("nyp.DataModels.Circular")
                        .WithMany()
                        .HasForeignKey("CircularId");

                    b.HasOne("nyp.DataModels.UsuarioIntranet")
                        .WithMany()
                        .HasForeignKey("UsuarioIntranetId");
                });

            modelBuilder.Entity("nyp.DataModels.UsuarioIntranet", b =>
                {
                    b.HasOne("nyp.DataModels.Unidad")
                        .WithMany()
                        .HasForeignKey("UnidadId");
                });

            modelBuilder.Entity("nyp.DataModels.UsuariosEnListaDistribucion", b =>
                {
                    b.HasOne("nyp.DataModels.ListaDistribucion")
                        .WithMany()
                        .HasForeignKey("ListaDistribucionId");

                    b.HasOne("nyp.DataModels.UsuarioIntranet")
                        .WithMany()
                        .HasForeignKey("UsuarioIntranetId");
                });
        }
    }
}
