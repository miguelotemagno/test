using System;
using System.Collections.Generic;
using Microsoft.Data.Entity.Migrations;
using Microsoft.Data.Entity.Metadata;

namespace nyp.Migrations
{
    public partial class enlaces : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(name: "FK_AutorizacionSolicitud_Solicitud_SolicitudId", table: "AutorizacionSolicitud");
            migrationBuilder.DropForeignKey(name: "FK_AutorizacionSolicitud_UsuarioIntranet_UsuarioIntranetId", table: "AutorizacionSolicitud");
            migrationBuilder.DropForeignKey(name: "FK_CategoriasEnPublicacion_Categoria_CategoriaId", table: "CategoriasEnPublicacion");
            migrationBuilder.DropForeignKey(name: "FK_CategoriasEnPublicacion_Publicacion_PublicacionId", table: "CategoriasEnPublicacion");
            migrationBuilder.DropForeignKey(name: "FK_Documento_Publicacion_PublicacionId", table: "Documento");
            migrationBuilder.DropForeignKey(name: "FK_DocumentosEnPublicacion_Documento_DocumentoId", table: "DocumentosEnPublicacion");
            migrationBuilder.DropForeignKey(name: "FK_DocumentosExistentesEnSolicitud_Documento_DocumentoId", table: "DocumentosExistentesEnSolicitud");
            migrationBuilder.DropForeignKey(name: "FK_EstadisticaDocumento_Documento_DocumentoId", table: "EstadisticaDocumento");
            migrationBuilder.DropForeignKey(name: "FK_ExclusionUsuario_Restriccion_RestriccionRestriccionId", table: "ExclusionUsuario");
            migrationBuilder.DropForeignKey(name: "FK_ExclusionUsuario_UsuarioIntranet_UsuarioIntranetId", table: "ExclusionUsuario");
            migrationBuilder.DropForeignKey(name: "FK_Nota_UsuarioIntranet_AutorId", table: "Nota");
            migrationBuilder.DropForeignKey(name: "FK_Nota_Solicitud_SolicitudId", table: "Nota");
            migrationBuilder.DropForeignKey(name: "FK_ProcesoCertificacion_UsuarioIntranet_AnalistaEjecutorId", table: "ProcesoCertificacion");
            migrationBuilder.DropForeignKey(name: "FK_ProcesoCertificacion_Publicacion_PublicacionId", table: "ProcesoCertificacion");
            migrationBuilder.DropForeignKey(name: "FK_Publicacion_Solicitud_SolicitudId", table: "Publicacion");
            migrationBuilder.DropForeignKey(name: "FK_Restriccion_Gerencia_GerenciaId", table: "Restriccion");
            migrationBuilder.DropForeignKey(name: "FK_Restriccion_Solicitud_SolicitudId", table: "Restriccion");
            migrationBuilder.DropForeignKey(name: "FK_UsuarioConsulta_Circular_CircularId", table: "UsuarioConsulta");
            migrationBuilder.DropForeignKey(name: "FK_UsuarioConsulta_UsuarioIntranet_UsuarioIntranetId", table: "UsuarioConsulta");
            migrationBuilder.DropForeignKey(name: "FK_UsuarioIntranet_Unidad_UnidadId", table: "UsuarioIntranet");
            migrationBuilder.DropForeignKey(name: "FK_UsuariosEnListaDistribucion_ListaDistribucion_ListaDistribucionId", table: "UsuariosEnListaDistribucion");
            migrationBuilder.DropForeignKey(name: "FK_UsuariosEnListaDistribucion_UsuarioIntranet_UsuarioIntranetId", table: "UsuariosEnListaDistribucion");
            migrationBuilder.CreateTable(
                name: "EnlacesCategoria",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CategoriaId = table.Column<long>(nullable: true),
                    Hipervinculo = table.Column<string>(nullable: true),
                    Titulo = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EnlacesCategoria", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EnlacesCategoria_Categoria_CategoriaId",
                        column: x => x.CategoriaId,
                        principalTable: "Categoria",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });
            migrationBuilder.AddForeignKey(
                name: "FK_AutorizacionSolicitud_Solicitud_SolicitudId",
                table: "AutorizacionSolicitud",
                column: "SolicitudId",
                principalTable: "Solicitud",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_AutorizacionSolicitud_UsuarioIntranet_UsuarioIntranetId",
                table: "AutorizacionSolicitud",
                column: "UsuarioIntranetId",
                principalTable: "UsuarioIntranet",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_CategoriasEnPublicacion_Categoria_CategoriaId",
                table: "CategoriasEnPublicacion",
                column: "CategoriaId",
                principalTable: "Categoria",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_CategoriasEnPublicacion_Publicacion_PublicacionId",
                table: "CategoriasEnPublicacion",
                column: "PublicacionId",
                principalTable: "Publicacion",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_Documento_Publicacion_PublicacionId",
                table: "Documento",
                column: "PublicacionId",
                principalTable: "Publicacion",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_DocumentosEnPublicacion_Documento_DocumentoId",
                table: "DocumentosEnPublicacion",
                column: "DocumentoId",
                principalTable: "Documento",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_DocumentosExistentesEnSolicitud_Documento_DocumentoId",
                table: "DocumentosExistentesEnSolicitud",
                column: "DocumentoId",
                principalTable: "Documento",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_EstadisticaDocumento_Documento_DocumentoId",
                table: "EstadisticaDocumento",
                column: "DocumentoId",
                principalTable: "Documento",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_ExclusionUsuario_Restriccion_RestriccionRestriccionId",
                table: "ExclusionUsuario",
                column: "RestriccionRestriccionId",
                principalTable: "Restriccion",
                principalColumn: "RestriccionId",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_ExclusionUsuario_UsuarioIntranet_UsuarioIntranetId",
                table: "ExclusionUsuario",
                column: "UsuarioIntranetId",
                principalTable: "UsuarioIntranet",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_Nota_UsuarioIntranet_AutorId",
                table: "Nota",
                column: "AutorId",
                principalTable: "UsuarioIntranet",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_Nota_Solicitud_SolicitudId",
                table: "Nota",
                column: "SolicitudId",
                principalTable: "Solicitud",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_ProcesoCertificacion_UsuarioIntranet_AnalistaEjecutorId",
                table: "ProcesoCertificacion",
                column: "AnalistaEjecutorId",
                principalTable: "UsuarioIntranet",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_ProcesoCertificacion_Publicacion_PublicacionId",
                table: "ProcesoCertificacion",
                column: "PublicacionId",
                principalTable: "Publicacion",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_Publicacion_Solicitud_SolicitudId",
                table: "Publicacion",
                column: "SolicitudId",
                principalTable: "Solicitud",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_Restriccion_Gerencia_GerenciaId",
                table: "Restriccion",
                column: "GerenciaId",
                principalTable: "Gerencia",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_Restriccion_Solicitud_SolicitudId",
                table: "Restriccion",
                column: "SolicitudId",
                principalTable: "Solicitud",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_UsuarioConsulta_Circular_CircularId",
                table: "UsuarioConsulta",
                column: "CircularId",
                principalTable: "Circular",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_UsuarioConsulta_UsuarioIntranet_UsuarioIntranetId",
                table: "UsuarioConsulta",
                column: "UsuarioIntranetId",
                principalTable: "UsuarioIntranet",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_UsuarioIntranet_Unidad_UnidadId",
                table: "UsuarioIntranet",
                column: "UnidadId",
                principalTable: "Unidad",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_UsuariosEnListaDistribucion_ListaDistribucion_ListaDistribucionId",
                table: "UsuariosEnListaDistribucion",
                column: "ListaDistribucionId",
                principalTable: "ListaDistribucion",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
            migrationBuilder.AddForeignKey(
                name: "FK_UsuariosEnListaDistribucion_UsuarioIntranet_UsuarioIntranetId",
                table: "UsuariosEnListaDistribucion",
                column: "UsuarioIntranetId",
                principalTable: "UsuarioIntranet",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(name: "FK_AutorizacionSolicitud_Solicitud_SolicitudId", table: "AutorizacionSolicitud");
            migrationBuilder.DropForeignKey(name: "FK_AutorizacionSolicitud_UsuarioIntranet_UsuarioIntranetId", table: "AutorizacionSolicitud");
            migrationBuilder.DropForeignKey(name: "FK_CategoriasEnPublicacion_Categoria_CategoriaId", table: "CategoriasEnPublicacion");
            migrationBuilder.DropForeignKey(name: "FK_CategoriasEnPublicacion_Publicacion_PublicacionId", table: "CategoriasEnPublicacion");
            migrationBuilder.DropForeignKey(name: "FK_Documento_Publicacion_PublicacionId", table: "Documento");
            migrationBuilder.DropForeignKey(name: "FK_DocumentosEnPublicacion_Documento_DocumentoId", table: "DocumentosEnPublicacion");
            migrationBuilder.DropForeignKey(name: "FK_DocumentosExistentesEnSolicitud_Documento_DocumentoId", table: "DocumentosExistentesEnSolicitud");
            migrationBuilder.DropForeignKey(name: "FK_EstadisticaDocumento_Documento_DocumentoId", table: "EstadisticaDocumento");
            migrationBuilder.DropForeignKey(name: "FK_ExclusionUsuario_Restriccion_RestriccionRestriccionId", table: "ExclusionUsuario");
            migrationBuilder.DropForeignKey(name: "FK_ExclusionUsuario_UsuarioIntranet_UsuarioIntranetId", table: "ExclusionUsuario");
            migrationBuilder.DropForeignKey(name: "FK_Nota_UsuarioIntranet_AutorId", table: "Nota");
            migrationBuilder.DropForeignKey(name: "FK_Nota_Solicitud_SolicitudId", table: "Nota");
            migrationBuilder.DropForeignKey(name: "FK_ProcesoCertificacion_UsuarioIntranet_AnalistaEjecutorId", table: "ProcesoCertificacion");
            migrationBuilder.DropForeignKey(name: "FK_ProcesoCertificacion_Publicacion_PublicacionId", table: "ProcesoCertificacion");
            migrationBuilder.DropForeignKey(name: "FK_Publicacion_Solicitud_SolicitudId", table: "Publicacion");
            migrationBuilder.DropForeignKey(name: "FK_Restriccion_Gerencia_GerenciaId", table: "Restriccion");
            migrationBuilder.DropForeignKey(name: "FK_Restriccion_Solicitud_SolicitudId", table: "Restriccion");
            migrationBuilder.DropForeignKey(name: "FK_UsuarioConsulta_Circular_CircularId", table: "UsuarioConsulta");
            migrationBuilder.DropForeignKey(name: "FK_UsuarioConsulta_UsuarioIntranet_UsuarioIntranetId", table: "UsuarioConsulta");
            migrationBuilder.DropForeignKey(name: "FK_UsuarioIntranet_Unidad_UnidadId", table: "UsuarioIntranet");
            migrationBuilder.DropForeignKey(name: "FK_UsuariosEnListaDistribucion_ListaDistribucion_ListaDistribucionId", table: "UsuariosEnListaDistribucion");
            migrationBuilder.DropForeignKey(name: "FK_UsuariosEnListaDistribucion_UsuarioIntranet_UsuarioIntranetId", table: "UsuariosEnListaDistribucion");
            migrationBuilder.DropTable("EnlacesCategoria");
            migrationBuilder.AddForeignKey(
                name: "FK_AutorizacionSolicitud_Solicitud_SolicitudId",
                table: "AutorizacionSolicitud",
                column: "SolicitudId",
                principalTable: "Solicitud",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_AutorizacionSolicitud_UsuarioIntranet_UsuarioIntranetId",
                table: "AutorizacionSolicitud",
                column: "UsuarioIntranetId",
                principalTable: "UsuarioIntranet",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_CategoriasEnPublicacion_Categoria_CategoriaId",
                table: "CategoriasEnPublicacion",
                column: "CategoriaId",
                principalTable: "Categoria",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_CategoriasEnPublicacion_Publicacion_PublicacionId",
                table: "CategoriasEnPublicacion",
                column: "PublicacionId",
                principalTable: "Publicacion",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_Documento_Publicacion_PublicacionId",
                table: "Documento",
                column: "PublicacionId",
                principalTable: "Publicacion",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_DocumentosEnPublicacion_Documento_DocumentoId",
                table: "DocumentosEnPublicacion",
                column: "DocumentoId",
                principalTable: "Documento",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_DocumentosExistentesEnSolicitud_Documento_DocumentoId",
                table: "DocumentosExistentesEnSolicitud",
                column: "DocumentoId",
                principalTable: "Documento",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_EstadisticaDocumento_Documento_DocumentoId",
                table: "EstadisticaDocumento",
                column: "DocumentoId",
                principalTable: "Documento",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_ExclusionUsuario_Restriccion_RestriccionRestriccionId",
                table: "ExclusionUsuario",
                column: "RestriccionRestriccionId",
                principalTable: "Restriccion",
                principalColumn: "RestriccionId",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_ExclusionUsuario_UsuarioIntranet_UsuarioIntranetId",
                table: "ExclusionUsuario",
                column: "UsuarioIntranetId",
                principalTable: "UsuarioIntranet",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_Nota_UsuarioIntranet_AutorId",
                table: "Nota",
                column: "AutorId",
                principalTable: "UsuarioIntranet",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_Nota_Solicitud_SolicitudId",
                table: "Nota",
                column: "SolicitudId",
                principalTable: "Solicitud",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_ProcesoCertificacion_UsuarioIntranet_AnalistaEjecutorId",
                table: "ProcesoCertificacion",
                column: "AnalistaEjecutorId",
                principalTable: "UsuarioIntranet",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_ProcesoCertificacion_Publicacion_PublicacionId",
                table: "ProcesoCertificacion",
                column: "PublicacionId",
                principalTable: "Publicacion",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_Publicacion_Solicitud_SolicitudId",
                table: "Publicacion",
                column: "SolicitudId",
                principalTable: "Solicitud",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_Restriccion_Gerencia_GerenciaId",
                table: "Restriccion",
                column: "GerenciaId",
                principalTable: "Gerencia",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_Restriccion_Solicitud_SolicitudId",
                table: "Restriccion",
                column: "SolicitudId",
                principalTable: "Solicitud",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_UsuarioConsulta_Circular_CircularId",
                table: "UsuarioConsulta",
                column: "CircularId",
                principalTable: "Circular",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_UsuarioConsulta_UsuarioIntranet_UsuarioIntranetId",
                table: "UsuarioConsulta",
                column: "UsuarioIntranetId",
                principalTable: "UsuarioIntranet",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_UsuarioIntranet_Unidad_UnidadId",
                table: "UsuarioIntranet",
                column: "UnidadId",
                principalTable: "Unidad",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_UsuariosEnListaDistribucion_ListaDistribucion_ListaDistribucionId",
                table: "UsuariosEnListaDistribucion",
                column: "ListaDistribucionId",
                principalTable: "ListaDistribucion",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
            migrationBuilder.AddForeignKey(
                name: "FK_UsuariosEnListaDistribucion_UsuarioIntranet_UsuarioIntranetId",
                table: "UsuariosEnListaDistribucion",
                column: "UsuarioIntranetId",
                principalTable: "UsuarioIntranet",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
