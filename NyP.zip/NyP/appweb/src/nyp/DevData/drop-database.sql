﻿drop table dbo.__EFMigrationsHistory;
drop table dbo.CategoriasEnPublicacion;
drop table dbo.DocumentosEnPublicacion;
drop table dbo.AutorizacionSolicitud;
drop table dbo.ArchivosEnSolicitud;
drop table dbo.CambioEnPublicacion;
drop table dbo.UsuarioConsulta;
drop table PropiedadConfiguracion;


drop table dbo.Categoria;
drop table dbo.Evento;
drop table dbo.Publicacion;
drop table dbo.Documento;
drop table dbo.Noticia;
drop table dbo.Seccion;
drop table dbo.PaginaContenidos;
drop table dbo.Organica;
drop table dbo.Unidad;
drop table dbo.Area;
drop table dbo.Gerencia;
drop table dbo.Nota;

delete from dbo.Solicitud;
delete from dbo.UsuarioIntranet;
drop table dbo.Circular;
drop table dbo.Solicitud;
drop table dbo.UsuarioIntranet;
drop table dbo.Archivo;


drop table dbo.ListaDistribucion;
drop table dbo.EventoConfiguracion;
drop table dbo.Area;
drop table dbo.Gerencia;
drop table dbo.ListaDistribucion;
drop table dbo.Unidad; 
drop table [dbo].[UsuariosEnListaDistribucion];