﻿using Newtonsoft.Json.Linq;
using Microsoft.AspNet.Hosting;
using nyp.DataModels;
using nyp.GestorDocumental.Service;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace nyp.GestorDocumental.NullContentManager
{
    public class NullPublicacionUri : IPublicacionUri
    {
        public DatosPublicacion DatosPublicacion { get; set; }
        public Uri Uri { get; set; }
    }

    public class NullResultadoAlmacenar : IResultadoAlmacenar
    {
        public string Id { get; set; }
        public bool Ok { get; set; }
        public string Mensaje { get; set; }
        public Uri Uri { get; set; }
    }

    public class NullContentManagerService : IGestorDocumental
    {
        private INYPContext dbContext;
        private IHostingEnvironment HostingEnvironment;

        public NullContentManagerService(INYPContext context, IHostingEnvironment hostingEnvironment)
        {
            dbContext = context;
            HostingEnvironment = hostingEnvironment;
        }

        public IList<IPublicacionUri> Search(int? CategoriaId, string searchText)
        {
            var qry = from doc in dbContext.Documentos
                      select doc;

            if (!string.IsNullOrEmpty(searchText))
            {
                qry = qry.Where(doc => doc.NombreArchivo.Contains(searchText));
            }

            var listExpr = from doc in qry
                           select new NullPublicacionUri()
                           {
                               DatosPublicacion = new DatosPublicacion()
                               {
                                   Descripcion = doc.NombreArchivo,
                                   NombreFisico = doc.NombreArchivo
                               },
                               Uri = new Uri(string.Format("http://localhost:37438/Solicitud/Doc/{0}", doc.Id))
                           };

            return new List<IPublicacionUri>(listExpr.ToList());
        }

        public IResultadoAlmacenar Almacenar(DatosPublicacion datosPublicacion, string nombreArchivo, string stream)
        {
            var result = new NullResultadoAlmacenar();

            result.Ok = true;
            var urlServer = (from d in dbContext.Propiedades
                             where d.Id == "RutaServer"
                             select d.Valor).FirstOrDefault();
            string uri = urlServer + "/Solicitud/Doc/{0}"; 
            result.Uri = new Uri(string.Format(uri, datosPublicacion.Id));
            result.Id = nombreArchivo;
            return result;
        }
        private string GetPhysicalFilename(string fileName)
        {

            var directorioTemporal = (from d in dbContext.Propiedades
                                     where d.Id == "DirectorioTemporal"
                                     select d.Valor).FirstOrDefault();
            string rutaArchivo = directorioTemporal.ToString(); 
            rutaArchivo = Path.Combine(rutaArchivo, "tmp-upload-zone", fileName);
            return rutaArchivo;
        }

        public DocumentoEnGestor GetDocumento(string idDocumento)
        {
            var doc = (from d in dbContext.Documentos
                       where d.GestorDocumentalId == idDocumento
                       select d).FirstOrDefault();
            return GetDocumento(doc);
        }

        private DocumentoEnGestor GetDocumento(Documento doc)
        {
            if (doc != null)
            {
                var nombreFisico = GetPhysicalFilename(doc.GestorDocumentalId);
                if (nombreFisico != null)
                {
                    try {
                        byte[] fileBytes = File.ReadAllBytes(nombreFisico);
                        if (fileBytes != null)
                        {
                            return new DocumentoEnGestor()
                            {
                                Id = doc.GestorDocumentalId,
                                MimeType = "application/octet-stream",
                                Nombre = doc.NombreArchivo,
                                Contenidos = fileBytes
                            };
                        }
                    } catch
                    {

                    }
                    
                }
            }
            return null;
        }

        public DocumentoEnGestor GetDocumentoPorNombre(string nombreArchivo)
        {
            var doc = (from d in dbContext.Documentos
                       where d.NombreArchivo == nombreArchivo
                       select d).FirstOrDefault();
            return GetDocumento(doc);

        }
    }
}
